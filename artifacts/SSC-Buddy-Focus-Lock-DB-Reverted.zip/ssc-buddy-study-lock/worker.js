//#region shared/study-breaks.ts
var e = (e) => Math.max(0, Math.floor(e / 30) - 1);
function t(e, t = Date.now()) {
	return !!e?.paused && Number.isSafeInteger(e.breakUntil) && e.breakUntil > t;
}
function n(e, t = Date.now()) {
	if (!e.paused || !e.breakUntil || t < e.breakUntil) return e;
	let { paused: n, pausedAt: r, remainingMs: i, breakUntil: a, ...o } = e;
	return {
		...o,
		id: `${e.lockId ?? e.id}:focus-${e.breaksTaken ?? 0}`,
		lockId: e.lockId ?? e.id,
		startedAt: a,
		endsAt: a + (i ?? 0)
	};
}
//#endregion
//#region node_modules/.pnpm/@firebase+util@1.15.3/node_modules/@firebase/util/dist/postinstall.mjs
var r = () => void 0, i = function(e) {
	let t = [], n = 0;
	for (let r = 0; r < e.length; r++) {
		let i = e.charCodeAt(r);
		i < 128 ? t[n++] = i : i < 2048 ? (t[n++] = i >> 6 | 192, t[n++] = i & 63 | 128) : (i & 64512) == 55296 && r + 1 < e.length && (e.charCodeAt(r + 1) & 64512) == 56320 ? (i = 65536 + ((i & 1023) << 10) + (e.charCodeAt(++r) & 1023), t[n++] = i >> 18 | 240, t[n++] = i >> 12 & 63 | 128, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128) : (t[n++] = i >> 12 | 224, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128);
	}
	return t;
}, a = function(e) {
	let t = [], n = 0, r = 0;
	for (; n < e.length;) {
		let i = e[n++];
		if (i < 128) t[r++] = String.fromCharCode(i);
		else if (i > 191 && i < 224) {
			let a = e[n++];
			t[r++] = String.fromCharCode((i & 31) << 6 | a & 63);
		} else if (i > 239 && i < 365) {
			let a = e[n++], o = e[n++], s = e[n++], c = ((i & 7) << 18 | (a & 63) << 12 | (o & 63) << 6 | s & 63) - 65536;
			t[r++] = String.fromCharCode(55296 + (c >> 10)), t[r++] = String.fromCharCode(56320 + (c & 1023));
		} else {
			let a = e[n++], o = e[n++];
			t[r++] = String.fromCharCode((i & 15) << 12 | (a & 63) << 6 | o & 63);
		}
	}
	return t.join("");
}, o = {
	byteToCharMap_: null,
	charToByteMap_: null,
	byteToCharMapWebSafe_: null,
	charToByteMapWebSafe_: null,
	ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	get ENCODED_VALS() {
		return this.ENCODED_VALS_BASE + "+/=";
	},
	get ENCODED_VALS_WEBSAFE() {
		return this.ENCODED_VALS_BASE + "-_.";
	},
	HAS_NATIVE_SUPPORT: typeof atob == "function",
	encodeByteArray(e, t) {
		if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
		this.init_();
		let n = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_, r = [];
		for (let t = 0; t < e.length; t += 3) {
			let i = e[t], a = t + 1 < e.length, o = a ? e[t + 1] : 0, s = t + 2 < e.length, c = s ? e[t + 2] : 0, l = i >> 2, u = (i & 3) << 4 | o >> 4, d = (o & 15) << 2 | c >> 6, f = c & 63;
			s || (f = 64, a || (d = 64)), r.push(n[l], n[u], n[d], n[f]);
		}
		return r.join("");
	},
	encodeString(e, t) {
		return this.HAS_NATIVE_SUPPORT && !t ? btoa(e) : this.encodeByteArray(i(e), t);
	},
	decodeString(e, t) {
		return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : a(this.decodeStringToByteArray(e, t));
	},
	decodeStringToByteArray(e, t) {
		this.init_();
		let n = t ? this.charToByteMapWebSafe_ : this.charToByteMap_, r = [];
		for (let t = 0; t < e.length;) {
			let i = n[e.charAt(t++)], a = t < e.length ? n[e.charAt(t)] : 0;
			++t;
			let o = t < e.length ? n[e.charAt(t)] : 64;
			++t;
			let c = t < e.length ? n[e.charAt(t)] : 64;
			if (++t, i == null || a == null || o == null || c == null) throw new s();
			let l = i << 2 | a >> 4;
			if (r.push(l), o !== 64) {
				let e = a << 4 & 240 | o >> 2;
				if (r.push(e), c !== 64) {
					let e = o << 6 & 192 | c;
					r.push(e);
				}
			}
		}
		return r;
	},
	init_() {
		if (!this.byteToCharMap_) {
			this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
			for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e);
		}
	}
}, s = class extends Error {
	constructor() {
		super(...arguments), this.name = "DecodeBase64StringError";
	}
}, c = function(e) {
	let t = i(e);
	return o.encodeByteArray(t, !0);
}, l = function(e) {
	return c(e).replace(/\./g, "");
}, u = function(e) {
	try {
		return o.decodeString(e, !0);
	} catch (e) {
		console.error("base64Decode failed: ", e);
	}
	return null;
};
function d() {
	if (typeof self < "u") return self;
	if (typeof window < "u") return window;
	if (typeof global < "u") return global;
	throw Error("Unable to locate global object.");
}
var f = () => d().__FIREBASE_DEFAULTS__, p = () => {
	if (typeof process > "u" || process.env === void 0) return;
	let e = process.env.__FIREBASE_DEFAULTS__;
	if (e) return JSON.parse(e);
}, m = () => {
	if (typeof document > "u") return;
	let e;
	try {
		e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/);
	} catch {
		return;
	}
	let t = e && u(e[1]);
	return t && JSON.parse(t);
}, ee = () => {
	try {
		return r() || f() || p() || m();
	} catch (e) {
		console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
		return;
	}
}, h = () => ee()?.config, g = class {
	constructor() {
		this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((e, t) => {
			this.resolve = e, this.reject = t;
		});
	}
	wrapCallback(e) {
		return (t, n) => {
			t ? this.reject(t) : this.resolve(n), typeof e == "function" && (this.promise.catch(() => {}), e.length === 1 ? e(t) : e(t, n));
		};
	}
};
function _() {
	return typeof navigator < "u" && typeof navigator.userAgent == "string" ? navigator.userAgent : "";
}
function v() {
	return typeof window < "u" && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(_());
}
function te() {
	return typeof navigator < "u" && navigator.userAgent === "Cloudflare-Workers";
}
function ne() {
	let e = typeof chrome == "object" ? chrome.runtime : typeof browser == "object" ? browser.runtime : void 0;
	return typeof e == "object" && e.id !== void 0;
}
function re() {
	return typeof navigator == "object" && navigator.product === "ReactNative";
}
function ie() {
	try {
		return typeof indexedDB == "object";
	} catch {
		return !1;
	}
}
function ae() {
	return new Promise((e, t) => {
		try {
			let n = !0, r = "validate-browser-context-for-indexeddb-analytics-module", i = self.indexedDB.open(r);
			i.onsuccess = () => {
				i.result.close(), n || self.indexedDB.deleteDatabase(r), e(!0);
			}, i.onupgradeneeded = () => {
				n = !1;
			}, i.onerror = () => {
				t(i.error?.message || "");
			};
		} catch (e) {
			t(e);
		}
	});
}
var oe = "FirebaseError", y = class e extends Error {
	constructor(t, n, r) {
		super(n), this.code = t, this.customData = r, this.name = oe, Object.setPrototypeOf(this, e.prototype), Error.captureStackTrace && Error.captureStackTrace(this, b.prototype.create);
	}
}, b = class {
	constructor(e, t, n) {
		this.service = e, this.serviceName = t, this.errors = n;
	}
	create(e, ...t) {
		let n = t[0] || {}, r = `${this.service}/${e}`, i = this.errors[e], a = i ? se(i, n) : "Error";
		return new y(r, `${this.serviceName}: ${a} (${r}).`, n);
	}
};
function se(e, t) {
	try {
		let n = 0, r = "";
		for (; n < e.length;) {
			let i = e.indexOf("{$", n);
			if (i === -1) {
				r += e.substring(n);
				break;
			}
			let a = e.indexOf("}", i + 2);
			if (a === -1) {
				r += e.substring(n);
				break;
			}
			let o = e.substring(i + 2, a), s = t[o];
			r += e.substring(n, i) + (s == null ? `<${o}?>` : String(s)), n = a + 1;
		}
		return r;
	} catch {
		return e;
	}
}
function x(e, t) {
	if (e === t) return !0;
	let n = Object.keys(e), r = Object.keys(t);
	for (let i of n) {
		if (!r.includes(i)) return !1;
		let n = e[i], a = t[i];
		if (ce(n) && ce(a)) {
			if (!x(n, a)) return !1;
		} else if (n !== a) return !1;
	}
	for (let e of r) if (!n.includes(e)) return !1;
	return !0;
}
function ce(e) {
	return typeof e == "object" && !!e;
}
function le(e) {
	let t = [];
	for (let [n, r] of Object.entries(e)) Array.isArray(r) ? r.forEach((e) => {
		t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e));
	}) : t.push(encodeURIComponent(n) + "=" + encodeURIComponent(r));
	return t.length ? "&" + t.join("&") : "";
}
function S(e) {
	let t = {};
	return e.replace(/^\?/, "").split("&").forEach((e) => {
		if (e) {
			let [n, r] = e.split("=");
			t[decodeURIComponent(n)] = decodeURIComponent(r);
		}
	}), t;
}
function C(e) {
	let t = e.indexOf("?");
	if (!t) return "";
	let n = e.indexOf("#", t);
	return e.substring(t, n > 0 ? n : void 0);
}
function ue(e, t) {
	let n = new de(e, t);
	return n.subscribe.bind(n);
}
var de = class {
	constructor(e, t) {
		this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = t, this.task.then(() => {
			e(this);
		}).catch((e) => {
			this.error(e);
		});
	}
	next(e) {
		this.forEachObserver((t) => {
			t.next(e);
		});
	}
	error(e) {
		this.forEachObserver((t) => {
			t.error(e);
		}), this.close(e);
	}
	complete() {
		this.forEachObserver((e) => {
			e.complete();
		}), this.close();
	}
	subscribe(e, t, n) {
		let r;
		if (e === void 0 && t === void 0 && n === void 0) throw Error("Missing Observer.");
		r = fe(e, [
			"next",
			"error",
			"complete"
		]) ? e : {
			next: e,
			error: t,
			complete: n
		}, r.next === void 0 && (r.next = pe), r.error === void 0 && (r.error = pe), r.complete === void 0 && (r.complete = pe);
		let i = this.unsubscribeOne.bind(this, this.observers.length);
		return this.finalized && this.task.then(() => {
			try {
				this.finalError ? r.error(this.finalError) : r.complete();
			} catch {}
		}), this.observers.push(r), i;
	}
	unsubscribeOne(e) {
		this.observers !== void 0 && this.observers[e] !== void 0 && (delete this.observers[e], --this.observerCount, this.observerCount === 0 && this.onNoObservers !== void 0 && this.onNoObservers(this));
	}
	forEachObserver(e) {
		if (!this.finalized) for (let t = 0; t < this.observers.length; t++) this.sendOne(t, e);
	}
	sendOne(e, t) {
		this.task.then(() => {
			if (this.observers !== void 0 && this.observers[e] !== void 0) try {
				t(this.observers[e]);
			} catch (e) {
				typeof console < "u" && console.error && console.error(e);
			}
		});
	}
	close(e) {
		this.finalized || (this.finalized = !0, e !== void 0 && (this.finalError = e), this.task.then(() => {
			this.observers = void 0, this.onNoObservers = void 0;
		}));
	}
};
function fe(e, t) {
	if (typeof e != "object" || !e) return !1;
	for (let n of t) if (n in e && typeof e[n] == "function") return !0;
	return !1;
}
function pe() {}
function w(e) {
	return e && e._delegate ? e._delegate : e;
}
function me(e) {
	try {
		return (e.startsWith("http://") || e.startsWith("https://") ? new URL(e).hostname : e).endsWith(".cloudworkstations.dev");
	} catch {
		return !1;
	}
}
//#endregion
//#region node_modules/.pnpm/@firebase+component@0.7.5/node_modules/@firebase/component/dist/esm/index.esm.js
var T = class {
	constructor(e, t, n) {
		this.name = e, this.instanceFactory = t, this.type = n, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null;
	}
	setInstantiationMode(e) {
		return this.instantiationMode = e, this;
	}
	setMultipleInstances(e) {
		return this.multipleInstances = e, this;
	}
	setServiceProps(e) {
		return this.serviceProps = e, this;
	}
	setInstanceCreatedCallback(e) {
		return this.onInstanceCreated = e, this;
	}
}, E = "[DEFAULT]", he = class {
	constructor(e, t) {
		this.name = e, this.container = t, this.component = null, this.instances = /* @__PURE__ */ new Map(), this.instancesDeferred = /* @__PURE__ */ new Map(), this.instancesOptions = /* @__PURE__ */ new Map(), this.onInitCallbacks = /* @__PURE__ */ new Map();
	}
	get(e) {
		let t = this.normalizeInstanceIdentifier(e);
		if (!this.instancesDeferred.has(t)) {
			let e = new g();
			if (this.instancesDeferred.set(t, e), this.isInitialized(t) || this.shouldAutoInitialize()) try {
				let n = this.getOrInitializeService({ instanceIdentifier: t });
				n && e.resolve(n);
			} catch {}
		}
		return this.instancesDeferred.get(t).promise;
	}
	getImmediate(e) {
		let t = this.normalizeInstanceIdentifier(e?.identifier), n = e?.optional ?? !1;
		if (this.isInitialized(t) || this.shouldAutoInitialize()) try {
			return this.getOrInitializeService({ instanceIdentifier: t });
		} catch (e) {
			if (n) return null;
			throw e;
		}
		if (n) return null;
		throw Error(`Service ${this.name} is not available`);
	}
	getComponent() {
		return this.component;
	}
	setComponent(e) {
		if (e.name !== this.name) throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);
		if (this.component) throw Error(`Component for ${this.name} has already been provided`);
		if (this.component = e, this.shouldAutoInitialize()) {
			if (_e(e)) try {
				this.getOrInitializeService({ instanceIdentifier: E });
			} catch {}
			for (let [e, t] of this.instancesDeferred.entries()) {
				let n = this.normalizeInstanceIdentifier(e);
				try {
					let e = this.getOrInitializeService({ instanceIdentifier: n });
					t.resolve(e);
				} catch {}
			}
		}
	}
	clearInstance(e = E) {
		this.instancesDeferred.delete(e), this.instancesOptions.delete(e), this.instances.delete(e);
	}
	async delete() {
		let e = Array.from(this.instances.values());
		await Promise.all([...e.filter((e) => "INTERNAL" in e).map((e) => e.INTERNAL.delete()), ...e.filter((e) => "_delete" in e).map((e) => e._delete())]);
	}
	isComponentSet() {
		return this.component != null;
	}
	isInitialized(e = E) {
		return this.instances.has(e);
	}
	getOptions(e = E) {
		return this.instancesOptions.get(e) || {};
	}
	initialize(e = {}) {
		let { options: t = {} } = e, n = this.normalizeInstanceIdentifier(e.instanceIdentifier);
		if (this.isInitialized(n)) throw Error(`${this.name}(${n}) has already been initialized`);
		if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
		let r = this.getOrInitializeService({
			instanceIdentifier: n,
			options: t
		});
		for (let [e, t] of this.instancesDeferred.entries()) n === this.normalizeInstanceIdentifier(e) && t.resolve(r);
		return r;
	}
	onInit(e, t) {
		let n = this.normalizeInstanceIdentifier(t), r = this.onInitCallbacks.get(n) ?? /* @__PURE__ */ new Set();
		r.add(e), this.onInitCallbacks.set(n, r);
		let i = this.instances.get(n);
		return i && e(i, n), () => {
			r.delete(e);
		};
	}
	invokeOnInitCallbacks(e, t) {
		let n = this.onInitCallbacks.get(t);
		if (n) for (let r of n) try {
			r(e, t);
		} catch {}
	}
	getOrInitializeService({ instanceIdentifier: e, options: t = {} }) {
		let n = this.instances.get(e);
		if (!n && this.component && (n = this.component.instanceFactory(this.container, {
			instanceIdentifier: ge(e),
			options: t
		}), this.instances.set(e, n), this.instancesOptions.set(e, t), this.invokeOnInitCallbacks(n, e), this.component.onInstanceCreated)) try {
			this.component.onInstanceCreated(this.container, e, n);
		} catch {}
		return n || null;
	}
	normalizeInstanceIdentifier(e = E) {
		return this.component ? this.component.multipleInstances ? e : E : e;
	}
	shouldAutoInitialize() {
		return !!this.component && this.component.instantiationMode !== "EXPLICIT";
	}
};
function ge(e) {
	return e === E ? void 0 : e;
}
function _e(e) {
	return e.instantiationMode === "EAGER";
}
var ve = class {
	constructor(e) {
		this.name = e, this.providers = /* @__PURE__ */ new Map();
	}
	addComponent(e) {
		let t = this.getProvider(e.name);
		if (t.isComponentSet()) throw Error(`Component ${e.name} has already been registered with ${this.name}`);
		t.setComponent(e);
	}
	addOrOverwriteComponent(e) {
		this.getProvider(e.name).isComponentSet() && this.providers.delete(e.name), this.addComponent(e);
	}
	getProvider(e) {
		if (this.providers.has(e)) return this.providers.get(e);
		let t = new he(e, this);
		return this.providers.set(e, t), t;
	}
	getProviders() {
		return Array.from(this.providers.values());
	}
}, ye = [], D;
(function(e) {
	e[e.DEBUG = 0] = "DEBUG", e[e.VERBOSE = 1] = "VERBOSE", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", e[e.SILENT = 5] = "SILENT";
})(D ||= {});
var be = {
	debug: D.DEBUG,
	verbose: D.VERBOSE,
	info: D.INFO,
	warn: D.WARN,
	error: D.ERROR,
	silent: D.SILENT
}, xe = D.INFO, Se = {
	[D.DEBUG]: "log",
	[D.VERBOSE]: "log",
	[D.INFO]: "info",
	[D.WARN]: "warn",
	[D.ERROR]: "error"
}, Ce = (e, t, ...n) => {
	if (t < e.logLevel) return;
	let r = (/* @__PURE__ */ new Date()).toISOString(), i = Se[t];
	if (i) console[i](`[${r}]  ${e.name}:`, ...n);
	else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`);
}, we = class {
	constructor(e) {
		this.name = e, this._logLevel = xe, this._logHandler = Ce, this._userLogHandler = null, ye.push(this);
	}
	get logLevel() {
		return this._logLevel;
	}
	set logLevel(e) {
		if (!(e in D)) throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
		this._logLevel = e;
	}
	setLogLevel(e) {
		this._logLevel = typeof e == "string" ? be[e] : e;
	}
	get logHandler() {
		return this._logHandler;
	}
	set logHandler(e) {
		if (typeof e != "function") throw TypeError("Value assigned to `logHandler` must be a function");
		this._logHandler = e;
	}
	get userLogHandler() {
		return this._userLogHandler;
	}
	set userLogHandler(e) {
		this._userLogHandler = e;
	}
	debug(...e) {
		this._userLogHandler && this._userLogHandler(this, D.DEBUG, ...e), this._logHandler(this, D.DEBUG, ...e);
	}
	log(...e) {
		this._userLogHandler && this._userLogHandler(this, D.VERBOSE, ...e), this._logHandler(this, D.VERBOSE, ...e);
	}
	info(...e) {
		this._userLogHandler && this._userLogHandler(this, D.INFO, ...e), this._logHandler(this, D.INFO, ...e);
	}
	warn(...e) {
		this._userLogHandler && this._userLogHandler(this, D.WARN, ...e), this._logHandler(this, D.WARN, ...e);
	}
	error(...e) {
		this._userLogHandler && this._userLogHandler(this, D.ERROR, ...e), this._logHandler(this, D.ERROR, ...e);
	}
}, Te = (e, t) => t.some((t) => e instanceof t), Ee, De;
function Oe() {
	return Ee ||= [
		IDBDatabase,
		IDBObjectStore,
		IDBIndex,
		IDBCursor,
		IDBTransaction
	];
}
function ke() {
	return De ||= [
		IDBCursor.prototype.advance,
		IDBCursor.prototype.continue,
		IDBCursor.prototype.continuePrimaryKey
	];
}
var Ae = /* @__PURE__ */ new WeakMap(), je = /* @__PURE__ */ new WeakMap(), Me = /* @__PURE__ */ new WeakMap(), Ne = /* @__PURE__ */ new WeakMap(), Pe = /* @__PURE__ */ new WeakMap();
function Fe(e) {
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("success", i), e.removeEventListener("error", a);
		}, i = () => {
			t(O(e.result)), r();
		}, a = () => {
			n(e.error), r();
		};
		e.addEventListener("success", i), e.addEventListener("error", a);
	});
	return t.then((t) => {
		t instanceof IDBCursor && Ae.set(t, e);
	}).catch(() => {}), Pe.set(t, e), t;
}
function Ie(e) {
	if (je.has(e)) return;
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a);
		}, i = () => {
			t(), r();
		}, a = () => {
			n(e.error || new DOMException("AbortError", "AbortError")), r();
		};
		e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a);
	});
	je.set(e, t);
}
var Le = {
	get(e, t, n) {
		if (e instanceof IDBTransaction) {
			if (t === "done") return je.get(e);
			if (t === "objectStoreNames") return e.objectStoreNames || Me.get(e);
			if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
		}
		return O(e[t]);
	},
	set(e, t, n) {
		return e[t] = n, !0;
	},
	has(e, t) {
		return e instanceof IDBTransaction && (t === "done" || t === "store") || t in e;
	}
};
function Re(e) {
	Le = e(Le);
}
function ze(e) {
	return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...n) {
		let r = e.call(Ve(this), t, ...n);
		return Me.set(r, t.sort ? t.sort() : [t]), O(r);
	} : ke().includes(e) ? function(...t) {
		return e.apply(Ve(this), t), O(Ae.get(this));
	} : function(...t) {
		return O(e.apply(Ve(this), t));
	};
}
function Be(e) {
	return typeof e == "function" ? ze(e) : (e instanceof IDBTransaction && Ie(e), Te(e, Oe()) ? new Proxy(e, Le) : e);
}
function O(e) {
	if (e instanceof IDBRequest) return Fe(e);
	if (Ne.has(e)) return Ne.get(e);
	let t = Be(e);
	return t !== e && (Ne.set(e, t), Pe.set(t, e)), t;
}
var Ve = (e) => Pe.get(e);
//#endregion
//#region node_modules/.pnpm/idb@7.1.1/node_modules/idb/build/index.js
function He(e, t, { blocked: n, upgrade: r, blocking: i, terminated: a } = {}) {
	let o = indexedDB.open(e, t), s = O(o);
	return r && o.addEventListener("upgradeneeded", (e) => {
		r(O(o.result), e.oldVersion, e.newVersion, O(o.transaction), e);
	}), n && o.addEventListener("blocked", (e) => n(e.oldVersion, e.newVersion, e)), s.then((e) => {
		a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", (e) => i(e.oldVersion, e.newVersion, e));
	}).catch(() => {}), s;
}
var Ue = [
	"get",
	"getKey",
	"getAll",
	"getAllKeys",
	"count"
], We = [
	"put",
	"add",
	"delete",
	"clear"
], Ge = /* @__PURE__ */ new Map();
function Ke(e, t) {
	if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
	if (Ge.get(t)) return Ge.get(t);
	let n = t.replace(/FromIndex$/, ""), r = t !== n, i = We.includes(n);
	if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || Ue.includes(n))) return;
	let a = async function(e, ...t) {
		let a = this.transaction(e, i ? "readwrite" : "readonly"), o = a.store;
		return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0];
	};
	return Ge.set(t, a), a;
}
Re((e) => ({
	...e,
	get: (t, n, r) => Ke(t, n) || e.get(t, n, r),
	has: (t, n) => !!Ke(t, n) || e.has(t, n)
}));
//#endregion
//#region node_modules/.pnpm/@firebase+app@0.16.3/node_modules/@firebase/app/dist/esm/index.esm.js
var qe = class {
	constructor(e) {
		this.container = e;
	}
	getPlatformInfoString() {
		return this.container.getProviders().map((e) => {
			if (Je(e)) {
				let t = e.getImmediate();
				return `${t.library}/${t.version}`;
			}
			return null;
		}).filter((e) => e).join(" ");
	}
};
function Je(e) {
	return e.getComponent()?.type === "VERSION";
}
var Ye = "@firebase/app", Xe = "0.16.3", k = new we("@firebase/app"), Ze = "@firebase/app-compat", Qe = "@firebase/analytics-compat", $e = "@firebase/analytics", et = "@firebase/app-check-compat", tt = "@firebase/app-check", nt = "@firebase/auth", rt = "@firebase/auth-compat", it = "@firebase/database", at = "@firebase/data-connect", ot = "@firebase/database-compat", st = "@firebase/functions", ct = "@firebase/functions-compat", lt = "@firebase/installations", ut = "@firebase/installations-compat", dt = "@firebase/messaging", ft = "@firebase/messaging-compat", pt = "@firebase/performance", mt = "@firebase/performance-compat", ht = "@firebase/remote-config", gt = "@firebase/remote-config-compat", _t = "@firebase/storage", vt = "@firebase/storage-compat", yt = "@firebase/firestore", bt = "@firebase/ai", xt = "@firebase/firestore-compat", St = "firebase", Ct = "13.0.0", wt = "[DEFAULT]", Tt = {
	[Ye]: "fire-core",
	[Ze]: "fire-core-compat",
	[$e]: "fire-analytics",
	[Qe]: "fire-analytics-compat",
	[tt]: "fire-app-check",
	[et]: "fire-app-check-compat",
	[nt]: "fire-auth",
	[rt]: "fire-auth-compat",
	[it]: "fire-rtdb",
	[at]: "fire-data-connect",
	[ot]: "fire-rtdb-compat",
	[st]: "fire-fn",
	[ct]: "fire-fn-compat",
	[lt]: "fire-iid",
	[ut]: "fire-iid-compat",
	[dt]: "fire-fcm",
	[ft]: "fire-fcm-compat",
	[pt]: "fire-perf",
	[mt]: "fire-perf-compat",
	[ht]: "fire-rc",
	[gt]: "fire-rc-compat",
	[_t]: "fire-gcs",
	[vt]: "fire-gcs-compat",
	[yt]: "fire-fst",
	[xt]: "fire-fst-compat",
	[bt]: "fire-vertex",
	"fire-js": "fire-js",
	[St]: "fire-js-all"
}, Et = /* @__PURE__ */ new Map(), Dt = /* @__PURE__ */ new Map(), Ot = /* @__PURE__ */ new Map();
function kt(e, t) {
	try {
		e.container.addComponent(t);
	} catch (n) {
		k.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, n);
	}
}
function A(e) {
	let t = e.name;
	if (Ot.has(t)) return k.debug(`There were multiple attempts to register component ${t}.`), !1;
	Ot.set(t, e);
	for (let t of Et.values()) kt(t, e);
	for (let t of Dt.values()) kt(t, e);
	return !0;
}
function At(e, t) {
	let n = e.container.getProvider("heartbeat").getImmediate({ optional: !0 });
	return n && n.triggerHeartbeat(), e.container.getProvider(t);
}
function j(e) {
	return e != null && e.settings !== void 0;
}
var M = new b("app", "Firebase", {
	"no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
	"bad-app-name": "Illegal App name: '{$appName}'",
	"duplicate-app": "Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.",
	"app-deleted": "Firebase App named '{$appName}' already deleted",
	"server-app-deleted": "Firebase Server App has been deleted",
	"no-options": "Need to provide options, when not being deployed to hosting via source.",
	"invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
	"invalid-log-argument": "First argument to `onLog` must be null or a function.",
	"idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
	"finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
	"invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
}), jt = class {
	constructor(e, t, n) {
		this._isDeleted = !1, this._options = { ...e }, this._config = { ...t }, this._name = t.name, this._automaticDataCollectionEnabled = t.automaticDataCollectionEnabled, this._container = n, this.container.addComponent(new T("app", () => this, "PUBLIC"));
	}
	get automaticDataCollectionEnabled() {
		return this.checkDestroyed(), this._automaticDataCollectionEnabled;
	}
	set automaticDataCollectionEnabled(e) {
		this.checkDestroyed(), this._automaticDataCollectionEnabled = e;
	}
	get name() {
		return this.checkDestroyed(), this._name;
	}
	get options() {
		return this.checkDestroyed(), this._options;
	}
	get config() {
		return this.checkDestroyed(), this._config;
	}
	get container() {
		return this._container;
	}
	get isDeleted() {
		return this._isDeleted;
	}
	set isDeleted(e) {
		this._isDeleted = e;
	}
	checkDestroyed() {
		if (this.isDeleted) throw M.create("app-deleted", { appName: this._name });
	}
}, Mt = Ct;
function Nt(e, t = {}) {
	let n = e;
	typeof t != "object" && (t = { name: t });
	let r = {
		name: wt,
		automaticDataCollectionEnabled: !0,
		...t
	}, i = r.name;
	if (typeof i != "string" || !i) throw M.create("bad-app-name", { appName: String(i) });
	if (n ||= h(), !n) throw M.create("no-options");
	let a = Et.get(i);
	if (a) {
		if (!x(n, a.options)) throw M.create("duplicate-app", {
			appName: i,
			mismatchedParam: "options",
			oldValue: JSON.stringify(a.options),
			newValue: JSON.stringify(n)
		});
		if (x(r, a.config)) return a;
		throw M.create("duplicate-app", {
			appName: i,
			mismatchedParam: "config",
			oldValue: JSON.stringify(a.config),
			newValue: JSON.stringify(r)
		});
	}
	let o = new ve(i);
	for (let e of Ot.values()) o.addComponent(e);
	let s = new jt(n, r, o);
	return Et.set(i, s), s;
}
function N(e, t, n) {
	let r = Tt[e] ?? e;
	n && (r += `-${n}`);
	let i = r.match(/\s|\//), a = t.match(/\s|\//);
	if (i || a) {
		let e = [`Unable to register library "${r}" with version "${t}":`];
		i && e.push(`library name "${r}" contains illegal characters (whitespace or "/")`), i && a && e.push("and"), a && e.push(`version name "${t}" contains illegal characters (whitespace or "/")`), k.warn(e.join(" "));
		return;
	}
	A(new T(`${r}-version`, () => ({
		library: r,
		version: t
	}), "VERSION"));
}
var Pt = "firebase-heartbeat-database", Ft = 1, P = "firebase-heartbeat-store", It = null;
function Lt() {
	return It ||= He(Pt, Ft, { upgrade: (e, t) => {
		if (t === 0) try {
			e.createObjectStore(P);
		} catch (e) {
			console.warn(e);
		}
	} }).catch((e) => {
		throw M.create("idb-open", { originalErrorMessage: e.message });
	}), It;
}
async function Rt(e) {
	try {
		let t = (await Lt()).transaction(P), n = await t.objectStore(P).get(Bt(e));
		return await t.done, n;
	} catch (e) {
		if (e instanceof y) k.warn(e.message);
		else {
			let t = M.create("idb-get", { originalErrorMessage: e?.message });
			k.warn(t.message);
		}
	}
}
async function zt(e, t) {
	try {
		let n = (await Lt()).transaction(P, "readwrite");
		await n.objectStore(P).put(t, Bt(e)), await n.done;
	} catch (e) {
		if (e instanceof y) k.warn(e.message);
		else {
			let t = M.create("idb-set", { originalErrorMessage: e?.message });
			k.warn(t.message);
		}
	}
}
function Bt(e) {
	return `${e.name}!${e.options.appId}`;
}
var Vt = 1024, Ht = 30, Ut = class {
	constructor(e) {
		this.container = e, this._heartbeatsCache = null;
		let t = this.container.getProvider("app").getImmediate();
		this._storage = new Kt(t), this._heartbeatsCachePromise = this._storage.read().then((e) => (this._heartbeatsCache = e, e));
	}
	async triggerHeartbeat() {
		try {
			let e = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(), t = Wt();
			if (this._heartbeatsCache?.heartbeats == null && (this._heartbeatsCache = await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null) || this._heartbeatsCache.lastSentHeartbeatDate === t || this._heartbeatsCache.heartbeats.some((e) => e.date === t)) return;
			if (this._heartbeatsCache.heartbeats.push({
				date: t,
				agent: e
			}), this._heartbeatsCache.heartbeats.length > Ht) {
				let e = Jt(this._heartbeatsCache.heartbeats);
				this._heartbeatsCache.heartbeats.splice(e, 1);
			}
			return this._storage.overwrite(this._heartbeatsCache);
		} catch (e) {
			k.warn(e);
		}
	}
	async getHeartbeatsHeader() {
		try {
			if (this._heartbeatsCache === null && await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null || this._heartbeatsCache.heartbeats.length === 0) return "";
			let e = Wt(), { heartbeatsToSend: t, unsentEntries: n } = Gt(this._heartbeatsCache.heartbeats), r = l(JSON.stringify({
				version: 2,
				heartbeats: t
			}));
			return this._heartbeatsCache.lastSentHeartbeatDate = e, n.length > 0 ? (this._heartbeatsCache.heartbeats = n, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), r;
		} catch (e) {
			return k.warn(e), "";
		}
	}
};
function Wt() {
	return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
}
function Gt(e, t = Vt) {
	let n = [], r = e.slice();
	for (let i of e) {
		let e = n.find((e) => e.agent === i.agent);
		if (!e) {
			if (n.push({
				agent: i.agent,
				dates: [i.date]
			}), qt(n) > t) {
				n.pop();
				break;
			}
		} else if (e.dates.push(i.date), qt(n) > t) {
			e.dates.pop();
			break;
		}
		r = r.slice(1);
	}
	return {
		heartbeatsToSend: n,
		unsentEntries: r
	};
}
var Kt = class {
	constructor(e) {
		this.app = e, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck();
	}
	async runIndexedDBEnvironmentCheck() {
		return ie() ? ae().then(() => !0).catch(() => !1) : !1;
	}
	async read() {
		if (await this._canUseIndexedDBPromise) {
			let e = await Rt(this.app);
			return e?.heartbeats ? e : { heartbeats: [] };
		}
		return { heartbeats: [] };
	}
	async overwrite(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return zt(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: e.heartbeats
			});
		}
	}
	async add(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return zt(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: [...t.heartbeats, ...e.heartbeats]
			});
		}
	}
};
function qt(e) {
	return l(JSON.stringify({
		version: 2,
		heartbeats: e
	})).length;
}
function Jt(e) {
	if (e.length === 0) return -1;
	let t = 0, n = e[0].date;
	for (let r = 1; r < e.length; r++) e[r].date < n && (n = e[r].date, t = r);
	return t;
}
function Yt(e) {
	A(new T("platform-logger", (e) => new qe(e), "PRIVATE")), A(new T("heartbeat", (e) => new Ut(e), "PRIVATE")), N(Ye, Xe, e), N(Ye, Xe, "esm2020"), N("fire-js", "");
}
//#endregion
//#region node_modules/.pnpm/firebase@13.0.0/node_modules/firebase/app/dist/esm/index.esm.js
Yt(""), N("firebase", "13.0.0", "app");
//#endregion
//#region node_modules/.pnpm/@firebase+auth@1.13.7_@firebase+app@0.16.3/node_modules/@firebase/auth/dist/web-extension-esm/register-BYpQIvAX.js
function Xt() {
	return { "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK." };
}
var Zt = Xt, Qt = new b("auth", "Firebase", Xt()), F = new we("@firebase/auth");
function I(e, ...t) {
	F.logLevel <= D.WARN && F.warn(`Auth (${Mt}): ${e}`, ...t);
}
function L(e, ...t) {
	F.logLevel <= D.ERROR && F.error(`Auth (${Mt}): ${e}`, ...t);
}
function R(e, ...t) {
	throw tn(e, ...t);
}
function $t(e, ...t) {
	return tn(e, ...t);
}
function en(e, t, n) {
	return new b("auth", "Firebase", {
		...Zt(),
		[t]: n
	}).create(t, { appName: e.name });
}
function z(e) {
	return en(e, "operation-not-supported-in-this-environment", "Operations that alter the current user are not supported in conjunction with FirebaseServerApp");
}
function tn(e, ...t) {
	if (typeof e != "string") {
		let n = t[0], r = [...t.slice(1)];
		return r[0] && (r[0].appName = e.name), e._errorFactory.create(n, ...r);
	}
	return Qt.create(e, ...t);
}
function B(e, t, ...n) {
	if (!e) throw tn(t, ...n);
}
function V(e) {
	let t = "INTERNAL ASSERTION FAILED: " + e;
	throw L(t), Error(t);
}
function nn(e, t) {
	e || V(t);
}
function rn() {
	return an() === "http:" || an() === "https:";
}
function an() {
	return typeof self < "u" && self.location?.protocol || null;
}
function on() {
	return typeof navigator < "u" && navigator && "onLine" in navigator && typeof navigator.onLine == "boolean" && (rn() || ne() || "connection" in navigator) ? navigator.onLine : !0;
}
function sn() {
	if (typeof navigator > "u") return null;
	let e = navigator;
	return e.languages && e.languages[0] || e.language || null;
}
var cn = class {
	constructor(e, t) {
		this.shortDelay = e, this.longDelay = t, nn(t > e, "Short delay should be less than long delay!"), this.isMobile = v() || re();
	}
	get() {
		return on() ? this.isMobile ? this.longDelay : this.shortDelay : Math.min(5e3, this.shortDelay);
	}
};
function ln(e, t) {
	nn(e.emulator, "Emulator should always be set here");
	let { url: n } = e.emulator;
	return t ? `${n}${t.startsWith("/") ? t.slice(1) : t}` : n;
}
var un = class {
	static initialize(e, t, n) {
		this.fetchImpl = e, t && (this.headersImpl = t), n && (this.responseImpl = n);
	}
	static fetch() {
		if (this.fetchImpl) return this.fetchImpl;
		if (typeof self < "u" && "fetch" in self) return self.fetch;
		if (typeof globalThis < "u" && globalThis.fetch) return globalThis.fetch;
		if (typeof fetch < "u") return fetch;
		V("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static headers() {
		if (this.headersImpl) return this.headersImpl;
		if (typeof self < "u" && "Headers" in self) return self.Headers;
		if (typeof globalThis < "u" && globalThis.Headers) return globalThis.Headers;
		if (typeof Headers < "u") return Headers;
		V("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static response() {
		if (this.responseImpl) return this.responseImpl;
		if (typeof self < "u" && "Response" in self) return self.Response;
		if (typeof globalThis < "u" && globalThis.Response) return globalThis.Response;
		if (typeof Response < "u") return Response;
		V("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
}, dn = {
	CREDENTIAL_MISMATCH: "custom-token-mismatch",
	MISSING_CUSTOM_TOKEN: "internal-error",
	INVALID_IDENTIFIER: "invalid-email",
	MISSING_CONTINUE_URI: "internal-error",
	INVALID_PASSWORD: "wrong-password",
	MISSING_PASSWORD: "missing-password",
	INVALID_LOGIN_CREDENTIALS: "invalid-credential",
	EMAIL_EXISTS: "email-already-in-use",
	PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
	INVALID_IDP_RESPONSE: "invalid-credential",
	INVALID_PENDING_TOKEN: "invalid-credential",
	FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
	MISSING_REQ_TYPE: "internal-error",
	EMAIL_NOT_FOUND: "user-not-found",
	RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
	EXPIRED_OOB_CODE: "expired-action-code",
	INVALID_OOB_CODE: "invalid-action-code",
	MISSING_OOB_CODE: "internal-error",
	CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
	INVALID_ID_TOKEN: "invalid-user-token",
	TOKEN_EXPIRED: "user-token-expired",
	USER_NOT_FOUND: "user-token-expired",
	TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
	PASSWORD_DOES_NOT_MEET_REQUIREMENTS: "password-does-not-meet-requirements",
	INVALID_CODE: "invalid-verification-code",
	INVALID_SESSION_INFO: "invalid-verification-id",
	INVALID_TEMPORARY_PROOF: "invalid-credential",
	MISSING_SESSION_INFO: "missing-verification-id",
	SESSION_EXPIRED: "code-expired",
	MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
	UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
	INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
	ADMIN_ONLY_OPERATION: "admin-restricted-operation",
	INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
	MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
	MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
	MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
	SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
	SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
	BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
	RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
	MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
	INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
	INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
	MISSING_CLIENT_TYPE: "missing-client-type",
	MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
	INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
	INVALID_REQ_TYPE: "invalid-req-type"
}, fn = [
	"/v1/accounts:signInWithCustomToken",
	"/v1/accounts:signInWithEmailLink",
	"/v1/accounts:signInWithIdp",
	"/v1/accounts:signInWithPassword",
	"/v1/accounts:signInWithPhoneNumber",
	"/v1/token"
], pn = new cn(3e4, 6e4);
function H(e, t) {
	return e.tenantId && !t.tenantId ? {
		...t,
		tenantId: e.tenantId
	} : t;
}
async function U(e, t, n, r, i = {}) {
	return mn(e, i, async () => {
		let i = {}, a = {};
		r && (t === "GET" ? a = r : i = { body: JSON.stringify(r) });
		let o = le({
			...a,
			key: e.config.apiKey
		}).slice(1), s = await e._getAdditionalHeaders();
		s["Content-Type"] = "application/json", e.languageCode && (s["X-Firebase-Locale"] = e.languageCode);
		let c = {
			method: t,
			headers: s,
			...i
		};
		return te() || (c.referrerPolicy = "strict-origin-when-cross-origin"), e.emulatorConfig && me(e.emulatorConfig.host) && (c.credentials = "include"), un.fetch()(await gn(e, e.config.apiHost, n, o), c);
	});
}
async function mn(e, t, n) {
	e._canInitEmulator = !1;
	let r = {
		...dn,
		...t
	};
	try {
		let t = new vn(e), i = await Promise.race([n(), t.promise]);
		t.clearNetworkTimeout();
		let a = await i.json();
		if ("needConfirmation" in a) throw yn(e, "account-exists-with-different-credential", a);
		if (i.ok && !("errorMessage" in a)) return a;
		{
			let [t, n] = (i.ok ? a.errorMessage : a.error.message).split(" : ");
			if (t === "FEDERATED_USER_ID_ALREADY_LINKED") throw yn(e, "credential-already-in-use", a);
			if (t === "EMAIL_EXISTS") throw yn(e, "email-already-in-use", a);
			if (t === "USER_DISABLED") throw yn(e, "user-disabled", a);
			let o = r[t] || t.toLowerCase().replace(/[_\s]+/g, "-");
			if (n) throw en(e, o, n);
			R(e, o);
		}
	} catch (t) {
		if (t instanceof y) throw t;
		R(e, "network-request-failed", { message: String(t) });
	}
}
async function hn(e, t, n, r, i = {}) {
	let a = await U(e, t, n, r, i);
	return "mfaPendingCredential" in a && R(e, "multi-factor-auth-required", { _serverResponse: a }), a;
}
async function gn(e, t, n, r) {
	let i = `${t}${n}?${r}`, a = e, o = a.config.emulator ? ln(e.config, i) : `${e.config.apiScheme}://${i}`;
	return fn.includes(n) && (await a._persistenceManagerAvailable, a._getPersistenceType() === "COOKIE") ? a._getPersistence()._getFinalTarget(o).toString() : o;
}
function _n(e) {
	switch (e) {
		case "ENFORCE": return "ENFORCE";
		case "AUDIT": return "AUDIT";
		case "OFF": return "OFF";
		default: return "ENFORCEMENT_STATE_UNSPECIFIED";
	}
}
var vn = class {
	clearNetworkTimeout() {
		clearTimeout(this.timer);
	}
	constructor(e) {
		this.auth = e, this.timer = null, this.promise = new Promise((e, t) => {
			this.timer = setTimeout(() => t($t(this.auth, "network-request-failed")), pn.get());
		});
	}
};
function yn(e, t, n) {
	let r = { appName: e.name };
	n.email && (r.email = n.email), n.phoneNumber && (r.phoneNumber = n.phoneNumber);
	let i = $t(e, t, r);
	return i.customData._tokenResponse = n, i;
}
function bn(e) {
	return e !== void 0 && e.enterprise !== void 0;
}
var xn = class {
	constructor(e) {
		if (this.siteKey = "", this.recaptchaEnforcementState = [], e.recaptchaKey === void 0) throw Error("recaptchaKey undefined");
		this.siteKey = e.recaptchaKey.split("/")[3], this.recaptchaEnforcementState = e.recaptchaEnforcementState;
	}
	getProviderEnforcementState(e) {
		if (!this.recaptchaEnforcementState || this.recaptchaEnforcementState.length === 0) return null;
		for (let t of this.recaptchaEnforcementState) if (t.provider && t.provider === e) return _n(t.enforcementState);
		return null;
	}
	isProviderEnabled(e) {
		return this.getProviderEnforcementState(e) === "ENFORCE" || this.getProviderEnforcementState(e) === "AUDIT";
	}
	isAnyProviderEnabled() {
		return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") || this.isProviderEnabled("PHONE_PROVIDER");
	}
};
async function Sn(e, t) {
	return U(e, "GET", "/v2/recaptchaConfig", H(e, t));
}
async function Cn(e, t) {
	return U(e, "POST", "/v1/accounts:delete", t);
}
async function wn(e, t) {
	return U(e, "POST", "/v1/accounts:lookup", t);
}
function W(e) {
	if (e) try {
		let t = new Date(Number(e));
		if (!isNaN(t.getTime())) return t.toUTCString();
	} catch {}
}
async function Tn(e, t = !1) {
	let n = w(e), r = await n.getIdToken(t), i = Dn(r);
	B(i && i.exp && i.auth_time && i.iat, n.auth, "internal-error");
	let a = typeof i.firebase == "object" ? i.firebase : void 0, o = a?.sign_in_provider;
	return {
		claims: i,
		token: r,
		authTime: W(En(i.auth_time)),
		issuedAtTime: W(En(i.iat)),
		expirationTime: W(En(i.exp)),
		signInProvider: o || null,
		signInSecondFactor: a?.sign_in_second_factor || null
	};
}
function En(e) {
	return Number(e) * 1e3;
}
function Dn(e) {
	let [t, n, r] = e.split(".");
	if (t === void 0 || n === void 0 || r === void 0) return L("JWT malformed, contained fewer than 3 sections"), null;
	try {
		let e = u(n);
		return e ? JSON.parse(e) : (L("Failed to decode base64 JWT payload"), null);
	} catch (e) {
		return L("Caught error parsing JWT payload as JSON", e?.toString()), null;
	}
}
function On(e) {
	let t = Dn(e);
	return B(t, "internal-error"), B(t.exp !== void 0, "internal-error"), B(t.iat !== void 0, "internal-error"), Number(t.exp) - Number(t.iat);
}
async function kn(e, t, n = !1) {
	if (n) return t;
	try {
		return await t;
	} catch (t) {
		throw t instanceof y && An(t) && e.auth.currentUser === e && await e.auth.signOut(), t;
	}
}
function An({ code: e }) {
	return e === "auth/user-disabled" || e === "auth/user-token-expired";
}
var jn = class {
	constructor(e) {
		this.user = e, this.isRunning = !1, this.timerId = null, this.errorBackoff = 3e4;
	}
	_start() {
		this.isRunning || (this.isRunning = !0, this.schedule());
	}
	_stop() {
		this.isRunning && (this.isRunning = !1, this.timerId !== null && clearTimeout(this.timerId));
	}
	getInterval(e) {
		if (e) {
			let e = this.errorBackoff;
			return this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4), e;
		}
		{
			this.errorBackoff = 3e4;
			let e = (this.user.stsTokenManager.expirationTime ?? 0) - Date.now() - 3e5;
			return Math.max(0, e);
		}
	}
	schedule(e = !1) {
		if (!this.isRunning) return;
		let t = this.getInterval(e);
		this.timerId = setTimeout(async () => {
			await this.iteration();
		}, t);
	}
	async iteration() {
		try {
			await this.user.getIdToken(!0);
		} catch (e) {
			e?.code === "auth/network-request-failed" && this.schedule(!0);
			return;
		}
		this.schedule();
	}
}, Mn = class {
	constructor(e, t) {
		this.createdAt = e, this.lastLoginAt = t, this._initializeTime();
	}
	_initializeTime() {
		this.lastSignInTime = W(this.lastLoginAt), this.creationTime = W(this.createdAt);
	}
	_copy(e) {
		this.createdAt = e.createdAt, this.lastLoginAt = e.lastLoginAt, this._initializeTime();
	}
	toJSON() {
		return {
			createdAt: this.createdAt,
			lastLoginAt: this.lastLoginAt
		};
	}
};
async function Nn(e) {
	let t = e.auth, n = await kn(e, wn(t, { idToken: await e.getIdToken() }));
	B(n?.users.length, t, "internal-error");
	let r = n.users[0];
	e._notifyReloadListener(r);
	let i = r.providerUserInfo?.length ? In(r.providerUserInfo) : [], a = Fn(e.providerData, i), o = e.isAnonymous, s = !(e.email && r.passwordHash) && !a?.length, c = o ? s : !1, l = {
		uid: r.localId,
		displayName: r.displayName || null,
		photoURL: r.photoUrl || null,
		email: r.email || null,
		emailVerified: r.emailVerified || !1,
		phoneNumber: r.phoneNumber || null,
		tenantId: r.tenantId || null,
		providerData: a,
		metadata: new Mn(r.createdAt, r.lastLoginAt),
		isAnonymous: c
	};
	Object.assign(e, l);
}
async function Pn(e) {
	let t = w(e);
	await Nn(t), await t.auth._persistUserIfCurrent(t), t.auth._notifyListenersIfCurrent(t);
}
function Fn(e, t) {
	return [...e.filter((e) => !t.some((t) => t.providerId === e.providerId)), ...t];
}
function In(e) {
	return e.map(({ providerId: e, ...t }) => ({
		providerId: e,
		uid: t.rawId || "",
		displayName: t.displayName || null,
		email: t.email || null,
		phoneNumber: t.phoneNumber || null,
		photoURL: t.photoUrl || null
	}));
}
async function Ln(e, t) {
	let n = await mn(e, {}, async () => {
		let n = le({
			grant_type: "refresh_token",
			refresh_token: t
		}).slice(1), { tokenApiHost: r, apiKey: i } = e.config, a = await gn(e, r, "/v1/token", `key=${i}`), o = await e._getAdditionalHeaders();
		o["Content-Type"] = "application/x-www-form-urlencoded";
		let s = {
			method: "POST",
			headers: o,
			body: n
		};
		return e.emulatorConfig && me(e.emulatorConfig.host) && (s.credentials = "include"), un.fetch()(a, s);
	});
	return {
		accessToken: n.access_token,
		expiresIn: n.expires_in,
		refreshToken: n.refresh_token
	};
}
async function Rn(e, t) {
	return U(e, "POST", "/v2/accounts:revokeToken", H(e, t));
}
var zn = class e {
	constructor() {
		this.refreshToken = null, this.accessToken = null, this.expirationTime = null;
	}
	get isExpired() {
		return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
	}
	updateFromServerResponse(e) {
		B(e.idToken, "internal-error"), B(e.idToken !== void 0, "internal-error"), B(e.refreshToken !== void 0, "internal-error");
		let t = "expiresIn" in e && e.expiresIn !== void 0 ? Number(e.expiresIn) : On(e.idToken);
		this.updateTokensAndExpiration(e.idToken, e.refreshToken, t);
	}
	updateFromIdToken(e) {
		B(e.length !== 0, "internal-error");
		let t = On(e);
		this.updateTokensAndExpiration(e, null, t);
	}
	async getToken(e, t = !1) {
		return !t && this.accessToken && !this.isExpired ? this.accessToken : (B(this.refreshToken, e, "user-token-expired"), this.refreshToken ? (await this.refresh(e, this.refreshToken), this.accessToken) : null);
	}
	clearRefreshToken() {
		this.refreshToken = null;
	}
	async refresh(e, t) {
		let { accessToken: n, refreshToken: r, expiresIn: i } = await Ln(e, t);
		this.updateTokensAndExpiration(n, r, Number(i));
	}
	updateTokensAndExpiration(e, t, n) {
		this.refreshToken = t || null, this.accessToken = e || null, this.expirationTime = Date.now() + n * 1e3;
	}
	static fromJSON(t, n) {
		let { refreshToken: r, accessToken: i, expirationTime: a } = n, o = new e();
		return r && (B(typeof r == "string", "internal-error", { appName: t }), o.refreshToken = r), i && (B(typeof i == "string", "internal-error", { appName: t }), o.accessToken = i), a && (B(typeof a == "number", "internal-error", { appName: t }), o.expirationTime = a), o;
	}
	toJSON() {
		return {
			refreshToken: this.refreshToken,
			accessToken: this.accessToken,
			expirationTime: this.expirationTime
		};
	}
	_assign(e) {
		this.accessToken = e.accessToken, this.refreshToken = e.refreshToken, this.expirationTime = e.expirationTime;
	}
	_clone() {
		return Object.assign(new e(), this.toJSON());
	}
	_performRefresh() {
		return V("not implemented");
	}
};
function G(e, t) {
	B(typeof e == "string" || e === void 0, "internal-error", { appName: t });
}
var K = class e {
	constructor({ uid: e, auth: t, stsTokenManager: n, ...r }) {
		this.providerId = "firebase", this.proactiveRefresh = new jn(this), this.reloadUserInfo = null, this.reloadListener = null, this.uid = e, this.auth = t, this.stsTokenManager = n, this.accessToken = n.accessToken, this.displayName = r.displayName || null, this.email = r.email || null, this.emailVerified = r.emailVerified || !1, this.phoneNumber = r.phoneNumber || null, this.photoURL = r.photoURL || null, this.isAnonymous = r.isAnonymous || !1, this.tenantId = r.tenantId || null, this.providerData = r.providerData ? [...r.providerData] : [], this.metadata = new Mn(r.createdAt || void 0, r.lastLoginAt || void 0);
	}
	async getIdToken(e) {
		let t = await kn(this, this.stsTokenManager.getToken(this.auth, e));
		return B(t, this.auth, "internal-error"), this.accessToken !== t && (this.accessToken = t, await this.auth._persistUserIfCurrent(this), this.auth._notifyListenersIfCurrent(this)), t;
	}
	getIdTokenResult(e) {
		return Tn(this, e);
	}
	reload() {
		return Pn(this);
	}
	_assign(e) {
		this !== e && (B(this.uid === e.uid, this.auth, "internal-error"), this.displayName = e.displayName, this.photoURL = e.photoURL, this.email = e.email, this.emailVerified = e.emailVerified, this.phoneNumber = e.phoneNumber, this.isAnonymous = e.isAnonymous, this.tenantId = e.tenantId, this.providerData = e.providerData.map((e) => ({ ...e })), this.metadata._copy(e.metadata), this.stsTokenManager._assign(e.stsTokenManager));
	}
	_clone(t) {
		let n = new e({
			...this,
			auth: t,
			stsTokenManager: this.stsTokenManager._clone()
		});
		return n.metadata._copy(this.metadata), n;
	}
	_onReload(e) {
		B(!this.reloadListener, this.auth, "internal-error"), this.reloadListener = e, this.reloadUserInfo &&= (this._notifyReloadListener(this.reloadUserInfo), null);
	}
	_notifyReloadListener(e) {
		this.reloadListener ? this.reloadListener(e) : this.reloadUserInfo = e;
	}
	_startProactiveRefresh() {
		this.proactiveRefresh._start();
	}
	_stopProactiveRefresh() {
		this.proactiveRefresh._stop();
	}
	async _updateTokensIfNecessary(e, t = !1) {
		let n = !1;
		e.idToken && e.idToken !== this.stsTokenManager.accessToken && (this.stsTokenManager.updateFromServerResponse(e), n = !0), t && await Nn(this), await this.auth._persistUserIfCurrent(this), n && this.auth._notifyListenersIfCurrent(this);
	}
	async delete() {
		if (j(this.auth.app)) return Promise.reject(z(this.auth));
		let e = await this.getIdToken();
		return await kn(this, Cn(this.auth, { idToken: e })), this.stsTokenManager.clearRefreshToken(), this.auth.signOut();
	}
	toJSON() {
		return {
			uid: this.uid,
			email: this.email || void 0,
			emailVerified: this.emailVerified,
			displayName: this.displayName || void 0,
			isAnonymous: this.isAnonymous,
			photoURL: this.photoURL || void 0,
			phoneNumber: this.phoneNumber || void 0,
			tenantId: this.tenantId || void 0,
			providerData: this.providerData.map((e) => ({ ...e })),
			stsTokenManager: this.stsTokenManager.toJSON(),
			_redirectEventId: this._redirectEventId,
			...this.metadata.toJSON(),
			apiKey: this.auth.config.apiKey,
			appName: this.auth.name
		};
	}
	get refreshToken() {
		return this.stsTokenManager.refreshToken || "";
	}
	static _fromJSON(t, n) {
		let r = n.displayName ?? void 0, i = n.email ?? void 0, a = n.phoneNumber ?? void 0, o = n.photoURL ?? void 0, s = n.tenantId ?? void 0, c = n._redirectEventId ?? void 0, l = n.createdAt ?? void 0, u = n.lastLoginAt ?? void 0, { uid: d, emailVerified: f, isAnonymous: p, providerData: m, stsTokenManager: ee } = n;
		B(d && ee, t, "internal-error");
		let h = zn.fromJSON(this.name, ee);
		B(typeof d == "string", t, "internal-error"), G(r, t.name), G(i, t.name), B(typeof f == "boolean", t, "internal-error"), B(typeof p == "boolean", t, "internal-error"), G(a, t.name), G(o, t.name), G(s, t.name), G(c, t.name), G(l, t.name), G(u, t.name);
		let g = new e({
			uid: d,
			auth: t,
			email: i,
			emailVerified: f,
			displayName: r,
			isAnonymous: p,
			photoURL: o,
			phoneNumber: a,
			tenantId: s,
			stsTokenManager: h,
			createdAt: l,
			lastLoginAt: u
		});
		return m && Array.isArray(m) && (g.providerData = m.map((e) => ({ ...e }))), c && (g._redirectEventId = c), g;
	}
	static async _fromIdTokenResponse(t, n, r = !1) {
		let i = new zn();
		i.updateFromServerResponse(n);
		let a = new e({
			uid: n.localId,
			auth: t,
			stsTokenManager: i,
			isAnonymous: r
		});
		return await Nn(a), a;
	}
	static async _fromGetAccountInfoResponse(t, n, r) {
		let i = n.users[0];
		B(i.localId !== void 0, "internal-error");
		let a = i.providerUserInfo === void 0 ? [] : In(i.providerUserInfo), o = !(i.email && i.passwordHash) && !a?.length, s = new zn();
		s.updateFromIdToken(r);
		let c = new e({
			uid: i.localId,
			auth: t,
			stsTokenManager: s,
			isAnonymous: o
		}), l = {
			uid: i.localId,
			displayName: i.displayName || null,
			photoURL: i.photoUrl || null,
			email: i.email || null,
			emailVerified: i.emailVerified || !1,
			phoneNumber: i.phoneNumber || null,
			tenantId: i.tenantId || null,
			providerData: a,
			metadata: new Mn(i.createdAt, i.lastLoginAt),
			isAnonymous: !(i.email && i.passwordHash) && !a?.length
		};
		return Object.assign(c, l), c;
	}
}, Bn = /* @__PURE__ */ new Map();
function q(e) {
	nn(e instanceof Function, "Expected a class definition");
	let t = Bn.get(e);
	return t ? (nn(t instanceof e, "Instance stored in cache mismatched with class"), t) : (t = new e(), Bn.set(e, t), t);
}
var Vn = class {
	constructor() {
		this.type = "NONE", this.storage = {};
	}
	async _isAvailable() {
		return !0;
	}
	async _set(e, t) {
		this.storage[e] = t;
	}
	async _get(e) {
		let t = this.storage[e];
		return t === void 0 ? null : t;
	}
	async _remove(e) {
		delete this.storage[e];
	}
	_addListener(e, t) {}
	_removeListener(e, t) {}
};
Vn.type = "NONE";
var Hn = Vn;
function Un(e, t, n) {
	return `firebase:${e}:${t}:${n}`;
}
var Wn = class e {
	constructor(e, t, n) {
		this.persistence = e, this.auth = t, this.userKey = n;
		let { config: r, name: i } = this.auth;
		this.fullUserKey = Un(this.userKey, r.apiKey, i), this.fullPersistenceKey = Un("persistence", r.apiKey, i), this.boundEventHandler = t._onStorageEvent.bind(t);
		try {
			this.persistence._addListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	setCurrentUser(e) {
		return this.persistence._set(this.fullUserKey, e.toJSON());
	}
	async getCurrentUser() {
		let e = await this.persistence._get(this.fullUserKey);
		if (!e) return null;
		if (typeof e == "string") {
			let t = await wn(this.auth, { idToken: e }).catch(() => void 0);
			return t ? K._fromGetAccountInfoResponse(this.auth, t, e) : null;
		}
		return K._fromJSON(this.auth, e);
	}
	removeCurrentUser() {
		return this.persistence._remove(this.fullUserKey);
	}
	savePersistenceForRedirect() {
		return this.persistence._set(this.fullPersistenceKey, this.persistence.type);
	}
	async setPersistence(e) {
		if (this.persistence === e) return;
		let t = await this.getCurrentUser();
		if (await this.removeCurrentUser(), this.persistence = e, t) return this.setCurrentUser(t);
	}
	delete() {
		try {
			this.persistence._removeListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	static async create(t, n, r = "authUser") {
		if (!n.length) return new e(q(Hn), t, r);
		let i = (await Promise.all(n.map(async (e) => {
			try {
				if (await e._isAvailable()) return e;
			} catch {
				return;
			}
		}))).filter((e) => e), a = i[0] || q(Hn), o = Un(r, t.config.apiKey, t.name), s = null;
		for (let e of n) try {
			let n = await e._get(o);
			if (n) {
				let r;
				if (typeof n == "string") {
					let e = await wn(t, { idToken: n }).catch(() => void 0);
					if (!e) break;
					r = await K._fromGetAccountInfoResponse(t, e, n);
				} else r = K._fromJSON(t, n);
				e !== a && (s = r), a = e;
				break;
			}
		} catch {}
		let c = i.filter((e) => e._shouldAllowMigration);
		return !a._shouldAllowMigration || !c.length ? new e(a, t, r) : (a = c[0], s && await a._set(o, s.toJSON()), await Promise.all(n.map(async (e) => {
			if (e !== a) try {
				await e._remove(o);
			} catch {}
		})), new e(a, t, r));
	}
};
function Gn(e) {
	let t = e.toLowerCase();
	if (t.includes("opera/") || t.includes("opr/") || t.includes("opios/")) return "Opera";
	if (Yn(t)) return "IEMobile";
	if (t.includes("msie") || t.includes("trident/")) return "IE";
	if (t.includes("edge/")) return "Edge";
	if (Kn(t)) return "Firefox";
	if (t.includes("silk/")) return "Silk";
	if (Zn(t)) return "Blackberry";
	if (Qn(t)) return "Webos";
	if (qn(t)) return "Safari";
	if ((t.includes("chrome/") || Jn(t)) && !t.includes("edge/")) return "Chrome";
	if (Xn(t)) return "Android";
	{
		let t = e.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
		if (t?.length === 2) return t[1];
	}
	return "Other";
}
function Kn(e = _()) {
	return /firefox\//i.test(e);
}
function qn(e = _()) {
	let t = e.toLowerCase();
	return t.includes("safari/") && !t.includes("chrome/") && !t.includes("crios/") && !t.includes("android");
}
function Jn(e = _()) {
	return /crios\//i.test(e);
}
function Yn(e = _()) {
	return /iemobile/i.test(e);
}
function Xn(e = _()) {
	return /android/i.test(e);
}
function Zn(e = _()) {
	return /blackberry/i.test(e);
}
function Qn(e = _()) {
	return /webos/i.test(e);
}
function $n(e, t = []) {
	let n;
	switch (e) {
		case "Browser":
			n = Gn(_());
			break;
		case "Worker":
			n = `${Gn(_())}-${e}`;
			break;
		default: n = e;
	}
	let r = t.length ? t.join(",") : "FirebaseCore-web";
	return `${n}/JsCore/${Mt}/${r}`;
}
var er = class {
	constructor(e) {
		this.auth = e, this.queue = [];
	}
	pushCallback(e, t) {
		let n = (t) => new Promise((n, r) => {
			try {
				n(e(t));
			} catch (e) {
				r(e);
			}
		});
		n.onAbort = t, this.queue.push(n);
		let r = this.queue.length - 1;
		return () => {
			this.queue[r] = () => Promise.resolve();
		};
	}
	async runMiddleware(e) {
		if (this.auth.currentUser === e) return;
		let t = [];
		try {
			for (let n of this.queue) await n(e), n.onAbort && t.push(n.onAbort);
		} catch (e) {
			t.reverse();
			for (let e of t) try {
				e();
			} catch {}
			throw this.auth._errorFactory.create("login-blocked", { originalMessage: e?.message });
		}
	}
};
async function tr(e, t = {}) {
	return U(e, "GET", "/v2/passwordPolicy", H(e, t));
}
var nr = 6, rr = class {
	constructor(e) {
		let t = e.customStrengthOptions;
		this.customStrengthOptions = {}, this.customStrengthOptions.minPasswordLength = t.minPasswordLength ?? nr, t.maxPasswordLength && (this.customStrengthOptions.maxPasswordLength = t.maxPasswordLength), t.containsLowercaseCharacter !== void 0 && (this.customStrengthOptions.containsLowercaseLetter = t.containsLowercaseCharacter), t.containsUppercaseCharacter !== void 0 && (this.customStrengthOptions.containsUppercaseLetter = t.containsUppercaseCharacter), t.containsNumericCharacter !== void 0 && (this.customStrengthOptions.containsNumericCharacter = t.containsNumericCharacter), t.containsNonAlphanumericCharacter !== void 0 && (this.customStrengthOptions.containsNonAlphanumericCharacter = t.containsNonAlphanumericCharacter), this.enforcementState = e.enforcementState, this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED" && (this.enforcementState = "OFF"), this.allowedNonAlphanumericCharacters = e.allowedNonAlphanumericCharacters?.join("") ?? "", this.forceUpgradeOnSignin = e.forceUpgradeOnSignin ?? !1, this.schemaVersion = e.schemaVersion;
	}
	validatePassword(e) {
		let t = {
			isValid: !0,
			passwordPolicy: this
		};
		return this.validatePasswordLengthOptions(e, t), this.validatePasswordCharacterOptions(e, t), t.isValid &&= t.meetsMinPasswordLength ?? !0, t.isValid &&= t.meetsMaxPasswordLength ?? !0, t.isValid &&= t.containsLowercaseLetter ?? !0, t.isValid &&= t.containsUppercaseLetter ?? !0, t.isValid &&= t.containsNumericCharacter ?? !0, t.isValid &&= t.containsNonAlphanumericCharacter ?? !0, t;
	}
	validatePasswordLengthOptions(e, t) {
		let n = this.customStrengthOptions.minPasswordLength, r = this.customStrengthOptions.maxPasswordLength;
		n && (t.meetsMinPasswordLength = e.length >= n), r && (t.meetsMaxPasswordLength = e.length <= r);
	}
	validatePasswordCharacterOptions(e, t) {
		this.updatePasswordCharacterOptionsStatuses(t, !1, !1, !1, !1);
		let n;
		for (let r = 0; r < e.length; r++) n = e.charAt(r), this.updatePasswordCharacterOptionsStatuses(t, n >= "a" && n <= "z", n >= "A" && n <= "Z", n >= "0" && n <= "9", this.allowedNonAlphanumericCharacters.includes(n));
	}
	updatePasswordCharacterOptionsStatuses(e, t, n, r, i) {
		this.customStrengthOptions.containsLowercaseLetter && (e.containsLowercaseLetter ||= t), this.customStrengthOptions.containsUppercaseLetter && (e.containsUppercaseLetter ||= n), this.customStrengthOptions.containsNumericCharacter && (e.containsNumericCharacter ||= r), this.customStrengthOptions.containsNonAlphanumericCharacter && (e.containsNonAlphanumericCharacter ||= i);
	}
}, ir = class {
	constructor(e, t, n, r) {
		this.app = e, this.heartbeatServiceProvider = t, this.appCheckServiceProvider = n, this.config = r, this.currentUser = null, this.emulatorConfig = null, this.operations = Promise.resolve(), this.authStateSubscription = new or(this), this.idTokenSubscription = new or(this), this.beforeStateQueue = new er(this), this.redirectUser = null, this.isProactiveRefreshEnabled = !1, this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1, this._canInitEmulator = !0, this._isInitialized = !1, this._deleted = !1, this._initializationPromise = null, this._popupRedirectResolver = null, this._errorFactory = Qt, this._agentRecaptchaConfig = null, this._tenantRecaptchaConfigs = {}, this._projectPasswordPolicy = null, this._tenantPasswordPolicies = {}, this._resolvePersistenceManagerAvailable = void 0, this.lastNotifiedUid = void 0, this.languageCode = null, this.tenantId = null, this.settings = { appVerificationDisabledForTesting: !1 }, this.frameworks = [], this.name = e.name, this.clientVersion = r.sdkClientVersion, this._persistenceManagerAvailable = new Promise((e) => this._resolvePersistenceManagerAvailable = e);
	}
	_initializeWithPersistence(e, t) {
		return t && (this._popupRedirectResolver = q(t)), this._initializationPromise = this.queue(async () => {
			if (!this._deleted) {
				try {
					this.persistenceManager = await Wn.create(this, e);
				} catch (e) {
					I(`Failed to initialize persistence: ${e}`), this.persistenceManager = await Wn.create(this, []);
				} finally {
					this._resolvePersistenceManagerAvailable?.();
				}
				if (!this._deleted) {
					if (this._popupRedirectResolver?._shouldInitProactively) try {
						await this._popupRedirectResolver._initialize(this);
					} catch {}
					try {
						await this.initializeCurrentUser(t);
					} catch (e) {
						I(`Failed to initialize current user: ${e}`), await this.directlySetCurrentUser(null).catch(() => {});
					}
					this.lastNotifiedUid = this.currentUser?.uid || null, !this._deleted && (this._isInitialized = !0);
				}
			}
		}), this._initializationPromise;
	}
	async _onStorageEvent() {
		if (this._deleted) return;
		let e = await this.assertedPersistence.getCurrentUser();
		if (this.currentUser || e) {
			if (this.currentUser && e && this.currentUser.uid === e.uid) {
				this._currentUser._assign(e), await this.currentUser.getIdToken();
				return;
			}
			await this._updateCurrentUser(e, !0);
		}
	}
	async initializeCurrentUserFromIdToken(e) {
		try {
			let t = await wn(this, { idToken: e }), n = await K._fromGetAccountInfoResponse(this, t, e);
			await this.directlySetCurrentUser(n);
		} catch (e) {
			console.warn("FirebaseServerApp could not login user with provided authIdToken: ", e), await this.directlySetCurrentUser(null);
		}
	}
	async initializeCurrentUser(e) {
		if (j(this.app)) {
			let e = this.app.settings.authIdToken;
			return e ? new Promise((t) => {
				setTimeout(() => this.initializeCurrentUserFromIdToken(e).then(t, t));
			}) : this.directlySetCurrentUser(null);
		}
		let t = await this.assertedPersistence.getCurrentUser(), n = t, r = !1;
		if (e && this.config.authDomain) {
			await this.getOrInitRedirectPersistenceManager();
			let t = this.redirectUser?._redirectEventId, i = n?._redirectEventId, a = await this.tryRedirectSignIn(e);
			(!t || t === i) && a?.user && (n = a.user, r = !0);
		}
		if (!n) return this.directlySetCurrentUser(null);
		if (!n._redirectEventId) {
			if (r) try {
				await this.beforeStateQueue.runMiddleware(n);
			} catch (e) {
				n = t, this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(e));
			}
			return n ? this.reloadAndSetCurrentUserOrClear(n) : this.directlySetCurrentUser(null);
		}
		return B(this._popupRedirectResolver, this, "argument-error"), await this.getOrInitRedirectPersistenceManager(), this.redirectUser && this.redirectUser._redirectEventId === n._redirectEventId ? this.directlySetCurrentUser(n) : this.reloadAndSetCurrentUserOrClear(n);
	}
	async tryRedirectSignIn(e) {
		let t = null;
		try {
			t = await this._popupRedirectResolver._completeRedirectFn(this, e, !0);
		} catch {
			await this._setRedirectUser(null);
		}
		return t;
	}
	async reloadAndSetCurrentUserOrClear(e) {
		try {
			await Nn(e);
		} catch (e) {
			let t = e?.code;
			if (t !== "auth/network-request-failed" && t !== "auth/too-many-requests" && !t?.startsWith("auth/quota-exceeded")) return this.directlySetCurrentUser(null);
		}
		return this.directlySetCurrentUser(e);
	}
	useDeviceLanguage() {
		this.languageCode = sn();
	}
	async _delete() {
		this._deleted = !0;
	}
	async updateCurrentUser(e) {
		if (j(this.app)) return Promise.reject(z(this));
		let t = e ? w(e) : null;
		return t && B(t.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token"), this._updateCurrentUser(t && t._clone(this));
	}
	async _updateCurrentUser(e, t = !1) {
		if (!this._deleted) return e && B(this.tenantId === e.tenantId, this, "tenant-id-mismatch"), t || await this.beforeStateQueue.runMiddleware(e), this.queue(async () => {
			await this.directlySetCurrentUser(e), this.notifyAuthListeners();
		});
	}
	async signOut() {
		return j(this.app) ? Promise.reject(z(this)) : (await this.beforeStateQueue.runMiddleware(null), (this.redirectPersistenceManager || this._popupRedirectResolver) && await this._setRedirectUser(null), this._updateCurrentUser(null, !0));
	}
	setPersistence(e) {
		return j(this.app) ? Promise.reject(z(this)) : this.queue(async () => {
			await this.assertedPersistence.setPersistence(q(e));
		});
	}
	_getRecaptchaConfig() {
		return this.tenantId == null ? this._agentRecaptchaConfig : this._tenantRecaptchaConfigs[this.tenantId];
	}
	async validatePassword(e) {
		this._getPasswordPolicyInternal() || await this._updatePasswordPolicy();
		let t = this._getPasswordPolicyInternal();
		return t.schemaVersion === this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION ? t.validatePassword(e) : Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {}));
	}
	_getPasswordPolicyInternal() {
		return this.tenantId === null ? this._projectPasswordPolicy : this._tenantPasswordPolicies[this.tenantId];
	}
	async _updatePasswordPolicy() {
		let e = new rr(await tr(this));
		this.tenantId === null ? this._projectPasswordPolicy = e : this._tenantPasswordPolicies[this.tenantId] = e;
	}
	_getPersistenceType() {
		return this.assertedPersistence.persistence.type;
	}
	_getPersistence() {
		return this.assertedPersistence.persistence;
	}
	_updateErrorMap(e) {
		this._errorFactory = new b("auth", "Firebase", e());
	}
	onAuthStateChanged(e, t, n) {
		return this.registerStateListener(this.authStateSubscription, e, t, n);
	}
	beforeAuthStateChanged(e, t) {
		return this.beforeStateQueue.pushCallback(e, t);
	}
	onIdTokenChanged(e, t, n) {
		return this.registerStateListener(this.idTokenSubscription, e, t, n);
	}
	authStateReady() {
		return new Promise((e, t) => {
			if (this.currentUser) e();
			else {
				let n = this.onAuthStateChanged(() => {
					n(), e();
				}, t);
			}
		});
	}
	async revokeAccessToken(e) {
		if (this.currentUser) {
			let t = {
				providerId: "apple.com",
				tokenType: "ACCESS_TOKEN",
				token: e,
				idToken: await this.currentUser.getIdToken()
			};
			this.tenantId != null && (t.tenantId = this.tenantId), await Rn(this, t);
		}
	}
	toJSON() {
		return {
			apiKey: this.config.apiKey,
			authDomain: this.config.authDomain,
			appName: this.name,
			currentUser: this._currentUser?.toJSON()
		};
	}
	async _setRedirectUser(e, t) {
		let n = await this.getOrInitRedirectPersistenceManager(t);
		return e === null ? n.removeCurrentUser() : n.setCurrentUser(e);
	}
	async getOrInitRedirectPersistenceManager(e) {
		if (!this.redirectPersistenceManager) {
			let t = e && q(e) || this._popupRedirectResolver;
			B(t, this, "argument-error"), this.redirectPersistenceManager = await Wn.create(this, [q(t._redirectPersistence)], "redirectUser"), this.redirectUser = await this.redirectPersistenceManager.getCurrentUser();
		}
		return this.redirectPersistenceManager;
	}
	async _redirectUserForId(e) {
		return this._isInitialized && await this.queue(async () => {}), this._currentUser?._redirectEventId === e ? this._currentUser : this.redirectUser?._redirectEventId === e ? this.redirectUser : null;
	}
	async _persistUserIfCurrent(e) {
		if (e === this.currentUser) return this.queue(async () => this.directlySetCurrentUser(e));
	}
	_notifyListenersIfCurrent(e) {
		e === this.currentUser && this.notifyAuthListeners();
	}
	_key() {
		return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
	}
	_startProactiveRefresh() {
		this.isProactiveRefreshEnabled = !0, this.currentUser && this._currentUser._startProactiveRefresh();
	}
	_stopProactiveRefresh() {
		this.isProactiveRefreshEnabled = !1, this.currentUser && this._currentUser._stopProactiveRefresh();
	}
	get _currentUser() {
		return this.currentUser;
	}
	notifyAuthListeners() {
		if (!this._isInitialized) return;
		this.idTokenSubscription.next(this.currentUser);
		let e = this.currentUser?.uid ?? null;
		this.lastNotifiedUid !== e && (this.lastNotifiedUid = e, this.authStateSubscription.next(this.currentUser));
	}
	registerStateListener(e, t, n, r) {
		if (this._deleted) return () => {};
		let i = typeof t == "function" ? t : t.next.bind(t), a = !1, o = this._isInitialized ? Promise.resolve() : this._initializationPromise;
		if (B(o, this, "internal-error"), o.then(() => {
			a || i(this.currentUser);
		}).catch((e) => {
			if (!a) {
				if (typeof t != "function" && t.error) t.error(e);
				else if (n) n(e);
				else throw e;
			}
		}), typeof t == "function") {
			let i = e.addObserver(t, n, r);
			return () => {
				a = !0, i();
			};
		}
		{
			let n = e.addObserver(t);
			return () => {
				a = !0, n();
			};
		}
	}
	async directlySetCurrentUser(e) {
		if (this.currentUser && this.currentUser !== e && this._currentUser._stopProactiveRefresh(), e && this.isProactiveRefreshEnabled && e._startProactiveRefresh(), this.currentUser = e, this.persistenceManager) try {
			e ? await this.persistenceManager.setCurrentUser(e) : await this.persistenceManager.removeCurrentUser();
		} catch (e) {
			let t = e?.message || String(e), n = en(this, "internal-error", `An internal AuthError has occurred: ${t}`);
			throw n.customData = { originalError: e }, n;
		}
	}
	queue(e) {
		return this.operations = this.operations.then(e, e), this.operations;
	}
	get assertedPersistence() {
		return B(this.persistenceManager, this, "internal-error"), this.persistenceManager;
	}
	_logFramework(e) {
		e && !this.frameworks.includes(e) && (this.frameworks.push(e), this.frameworks.sort(), this.clientVersion = $n(this.config.clientPlatform, this._getFrameworks()));
	}
	_getFrameworks() {
		return this.frameworks;
	}
	async _getAdditionalHeaders() {
		let e = { "X-Client-Version": this.clientVersion };
		this.app.options.appId && (e["X-Firebase-gmpid"] = this.app.options.appId);
		let t = await this.heartbeatServiceProvider.getImmediate({ optional: !0 })?.getHeartbeatsHeader();
		t && (e["X-Firebase-Client"] = t);
		let n = await this._getAppCheckToken();
		return n && (e["X-Firebase-AppCheck"] = n), e;
	}
	async _getAppCheckToken() {
		if (j(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
		let e = await this.appCheckServiceProvider.getImmediate({ optional: !0 })?.getToken();
		return e?.error && I(`Error while retrieving App Check token: ${e.error}`), e?.token;
	}
};
function ar(e) {
	return w(e);
}
var or = class {
	constructor(e) {
		this.auth = e, this.observer = null, this.addObserver = ue((e) => this.observer = e);
	}
	get next() {
		return B(this.observer, this.auth, "internal-error"), this.observer.next.bind(this.observer);
	}
}, sr = {
	async loadJS() {
		throw Error("Unable to load external scripts");
	},
	recaptchaV2Script: "",
	recaptchaEnterpriseScript: "",
	gapiScript: ""
};
function cr(e) {
	return sr.loadJS(e);
}
function lr() {
	return sr.recaptchaEnterpriseScript;
}
var ur = class {
	constructor() {
		this.enterprise = new dr();
	}
	ready(e) {
		e();
	}
	execute(e, t) {
		return Promise.resolve("token");
	}
	render(e, t) {
		return "";
	}
}, dr = class {
	ready(e) {
		e();
	}
	execute(e, t) {
		return Promise.resolve("token");
	}
	render(e, t) {
		return "";
	}
}, fr = "recaptcha-enterprise", pr = "NO_RECAPTCHA", mr = "onFirebaseAuthREInstanceReady", hr = class e {
	constructor(e) {
		this.type = fr, this.auth = ar(e);
	}
	async verify(t = "verify", n = !1) {
		async function r(e) {
			if (!n) {
				if (e.tenantId == null && e._agentRecaptchaConfig != null) return e._agentRecaptchaConfig.siteKey;
				if (e.tenantId != null && e._tenantRecaptchaConfigs[e.tenantId] !== void 0) return e._tenantRecaptchaConfigs[e.tenantId].siteKey;
			}
			return new Promise(async (t, n) => {
				Sn(e, {
					clientType: "CLIENT_TYPE_WEB",
					version: "RECAPTCHA_ENTERPRISE"
				}).then((r) => {
					if (r.recaptchaKey === void 0) n(/* @__PURE__ */ Error("recaptcha Enterprise site key undefined"));
					else {
						let n = new xn(r);
						return e.tenantId == null ? e._agentRecaptchaConfig = n : e._tenantRecaptchaConfigs[e.tenantId] = n, t(n.siteKey);
					}
				}).catch((e) => {
					n(e);
				});
			});
		}
		function i(e, n, r) {
			let i = window.grecaptcha;
			bn(i) ? i.enterprise.ready(() => {
				i.enterprise.execute(e, { action: t }).then((e) => {
					n(e);
				}).catch(() => {
					n(pr);
				});
			}) : r(Error("No reCAPTCHA enterprise script loaded."));
		}
		return this.auth.settings.appVerificationDisabledForTesting ? new ur().execute("siteKey", { action: "verify" }) : new Promise((t, a) => {
			r(this.auth).then(async (r) => {
				if (!n && bn(window.grecaptcha) && e.scriptInjectionDeferred) await e.scriptInjectionDeferred.promise, i(r, t, a);
				else {
					if (typeof window > "u") {
						a(/* @__PURE__ */ Error("RecaptchaVerifier is only supported in browser"));
						return;
					}
					let n = lr();
					n.length !== 0 && (n += r + `&onload=${mr}`), e.scriptInjectionDeferred = new g(), window[mr] = () => {
						e.scriptInjectionDeferred?.resolve();
					}, cr(n).then(() => e.scriptInjectionDeferred?.promise).then(() => {
						i(r, t, a);
					}).catch((e) => {
						a(e);
					});
				}
			}).catch((e) => {
				a(e);
			});
		});
	}
};
hr.scriptInjectionDeferred = null;
async function J(e, t, n, r = !1, i = !1) {
	let a = new hr(e), o;
	if (i) o = pr;
	else try {
		o = await a.verify(n);
	} catch {
		o = await a.verify(n, !0);
	}
	let s = { ...t };
	if (n === "mfaSmsEnrollment" || n === "mfaSmsSignIn") {
		if ("phoneEnrollmentInfo" in s) {
			let e = s.phoneEnrollmentInfo.phoneNumber, t = s.phoneEnrollmentInfo.recaptchaToken;
			Object.assign(s, { phoneEnrollmentInfo: {
				phoneNumber: e,
				recaptchaToken: t,
				captchaResponse: o,
				clientType: "CLIENT_TYPE_WEB",
				recaptchaVersion: "RECAPTCHA_ENTERPRISE"
			} });
		} else if ("phoneSignInInfo" in s) {
			let e = s.phoneSignInInfo.recaptchaToken;
			Object.assign(s, { phoneSignInInfo: {
				recaptchaToken: e,
				captchaResponse: o,
				clientType: "CLIENT_TYPE_WEB",
				recaptchaVersion: "RECAPTCHA_ENTERPRISE"
			} });
		}
		return s;
	}
	return r ? Object.assign(s, { captchaResp: o }) : Object.assign(s, { captchaResponse: o }), Object.assign(s, { clientType: "CLIENT_TYPE_WEB" }), Object.assign(s, { recaptchaVersion: "RECAPTCHA_ENTERPRISE" }), s;
}
async function gr(e, t, n, r, i) {
	return i === "EMAIL_PASSWORD_PROVIDER" ? e._getRecaptchaConfig()?.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") ? r(e, await J(e, t, n, n === "getOobCode")) : r(e, t).catch(async (i) => i.code === "auth/missing-recaptcha-token" ? (console.log(`${n} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`), r(e, await J(e, t, n, n === "getOobCode"))) : Promise.reject(i)) : i === "PHONE_PROVIDER" ? e._getRecaptchaConfig()?.isProviderEnabled("PHONE_PROVIDER") ? r(e, await J(e, t, n)).catch(async (i) => e._getRecaptchaConfig()?.getProviderEnforcementState("PHONE_PROVIDER") === "AUDIT" && (i.code === "auth/missing-recaptcha-token" || i.code === "auth/invalid-app-credential") ? (console.log(`Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${n} flow.`), r(e, await J(e, t, n, !1, !0))) : Promise.reject(i)) : r(e, await J(e, t, n, !1, !0)) : Promise.reject(i + " provider is not supported.");
}
function _r(e, t) {
	let n = At(e, "auth");
	if (n.isInitialized()) {
		let e = n.getImmediate();
		if (x(n.getOptions(), t ?? {})) return e;
		R(e, "already-initialized");
	}
	return n.initialize({ options: t });
}
function vr(e, t) {
	let n = t?.persistence || [], r = (Array.isArray(n) ? n : [n]).map(q);
	t?.errorMap && e._updateErrorMap(t.errorMap), e._initializeWithPersistence(r, t?.popupRedirectResolver);
}
var yr = class {
	constructor(e, t) {
		this.providerId = e, this.signInMethod = t;
	}
	toJSON() {
		return V("not implemented");
	}
	_getIdTokenResponse(e) {
		return V("not implemented");
	}
	_linkToIdToken(e, t) {
		return V("not implemented");
	}
	_getReauthenticationResolver(e) {
		return V("not implemented");
	}
};
async function br(e, t) {
	return U(e, "POST", "/v1/accounts:signUp", t);
}
async function xr(e, t) {
	return hn(e, "POST", "/v1/accounts:signInWithPassword", H(e, t));
}
async function Sr(e, t) {
	return hn(e, "POST", "/v1/accounts:signInWithEmailLink", H(e, t));
}
async function Cr(e, t) {
	return hn(e, "POST", "/v1/accounts:signInWithEmailLink", H(e, t));
}
var wr = class e extends yr {
	constructor(e, t, n, r = null) {
		super("password", n), this._email = e, this._password = t, this._tenantId = r;
	}
	static _fromEmailAndPassword(t, n) {
		return new e(t, n, "password");
	}
	static _fromEmailAndCode(t, n, r = null) {
		return new e(t, n, "emailLink", r);
	}
	toJSON() {
		return {
			email: this._email,
			password: this._password,
			signInMethod: this.signInMethod,
			tenantId: this._tenantId
		};
	}
	static fromJSON(e) {
		let t = typeof e == "string" ? JSON.parse(e) : e;
		if (t?.email && t?.password) {
			if (t.signInMethod === "password") return this._fromEmailAndPassword(t.email, t.password);
			if (t.signInMethod === "emailLink") return this._fromEmailAndCode(t.email, t.password, t.tenantId);
		}
		return null;
	}
	async _getIdTokenResponse(e) {
		switch (this.signInMethod) {
			case "password": return gr(e, {
				returnSecureToken: !0,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signInWithPassword", xr, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return Sr(e, {
				email: this._email,
				oobCode: this._password
			});
			default: R(e, "internal-error");
		}
	}
	async _linkToIdToken(e, t) {
		switch (this.signInMethod) {
			case "password": return gr(e, {
				idToken: t,
				returnSecureToken: !0,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signUpPassword", br, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return Cr(e, {
				idToken: t,
				email: this._email,
				oobCode: this._password
			});
			default: R(e, "internal-error");
		}
	}
	_getReauthenticationResolver(e) {
		return this._getIdTokenResponse(e);
	}
};
async function Tr(e, t) {
	return hn(e, "POST", "/v1/accounts:signInWithIdp", H(e, t));
}
var Er = "http://localhost", Dr = class e extends yr {
	constructor() {
		super(...arguments), this.pendingToken = null;
	}
	static _fromParams(t) {
		let n = new e(t.providerId, t.signInMethod);
		return t.idToken || t.accessToken ? (t.idToken && (n.idToken = t.idToken), t.accessToken && (n.accessToken = t.accessToken), t.nonce && !t.pendingToken && (n.nonce = t.nonce), t.pendingToken && (n.pendingToken = t.pendingToken)) : t.oauthToken && t.oauthTokenSecret ? (n.accessToken = t.oauthToken, n.secret = t.oauthTokenSecret) : R("argument-error"), n;
	}
	toJSON() {
		return {
			idToken: this.idToken,
			accessToken: this.accessToken,
			secret: this.secret,
			nonce: this.nonce,
			pendingToken: this.pendingToken,
			providerId: this.providerId,
			signInMethod: this.signInMethod
		};
	}
	static fromJSON(t) {
		let { providerId: n, signInMethod: r, ...i } = typeof t == "string" ? JSON.parse(t) : t;
		if (!n || !r) return null;
		let a = new e(n, r);
		return a.idToken = i.idToken || void 0, a.accessToken = i.accessToken || void 0, a.secret = i.secret, a.nonce = i.nonce, a.pendingToken = i.pendingToken || null, a;
	}
	_getIdTokenResponse(e) {
		return Tr(e, this.buildRequest());
	}
	_linkToIdToken(e, t) {
		let n = this.buildRequest();
		return n.idToken = t, Tr(e, n);
	}
	_getReauthenticationResolver(e) {
		let t = this.buildRequest();
		return t.autoCreate = !1, Tr(e, t);
	}
	buildRequest() {
		let e = {
			requestUri: Er,
			returnSecureToken: !0
		};
		if (this.pendingToken) e.pendingToken = this.pendingToken;
		else {
			let t = {};
			this.idToken && (t.id_token = this.idToken), this.accessToken && (t.access_token = this.accessToken), this.secret && (t.oauth_token_secret = this.secret), t.providerId = this.providerId, this.nonce && !this.pendingToken && (t.nonce = this.nonce), e.postBody = le(t);
		}
		return e;
	}
};
function Or(e) {
	switch (e) {
		case "recoverEmail": return "RECOVER_EMAIL";
		case "resetPassword": return "PASSWORD_RESET";
		case "signIn": return "EMAIL_SIGNIN";
		case "verifyEmail": return "VERIFY_EMAIL";
		case "verifyAndChangeEmail": return "VERIFY_AND_CHANGE_EMAIL";
		case "revertSecondFactorAddition": return "REVERT_SECOND_FACTOR_ADDITION";
		default: return null;
	}
}
function kr(e) {
	let t = S(C(e)).link, n = t ? S(C(t)).deep_link_id : null, r = S(C(e)).deep_link_id;
	return (r ? S(C(r)).link : null) || r || n || t || e;
}
var Ar = class e {
	constructor(e) {
		let t = S(C(e)), n = t.apiKey ?? null, r = t.oobCode ?? null, i = Or(t.mode ?? null);
		B(n && r && i, "argument-error"), this.apiKey = n, this.operation = i, this.code = r, this.continueUrl = t.continueUrl ?? null, this.languageCode = t.lang ?? null, this.tenantId = t.tenantId ?? null;
	}
	static parseLink(t) {
		let n = kr(t);
		try {
			return new e(n);
		} catch {
			return null;
		}
	}
}, jr = class e {
	constructor() {
		this.providerId = e.PROVIDER_ID;
	}
	static credential(e, t) {
		return wr._fromEmailAndPassword(e, t);
	}
	static credentialWithLink(e, t) {
		let n = Ar.parseLink(t);
		return B(n, "argument-error"), wr._fromEmailAndCode(e, n.code, n.tenantId);
	}
};
jr.PROVIDER_ID = "password", jr.EMAIL_PASSWORD_SIGN_IN_METHOD = "password", jr.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
var Mr = class {
	constructor(e) {
		this.providerId = e, this.defaultLanguageCode = null, this.customParameters = {};
	}
	setDefaultLanguage(e) {
		this.defaultLanguageCode = e;
	}
	setCustomParameters(e) {
		return this.customParameters = e, this;
	}
	getCustomParameters() {
		return this.customParameters;
	}
}, Nr = class extends Mr {
	constructor() {
		super(...arguments), this.scopes = [];
	}
	addScope(e) {
		return this.scopes.includes(e) || this.scopes.push(e), this;
	}
	getScopes() {
		return [...this.scopes];
	}
}, Pr = class e extends Nr {
	constructor() {
		super("facebook.com");
	}
	static credential(t) {
		return Dr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.FACEBOOK_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
Pr.FACEBOOK_SIGN_IN_METHOD = "facebook.com", Pr.PROVIDER_ID = "facebook.com";
var Fr = class e extends Nr {
	constructor() {
		super("google.com"), this.addScope("profile");
	}
	static credential(t, n) {
		return Dr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GOOGLE_SIGN_IN_METHOD,
			idToken: t,
			accessToken: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthIdToken: n, oauthAccessToken: r } = t;
		if (!n && !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
Fr.GOOGLE_SIGN_IN_METHOD = "google.com", Fr.PROVIDER_ID = "google.com";
var Ir = class e extends Nr {
	constructor() {
		super("github.com");
	}
	static credential(t) {
		return Dr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GITHUB_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
Ir.GITHUB_SIGN_IN_METHOD = "github.com", Ir.PROVIDER_ID = "github.com";
var Lr = class e extends Nr {
	constructor() {
		super("twitter.com");
	}
	static credential(t, n) {
		return Dr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.TWITTER_SIGN_IN_METHOD,
			oauthToken: t,
			oauthTokenSecret: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthAccessToken: n, oauthTokenSecret: r } = t;
		if (!n || !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
Lr.TWITTER_SIGN_IN_METHOD = "twitter.com", Lr.PROVIDER_ID = "twitter.com";
var Rr = class e {
	constructor(e) {
		this.user = e.user, this.providerId = e.providerId, this._tokenResponse = e._tokenResponse, this.operationType = e.operationType;
	}
	static async _fromIdTokenResponse(t, n, r, i = !1) {
		let a = await K._fromIdTokenResponse(t, r, i), o = zr(r);
		return new e({
			user: a,
			providerId: o,
			_tokenResponse: r,
			operationType: n
		});
	}
	static async _forOperation(t, n, r) {
		await t._updateTokensIfNecessary(r, !0);
		let i = zr(r);
		return new e({
			user: t,
			providerId: i,
			_tokenResponse: r,
			operationType: n
		});
	}
};
function zr(e) {
	return e.providerId ? e.providerId : "phoneNumber" in e ? "phone" : null;
}
var Br = class e extends y {
	constructor(t, n, r, i) {
		super(n.code, n.message), this.operationType = r, this.user = i, Object.setPrototypeOf(this, e.prototype), this.customData = {
			appName: t.name,
			tenantId: t.tenantId ?? void 0,
			_serverResponse: n.customData._serverResponse,
			operationType: r
		};
	}
	static _fromErrorAndOperation(t, n, r, i) {
		return new e(t, n, r, i);
	}
};
function Vr(e, t, n, r) {
	return (t === "reauthenticate" ? n._getReauthenticationResolver(e) : n._getIdTokenResponse(e)).catch((n) => {
		throw n.code === "auth/multi-factor-auth-required" ? Br._fromErrorAndOperation(e, n, t, r) : n;
	});
}
async function Hr(e, t, n = !1) {
	if (j(e.app)) return Promise.reject(z(e));
	let r = "signIn", i = await Vr(e, r, t), a = await Rr._fromIdTokenResponse(e, r, i);
	return n || await e._updateCurrentUser(a.user), a;
}
async function Ur(e, t) {
	return Hr(ar(e), t);
}
async function Wr(e) {
	let t = ar(e);
	t._getPasswordPolicyInternal() && await t._updatePasswordPolicy();
}
function Gr(e, t, n) {
	return j(e.app) ? Promise.reject(z(e)) : Ur(w(e), jr.credential(t, n)).catch(async (t) => {
		throw t.code === "auth/password-does-not-meet-requirements" && Wr(e), t;
	});
}
function Kr(e, t, n, r) {
	return w(e).onAuthStateChanged(t, n, r);
}
function qr(e) {
	return w(e).signOut();
}
var Jr = "__sak";
function Yr(e) {
	return Promise.all(e.map(async (e) => {
		try {
			return {
				fulfilled: !0,
				value: await e
			};
		} catch (e) {
			return {
				fulfilled: !1,
				reason: e
			};
		}
	}));
}
var Xr = class e {
	constructor(e) {
		this.eventTarget = e, this.handlersMap = {}, this.boundEventHandler = this.handleEvent.bind(this);
	}
	static _getInstance(t) {
		let n = this.receivers.find((e) => e.isListeningto(t));
		if (n) return n;
		let r = new e(t);
		return this.receivers.push(r), r;
	}
	isListeningto(e) {
		return this.eventTarget === e;
	}
	async handleEvent(e) {
		let t = e, { eventId: n, eventType: r, data: i } = t.data, a = this.handlersMap[r];
		if (!a?.size) return;
		t.ports[0].postMessage({
			status: "ack",
			eventId: n,
			eventType: r
		});
		let o = await Yr(Array.from(a).map(async (e) => e(t.origin, i)));
		t.ports[0].postMessage({
			status: "done",
			eventId: n,
			eventType: r,
			response: o
		});
	}
	_subscribe(e, t) {
		Object.keys(this.handlersMap).length === 0 && this.eventTarget.addEventListener("message", this.boundEventHandler), this.handlersMap[e] || (this.handlersMap[e] = /* @__PURE__ */ new Set()), this.handlersMap[e].add(t);
	}
	_unsubscribe(e, t) {
		this.handlersMap[e] && t && this.handlersMap[e].delete(t), (!t || this.handlersMap[e].size === 0) && delete this.handlersMap[e], Object.keys(this.handlersMap).length === 0 && this.eventTarget.removeEventListener("message", this.boundEventHandler);
	}
};
Xr.receivers = [];
function Zr(e = "", t = 10) {
	let n = "";
	for (let e = 0; e < t; e++) n += Math.floor(Math.random() * 10);
	return e + n;
}
var Qr = class {
	constructor(e) {
		this.target = e, this.handlers = /* @__PURE__ */ new Set();
	}
	removeMessageHandler(e) {
		e.messageChannel && (e.messageChannel.port1.removeEventListener("message", e.onMessage), e.messageChannel.port1.close()), this.handlers.delete(e);
	}
	async _send(e, t, n = 50) {
		let r = typeof MessageChannel < "u" ? new MessageChannel() : null;
		if (!r) throw Error("connection_unavailable");
		let i, a;
		return new Promise((o, s) => {
			let c = Zr("", 20);
			r.port1.start();
			let l = setTimeout(() => {
				s(/* @__PURE__ */ Error("unsupported_event"));
			}, n);
			a = {
				messageChannel: r,
				onMessage(e) {
					let t = e;
					if (t.data.eventId === c) switch (t.data.status) {
						case "ack":
							clearTimeout(l), i = setTimeout(() => {
								s(/* @__PURE__ */ Error("timeout"));
							}, 3e3);
							break;
						case "done":
							clearTimeout(i), o(t.data.response);
							break;
						default: clearTimeout(l), clearTimeout(i), s(/* @__PURE__ */ Error("invalid_response"));
					}
				}
			}, this.handlers.add(a), r.port1.addEventListener("message", a.onMessage), this.target.postMessage({
				eventType: e,
				eventId: c,
				data: t
			}, [r.port2]);
		}).finally(() => {
			a && this.removeMessageHandler(a);
		});
	}
};
function $r() {
	return window;
}
function ei() {
	return $r().WorkerGlobalScope !== void 0 && typeof $r().importScripts == "function";
}
async function ti() {
	if (!navigator?.serviceWorker) return null;
	try {
		return (await navigator.serviceWorker.ready).active;
	} catch {
		return null;
	}
}
function ni() {
	return navigator?.serviceWorker?.controller || null;
}
function ri() {
	return ei() ? self : null;
}
var ii = "firebaseLocalStorageDb", ai = 1, oi = "firebaseLocalStorage", si = "fbase_key", Y = class {
	constructor(e) {
		this.request = e;
	}
	toPromise() {
		return new Promise((e, t) => {
			this.request.addEventListener("success", () => {
				e(this.request.result);
			}), this.request.addEventListener("error", () => {
				t(this.request.error);
			});
		});
	}
};
function ci(e, t) {
	return e.transaction([oi], t ? "readwrite" : "readonly").objectStore(oi);
}
function li() {
	return new Y(indexedDB.deleteDatabase(ii)).toPromise();
}
function ui() {
	let e = indexedDB.open(ii, ai);
	return new Promise((t, n) => {
		e.addEventListener("error", () => {
			n(e.error);
		}), e.addEventListener("upgradeneeded", () => {
			let t = e.result;
			try {
				t.createObjectStore(oi, { keyPath: si });
			} catch (e) {
				n(e);
			}
		}), e.addEventListener("success", async () => {
			let n = e.result;
			n.objectStoreNames.contains(oi) ? t(n) : (n.close(), await li(), t(await ui()));
		});
	});
}
async function di(e, t, n) {
	return new Y(ci(e, !0).put({
		[si]: t,
		value: n
	})).toPromise();
}
async function fi(e, t) {
	let n = await new Y(ci(e, !1).get(t)).toPromise();
	return n === void 0 ? null : n.value;
}
function pi(e, t) {
	return new Y(ci(e, !0).delete(t)).toPromise();
}
var mi = 800, hi = 3, gi = class {
	registerLifecycleListeners() {
		typeof window < "u" && typeof window.addEventListener == "function" && (window.addEventListener("pagehide", this.onPageHide), window.addEventListener("pageshow", this.onPageShow));
	}
	unregisterLifecycleListeners() {
		typeof window < "u" && typeof window.removeEventListener == "function" && (window.removeEventListener("pagehide", this.onPageHide), window.removeEventListener("pageshow", this.onPageShow));
	}
	constructor() {
		this.type = "LOCAL", this.dbPromise = null, this._shouldAllowMigration = !0, this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.isClosing = !1, this.pendingWrites = 0, this.receiver = null, this.sender = null, this.serviceWorkerReceiverAvailable = !1, this.activeServiceWorker = null, this.onPageHide = () => {
			this.isClosing = !0, this.stopPolling(), this.dbPromise &&= (this.dbPromise.then((e) => e.close()).catch(() => {}), null);
		}, this.onPageShow = () => {
			this.isClosing && (this.isClosing = !1, Object.keys(this.listeners).length > 0 && this.startPolling());
		}, this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {});
	}
	async _openDb() {
		return this.dbPromise ? this.dbPromise : (this.dbPromise = ui(), this.dbPromise.catch(() => {
			this.dbPromise = null;
		}), this.dbPromise);
	}
	async _withRetries(e) {
		let t = 0;
		for (;;) try {
			return await e(await this._openDb());
		} catch (e) {
			if (t++ > hi) throw e;
			if (this.dbPromise) {
				let e = this.dbPromise;
				this.dbPromise = null;
				try {
					(await e).close();
				} catch {}
			}
		}
	}
	async initializeServiceWorkerMessaging() {
		return ei() ? this.initializeReceiver() : this.initializeSender();
	}
	async initializeReceiver() {
		this.receiver = Xr._getInstance(ri()), this.receiver._subscribe("keyChanged", async (e, t) => ({ keyProcessed: (await this._poll()).includes(t.key) })), this.receiver._subscribe("ping", async (e, t) => ["keyChanged"]);
	}
	async initializeSender() {
		if (this.activeServiceWorker = await ti(), !this.activeServiceWorker) return;
		this.sender = new Qr(this.activeServiceWorker);
		let e = await this.sender._send("ping", {}, 800);
		e && e[0]?.fulfilled && e[0]?.value.includes("keyChanged") && (this.serviceWorkerReceiverAvailable = !0);
	}
	async notifyServiceWorker(e) {
		if (this.sender && this.activeServiceWorker && ni() === this.activeServiceWorker) try {
			await this.sender._send("keyChanged", { key: e }, this.serviceWorkerReceiverAvailable ? 800 : 50);
		} catch {}
	}
	async _isAvailable() {
		try {
			return indexedDB ? (await this._withRetries(async (e) => {
				await di(e, Jr, "1"), await pi(e, Jr);
			}), !0) : !1;
		} catch {}
		return !1;
	}
	async _withPendingWrite(e) {
		this.pendingWrites++;
		try {
			await e();
		} finally {
			this.pendingWrites--;
		}
	}
	async _set(e, t) {
		return this._withPendingWrite(async () => (await this._withRetries((n) => di(n, e, t)), this.localCache[e] = t, this.notifyServiceWorker(e)));
	}
	async _get(e) {
		let t = await this._withRetries((t) => fi(t, e));
		return this.localCache[e] = t, t;
	}
	async _remove(e) {
		return this._withPendingWrite(async () => (await this._withRetries((t) => pi(t, e)), delete this.localCache[e], this.notifyServiceWorker(e)));
	}
	async _poll() {
		if (this.isClosing) return [];
		try {
			let e = await this._withRetries((e) => new Y(ci(e, !1).getAll()).toPromise());
			if (this.isClosing || !e || this.pendingWrites !== 0) return [];
			let t = [], n = /* @__PURE__ */ new Set();
			if (e.length !== 0) for (let { fbase_key: r, value: i } of e) n.add(r), JSON.stringify(this.localCache[r]) !== JSON.stringify(i) && (this.notifyListeners(r, i), t.push(r));
			for (let e of Object.keys(this.localCache)) this.localCache[e] && !n.has(e) && (this.notifyListeners(e, null), t.push(e));
			return t;
		} catch (e) {
			return this.isClosing || I(`Firebase Auth cross-tab polling failed with error: ${e}`), [];
		}
	}
	notifyListeners(e, t) {
		this.localCache[e] = t;
		let n = this.listeners[e];
		if (n) for (let e of Array.from(n)) e(t);
	}
	startPolling() {
		this.stopPolling(), this.pollTimer = setInterval(async () => this._poll(), mi);
	}
	stopPolling() {
		this.pollTimer &&= (clearInterval(this.pollTimer), null);
	}
	_addListener(e, t) {
		Object.keys(this.listeners).length === 0 && (this.startPolling(), this.registerLifecycleListeners()), this.listeners[e] || (this.listeners[e] = /* @__PURE__ */ new Set(), this._get(e)), this.listeners[e].add(t);
	}
	_removeListener(e, t) {
		this.listeners[e] && (this.listeners[e].delete(t), this.listeners[e].size === 0 && delete this.listeners[e]), Object.keys(this.listeners).length === 0 && (this.stopPolling(), this.unregisterLifecycleListeners());
	}
};
gi.type = "LOCAL";
var _i = gi, vi = "@firebase/auth", yi = "1.13.7", bi = class {
	constructor(e) {
		this.auth = e, this.internalListeners = /* @__PURE__ */ new Map();
	}
	getUid() {
		return this.assertAuthConfigured(), this.auth.currentUser?.uid || null;
	}
	async getToken(e) {
		return this.assertAuthConfigured(), await this.auth._initializationPromise, this.auth.currentUser ? { accessToken: await this.auth.currentUser.getIdToken(e) } : null;
	}
	addAuthTokenListener(e) {
		if (this.assertAuthConfigured(), this.internalListeners.has(e)) return;
		let t = this.auth.onIdTokenChanged((t) => {
			e(t?.stsTokenManager.accessToken || null);
		});
		this.internalListeners.set(e, t), this.updateProactiveRefresh();
	}
	removeAuthTokenListener(e) {
		this.assertAuthConfigured();
		let t = this.internalListeners.get(e);
		t && (this.internalListeners.delete(e), t(), this.updateProactiveRefresh());
	}
	assertAuthConfigured() {
		B(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth");
	}
	updateProactiveRefresh() {
		this.internalListeners.size > 0 ? this.auth._startProactiveRefresh() : this.auth._stopProactiveRefresh();
	}
};
function xi(e) {
	switch (e) {
		case "Node": return "node";
		case "ReactNative": return "rn";
		case "Worker": return "webworker";
		case "Cordova": return "cordova";
		case "WebExtension": return "web-extension";
		default: return;
	}
}
function Si(e) {
	A(new T("auth", (t, { options: n }) => {
		let r = t.getProvider("app").getImmediate(), i = t.getProvider("heartbeat"), a = t.getProvider("app-check-internal"), { apiKey: o, authDomain: s } = r.options;
		B(o && !o.includes(":"), "invalid-api-key", { appName: r.name });
		let c = new ir(r, i, a, {
			apiKey: o,
			authDomain: s,
			clientPlatform: e,
			apiHost: "identitytoolkit.googleapis.com",
			tokenApiHost: "securetoken.googleapis.com",
			apiScheme: "https",
			sdkClientVersion: $n(e)
		});
		return vr(c, n), c;
	}, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e, t, n) => {
		e.getProvider("auth-internal").initialize();
	})), A(new T("auth-internal", (e) => ((e) => new bi(e))(ar(e.getProvider("auth").getImmediate())), "PRIVATE").setInstantiationMode("EXPLICIT")), N(vi, yi, xi(e)), N(vi, yi, "esm2020");
}
//#endregion
//#region node_modules/.pnpm/@firebase+auth@1.13.7_@firebase+app@0.16.3/node_modules/@firebase/auth/dist/web-extension-esm/index.js
Si("WebExtension");
//#endregion
//#region browser-extension/firestore-codec.js
function Ci(e) {
	if (!e || "nullValue" in e) return null;
	if ("stringValue" in e) return e.stringValue;
	if ("integerValue" in e) return Number(e.integerValue);
	if ("doubleValue" in e) return e.doubleValue;
	if ("booleanValue" in e) return e.booleanValue;
	if ("timestampValue" in e) return Date.parse(e.timestampValue);
	if ("arrayValue" in e) return (e.arrayValue.values ?? []).map(Ci);
	if ("mapValue" in e) return Object.fromEntries(Object.entries(e.mapValue.fields ?? {}).map(([e, t]) => [e, Ci(t)]));
	throw Error("Unsupported Firebase field");
}
function X(e) {
	return Ci({ mapValue: { fields: e.fields ?? {} } });
}
function Z(e) {
	if (e === null) return { nullValue: null };
	if (typeof e == "string") return { stringValue: e };
	if (typeof e == "boolean") return { booleanValue: e };
	if (typeof e == "number" && Number.isSafeInteger(e)) return { integerValue: String(e) };
	if (Array.isArray(e)) return { arrayValue: { values: e.map(Z) } };
	if (e && typeof e == "object") return { mapValue: { fields: Object.fromEntries(Object.entries(e).map(([e, t]) => [e, Z(t)])) } };
	throw Error("Unsupported Firebase value");
}
//#endregion
//#region shared/study-focus.ts
var wi = () => Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
function Ti(e = Date.now(), t = wi()) {
	let n = new Intl.DateTimeFormat("en-US", {
		timeZone: t,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(e);
	return [
		"year",
		"month",
		"day"
	].map((e) => n.find((t) => t.type === e).value).join("-");
}
function Ei(e, t = Date.now(), n = !1) {
	if (!e || typeof e.id != "string" || !e.id || !Number.isSafeInteger(e.startedAt) || !Number.isSafeInteger(e.endsAt) || e.endsAt <= e.startedAt || e.endsAt - e.startedAt > 432e5) return [];
	let r = e.timeZone || wi(), i = Math.min(t, e.endsAt, e.paused ? e.pausedAt ?? e.startedAt : e.endsAt), a = [], o = e.startedAt;
	for (; o < i;) {
		let t = Ti(o, r), s = i;
		if (Ti(i - 1, r) !== t) {
			let e = o, n = i;
			for (; n - e > 1;) {
				let i = Math.floor((e + n) / 2);
				Ti(i, r) === t ? e = i : n = i;
			}
			s = n;
		}
		let c = s - o, l = n && s === i && i < e.endsAt && !e.paused ? Math.floor(c / 6e4) * 6e4 : c;
		l > 0 && a.push({
			date: t,
			milliseconds: l
		}), o = s;
	}
	return a;
}
function Di(e, t, n) {
	let r = { ...e?.sessionCredits ?? {} }, i = Number(r[t]) || 0, a = Math.max(i, n);
	return r[t] = a, {
		totalMilliseconds: Math.max(0, Number(e?.totalMilliseconds) || 0) + a - i,
		sessionCredits: r
	};
}
var Oi = [
	"instagram.com",
	"facebook.com",
	"fb.com",
	"x.com",
	"twitter.com",
	"reddit.com",
	"snapchat.com",
	"tiktok.com",
	"threads.net",
	"threads.com",
	"pinterest.com",
	"linkedin.com",
	"discord.com",
	"discord.gg",
	"telegram.org",
	"t.me",
	"twitch.tv"
], ki = (e, t) => e === t || e.endsWith(`.${t}`), Ai = (e) => Oi.some((t) => ki(e, t));
function Q(e) {
	let t = e.trim(), n = new URL(t.includes("://") ? t : `https://${t}`), r = n.hostname.toLowerCase().replace(/\.$/, "");
	if (!["http:", "https:"].includes(n.protocol) || n.username || n.password || r.length > 253 || !r.includes(".") || /^\d+(\.\d+){3}$/.test(r) || r.endsWith(".localhost") || r.split(".").some((e) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(e))) throw Error("Enter a domain like parmar.com.");
	return r;
}
function ji(e) {
	let t = [...new Set(e.map(Q))];
	if (t.some(Ai)) throw Error("Social media websites cannot be added.");
	if (t.length > 2) throw Error("Maximum 2 websites per session.");
	return { domains: t };
}
//#endregion
//#region browser-extension/policy.js
var Mi = [
	1,
	2,
	3
];
function $(e, t = Date.now()) {
	if (e === null) return null;
	if (!e || typeof e.id != "string" || !Number.isSafeInteger(e.startedAt) || !Number.isSafeInteger(e.endsAt) || e.endsAt <= e.startedAt || e.endsAt - e.startedAt > 432e5 || !Array.isArray(e.domains) || e.domains.length > 64 || e.paused !== void 0 && e.paused !== !0) throw Error("Invalid study session");
	if (e.appLimit !== void 0 && (!Number.isInteger(e.appLimit) || e.appLimit < 0 || e.appLimit > 2)) throw Error("Invalid allowed app limit");
	if (e.lockId !== void 0 && (typeof e.lockId != "string" || !e.lockId.length || e.lockId.length > 128)) throw Error("Invalid study session");
	if (e.paused && (!Number.isSafeInteger(e.remainingMs) || e.remainingMs < 1 || e.remainingMs > 432e5 || !Number.isSafeInteger(e.pausedAt))) throw Error("Invalid paused study session");
	if (e.breakLimit !== void 0 && (!Number.isInteger(e.breakLimit) || e.breakLimit < 0 || e.breakLimit > 23 || !Number.isInteger(e.breaksTaken) || e.breaksTaken < 0 || e.breaksTaken > e.breakLimit)) throw Error("Invalid break allowance");
	if (e.breakUntil !== void 0 && (!e.paused || e.breakLimit === void 0 || !Number.isSafeInteger(e.breakUntil) || e.breakUntil - e.pausedAt !== 6e5 || e.remainingMs !== e.endsAt - e.pausedAt)) throw Error("Invalid break deadline");
	for (let t of e.domains) if (typeof t != "string" || t.length > 253 || !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(t) || /^\d+(\.\d+){3}$/.test(t)) throw Error("Invalid allowed website");
	let r = n({
		id: e.id,
		startedAt: e.startedAt,
		endsAt: e.endsAt,
		domains: e.domains.slice(0, 2),
		...e.appLimit === void 0 ? {} : { appLimit: e.appLimit },
		...e.lockId ? { lockId: e.lockId } : {},
		...e.timeZone ? { timeZone: e.timeZone } : {},
		...e.breakLimit === void 0 ? {} : {
			breakLimit: e.breakLimit,
			breaksTaken: e.breaksTaken
		},
		...e.breakUntil === void 0 ? {} : { breakUntil: e.breakUntil },
		...e.paused ? {
			paused: !0,
			pausedAt: e.pausedAt,
			remainingMs: e.remainingMs
		} : {}
	}, t);
	return r.paused || r.endsAt > t ? r : null;
}
function Ni(e) {
	return ji([String(e).trim()]).domains[0] ?? (() => {
		throw Error("Enter a website domain.");
	})();
}
function Pi(e, t, r = !1, i = Date.now()) {
	e = {
		...e,
		session: e.session ? n(e.session, i) : null
	};
	let a = Q(String(t).trim()), o = e.session && (e.session.paused || e.session.endsAt > i);
	if (o && r) throw Error("Websites stay locked until the timer ends.");
	let s = (o ? e.session.domains : e.allowedDomains ?? []).slice(0, 2), { domains: c } = ji(r ? s.filter((e) => e !== a) : [.../* @__PURE__ */ new Set([...s, a])]);
	return {
		...e,
		version: 1,
		revision: crypto.randomUUID(),
		session: o ? {
			...e.session,
			domains: c
		} : null,
		allowedDomains: c,
		source: "extension"
	};
}
function Fi(t, r, i = Date.now()) {
	if (t = {
		...t,
		session: t.session ? n(t.session, i) : null
	}, !Number.isInteger(r) || r < 1 || r > 720) throw Error("Choose 1 minute to 12 hours.");
	if (t.session && (t.session.paused || t.session.endsAt > i)) throw Error("Your session is already running.");
	let { domains: a } = ji((t.allowedDomains ?? []).slice(0, 2));
	if (!a.length) throw Error("Add a website first.");
	return {
		...t,
		version: 1,
		revision: crypto.randomUUID(),
		source: "extension",
		session: {
			id: crypto.randomUUID(),
			startedAt: i,
			endsAt: i + r * 6e4,
			domains: a,
			timeZone: wi(),
			breakLimit: e(r),
			breaksTaken: 0
		}
	};
}
function Ii(e, t) {
	try {
		let n = new URL(e);
		return ["https:", "http:"].includes(n.protocol) && t.some((e) => n.hostname === e || n.hostname.endsWith(`.${e}`));
	} catch {
		return !1;
	}
}
function Li(e, n = "") {
	return !e || t(e) ? [] : [{
		id: 1,
		priority: 1,
		action: {
			type: "redirect",
			redirect: n ? { regexSubstitution: `${n}#site=\\1` } : { extensionPath: "/blocked.html" }
		},
		condition: {
			regexFilter: "^(https?://.*)$",
			resourceTypes: ["main_frame"]
		}
	}, ...e.domains.length ? [{
		id: 2,
		priority: 2,
		action: { type: "allow" },
		condition: {
			requestDomains: e.domains,
			resourceTypes: ["main_frame"]
		}
	}] : []];
}
//#endregion
//#region shared/focus-rewards.ts
var Ri = 6e5, zi = (e) => Number.isFinite(Number(e)) ? Math.floor(Math.max(0, Number(e) || 0) / Ri) : 0, Bi = (e = {}) => Object.values(e).reduce((e, t) => e + zi(t), 0);
function Vi(e) {
	let t = /* @__PURE__ */ new Date(`${e}T12:00:00Z`);
	return !Number.isFinite(t.getTime()) || t.toISOString().slice(0, 10) !== e ? "" : (t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 6) % 7), t.toISOString().slice(0, 10));
}
function Hi(e, t, n, r) {
	let i = Vi(n);
	return {
		uid: e,
		username: String(t.username ?? "").trim().toLowerCase(),
		name: String(t.name || "Student"),
		...t.avatar ? { avatar: t.avatar } : {},
		week: i,
		focusDays: Object.fromEntries(Object.entries(r).filter(([e]) => /^\d{4}-\d{2}-\d{2}$/.test(e) && Vi(e) === i)),
		focusXp: Bi(r)
	};
}
//#endregion
//#region browser-extension/cloud.js
function Ui() {
	let e = {
		apiKey: "AIzaSyBKS04pXofLZ18RDLYIlPvo8Mkba2mqIKQ",
		authDomain: "ssc-buddy-e73d7.firebaseapp.com",
		projectId: "ssc-buddy-e73d7",
		appId: "1:541181826831:web:75cb1de57a5db2affc507a"
	};
	if (!e.apiKey || !e.projectId || !e.appId) throw Error("The extension is not configured. Please install the latest version.");
	let t = _r(Nt(e), { persistence: _i }), r = new Promise((e) => {
		let n = Kr(t, () => {
			n(), e();
		});
	}), i = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(e.projectId)}/databases/(default)/documents`;
	async function a(e, n = {}, a, o, s) {
		await r;
		let c = t.currentUser;
		if (!c || a && c.uid !== a) throw Error("Sign in to your SSC Buddy account.");
		let l = await c.getIdToken(), u = s ? `${i}/leaderboards/${encodeURIComponent(s)}/entries/${encodeURIComponent(c.uid)}${e}` : o ? `${i}/publicProfiles/${encodeURIComponent(o)}${e}` : `${i}/users/${encodeURIComponent(c.uid)}/${e}`, d = await fetch(u, {
			...n,
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${l}`,
				...n.headers
			},
			signal: AbortSignal.timeout(8e3),
			cache: "no-store"
		});
		if (d.status === 404 && !n.method) return null;
		let f = await d.json();
		if (!d.ok) {
			let e = /* @__PURE__ */ Error(d.status === 403 ? "Sign in with your SSC Buddy account." : "Could not connect. Please try again.");
			throw e.status = d.status, e;
		}
		return f;
	}
	async function o(e, t, n) {
		let r = await a("profile/current", {}, n), i = r ? X(r) : {}, o = String(i.username ?? "").trim().toLowerCase();
		if (!/^[a-z0-9._]{3,24}$/.test(o)) return;
		let c = await a("studyFocusDays/" + e, {}, n), l = Number(c ? X(c).totalMilliseconds : 0) || 0;
		for (let r = 0; r < 4; r++) {
			let r = await a("", {}, n, o), c = r ? X(r) : null;
			if (c?.uid !== n) return;
			if (Number(c.focusDays?.[e] ?? -1) >= l && c.focusTimeZone === t) {
				await s(n, i, e, c.focusDays);
				return;
			}
			let u = {
				...c.focusDays,
				[e]: Math.max(Number(c.focusDays?.[e]) || 0, l)
			}, d = "currentDocument.updateTime=" + encodeURIComponent(r.updateTime), f = Z({
				focusDays: u,
				focusTimeZone: t || "UTC"
			}).mapValue.fields;
			try {
				await a("?updateMask.fieldPaths=focusDays&updateMask.fieldPaths=focusTimeZone&" + d, {
					method: "PATCH",
					body: JSON.stringify({ fields: f })
				}, n, o), await s(n, i, e, u);
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Could not share focus time. Please try again.");
	}
	async function s(e, t, n, r) {
		let i = Vi(n);
		for (let o = 0; o < 4; o++) {
			let o = await a("", {}, e, void 0, i), s = o ? X(o) : {}, c = Hi(e, t, n, r);
			c.focusDays = {
				...s.focusDays,
				...Object.fromEntries(Object.entries(c.focusDays).map(([e, t]) => [e, Math.max(s.focusDays?.[e] ?? 0, t)]))
			}, c.focusXp = Math.max(s.focusXp ?? 0, c.focusXp);
			let l = o ? "currentDocument.updateTime=" + encodeURIComponent(o.updateTime) : "currentDocument.exists=false", u = Object.keys(c).map((e) => "updateMask.fieldPaths=" + encodeURIComponent(e)).join("&");
			try {
				await a("?" + u + "&" + l, {
					method: "PATCH",
					body: JSON.stringify({ fields: Z(c).mapValue.fields })
				}, e, void 0, i);
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Could not update focus points. Please try again.");
	}
	async function c(e, r = Date.now()) {
		e = n(e, r);
		let i = t.currentUser?.uid;
		if (!i) throw Error("Sign in to your SSC Buddy account.");
		for (let t of Ei(e, r, !0)) {
			let n = !1;
			for (let r = 0; r < 4; r++) {
				let r = "studyFocusDays/" + t.date, o = await a(r, {}, i), s = o ? X(o) : null, c = Di(s, e.id, t.milliseconds);
				if (c.totalMilliseconds === s?.totalMilliseconds) {
					n = !0;
					break;
				}
				let l = o ? "currentDocument.updateTime=" + encodeURIComponent(o.updateTime) : "currentDocument.exists=false", u = Z({
					version: 1,
					date: t.date,
					...c
				}).mapValue.fields;
				u.updatedAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() };
				try {
					await a(r + "?" + l, {
						method: "PATCH",
						body: JSON.stringify({ fields: u })
					}, i), n = !0;
					break;
				} catch (e) {
					if (![409, 412].includes(e.status)) throw e;
				}
			}
			if (!n) throw Error("Could not save focus time. Please try again.");
			await o(t.date, e.timeZone || "UTC", i);
		}
	}
	async function l(e, t) {
		for (let n = 0; n < 4; n++) {
			let n = await a("studyLock/current"), r = n ? X(n) : {
				version: 1,
				revision: "empty",
				session: null
			}, i = Pi(r, e, t);
			r.session && r.session.endsAt <= Date.now() && await c(r.session);
			let o = n ? `currentDocument.updateTime=${encodeURIComponent(n.updateTime)}` : "currentDocument.exists=false";
			try {
				let e = Z(i).mapValue.fields;
				e.updatedAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() }, await a(`studyLock/current?${o}`, {
					method: "PATCH",
					body: JSON.stringify({ fields: e })
				});
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Your websites changed on another device. Try again.");
	}
	return {
		ready: r,
		recordFocus: c,
		user: () => t.currentUser ? {
			uid: t.currentUser.uid,
			email: t.currentUser.email
		} : null,
		subscribe: (e) => Kr(t, e),
		login: (e, n) => Gr(t, e, n),
		logout: () => qr(t),
		async read() {
			let e = await a("studyLock/current");
			return e ? X(e) : {
				version: 1,
				revision: "empty",
				session: null
			};
		},
		editWebsite: l,
		async start(e) {
			for (let t = 0; t < 4; t++) {
				let t = await a("studyLock/current"), n = t ? X(t) : {
					version: 1,
					revision: "empty",
					session: null
				}, r = Fi(n, e);
				n.session && await c(n.session);
				let i = t ? `currentDocument.updateTime=${encodeURIComponent(t.updateTime)}` : "currentDocument.exists=false";
				try {
					await a(`studyLock/current?${i}`, {
						method: "PATCH",
						body: JSON.stringify({ fields: Z(r).mapValue.fields })
					});
					return;
				} catch (e) {
					if (![409, 412].includes(e.status)) throw e;
				}
			}
			throw Error("Your session changed on another device. Try again.");
		},
		async acknowledge(e, t, n = "") {
			let r = Z({
				label: /Edg\//.test(navigator.userAgent) ? "Edge" : "Chrome",
				extensionId: chrome.runtime.id,
				sessionId: t,
				error: n,
				version: 1
			}).mapValue.fields;
			r.lastSeenAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() }, await a(`studyLockDevices/${encodeURIComponent(e)}`, {
				method: "PATCH",
				body: JSON.stringify({ fields: r })
			});
		}
	};
}
//#endregion
//#region browser-extension/worker-engine.js
function Wi(e) {
	try {
		let t = new URL(e).hash, n = t.startsWith("#site=") ? t.slice(6) : t.startsWith("#youtube=") ? t.slice(9) : "", r = new URL(/^https?:\/\//.test(n) ? n : decodeURIComponent(n));
		return ["http:", "https:"].includes(r.protocol) ? r.href : null;
	} catch {
		return null;
	}
}
function Gi(e) {
	let t = e?.code;
	if ([
		"auth/invalid-credential",
		"auth/wrong-password",
		"auth/user-not-found",
		"auth/invalid-email",
		"auth/missing-password"
	].includes(t)) return "Check your email and password.";
	if (t === "auth/too-many-requests") return "Too many attempts. Try again later.";
	if (t === "auth/network-request-failed") return "Check your internet connection.";
	if (t?.startsWith("auth/")) return "Could not sign in. Please try again.";
	let n = e?.message ?? "";
	return /firebase|googleapis|identitytoolkit|securetoken/i.test(n) || !n ? "Could not connect. Please try again." : n;
}
function Ki(e) {
	let n = 0, r = "", i = Promise.resolve(), a, o = (e) => {
		let t = i.then(e);
		return i = t.catch(() => {}), t;
	}, s = async () => await chrome.storage.local.get(["study", "deviceId"]);
	async function c(e, n, r) {
		let { study: i } = await s();
		if (i?.session && (!e || e.id !== i.session.id)) {
			let { pendingFocus: e = [] } = await chrome.storage.local.get("pendingFocus"), t = e.filter((e) => e.uid !== i.uid || e.session.id !== i.session.id);
			t.push({
				uid: i.uid,
				session: i.session
			}), await chrome.storage.local.set({ pendingFocus: t });
		}
		let a = await chrome.declarativeNetRequest.getSessionRules();
		await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: a.filter((e) => e.id >= 1e5).map((e) => e.id) }), await chrome.declarativeNetRequest.updateDynamicRules({
			removeRuleIds: Mi,
			addRules: Li(e, chrome.runtime.getURL("blocked.html"))
		}), await chrome.storage.local.set({ study: {
			session: e,
			revision: n,
			uid: r
		} }), await chrome.alarms.clear("study-end"), e && (!e.paused || e.breakUntil) && await chrome.alarms.create("study-end", { when: e.breakUntil ?? e.endsAt }), e && !t(e) && await l(e), await chrome.action.setBadgeText({ text: t(e) ? "BREAK" : e ? "ON" : "" }), await chrome.action.setBadgeBackgroundColor({ color: "#577c3e" });
	}
	async function l(e) {
		for (let t of await chrome.tabs.query({})) t.id && /^https?:\/\//.test(t.url ?? "") && !Ii(t.url, e.domains) && await chrome.tabs.update(t.id, { url: chrome.runtime.getURL("blocked.html") + "#site=" + encodeURIComponent(t.url) }).catch(() => {});
	}
	async function u() {
		let { study: e } = await s(), t = $(e?.session ?? null);
		return e?.session && JSON.stringify(t) !== JSON.stringify(e.session) && await c(t, e.revision, e.uid), t;
	}
	async function d(e, t) {
		if (e.version !== 1 || typeof e.revision != "string" || e.revision.length > 128) throw Error("Could not load your focus session");
		let n = $(e.session), { study: r } = await s(), i = $(r?.session ?? null);
		if (i && r.uid === t) {
			let e = i.domains, t = n ? n.domains : [], r = n && e.length === n.domains.length && e.every((e) => n.domains.includes(e)), a = !i.paused && n?.paused && n.id === i.id && n.startedAt === i.startedAt && n.endsAt === i.endsAt && r, o = n && !n.paused && r && n.lockId === (i.lockId ?? i.id) && n.startedAt >= i.startedAt && n.endsAt - n.startedAt <= (i.paused ? i.remainingMs : i.endsAt - i.startedAt);
			if (!a && !o && (!n || n.id !== i.id || n.startedAt !== i.startedAt || n.endsAt !== i.endsAt || !!n.paused != !!i.paused || Number(n.remainingMs ?? 0) !== Number(i.remainingMs ?? 0) || e.some((e) => !t.includes(e)))) throw Error("Your session stays locked until its timer ends.");
		}
		let a = (n?.domains ?? e.allowedDomains ?? []).slice(0, 2);
		await chrome.storage.local.set({ websiteDraft: {
			uid: t,
			domains: a
		} });
		let { study: o } = await s();
		return (o?.uid !== t || o?.revision !== e.revision || JSON.stringify(o?.session ?? null) !== JSON.stringify(n)) && await c(n, e.revision, t), n;
	}
	async function f() {
		return a || (a = (async () => {
			await e.ready;
			let t = e.user();
			if (!t) return;
			let i = await e.read();
			if (e.user()?.uid !== t.uid) return;
			let a = await o(() => d(i, t.uid)), { deviceId: c } = await s();
			if (c || (c = crypto.randomUUID(), await chrome.storage.local.set({ deviceId: c })), await e.acknowledge(c, a?.id ?? null), n = Date.now(), r = "", e.recordFocus) try {
				i.session && await e.recordFocus(i.session);
				let { pendingFocus: n = [] } = await chrome.storage.local.get("pendingFocus");
				for (let r of n.filter((e) => e.uid === t.uid)) {
					if (e.user()?.uid !== t.uid) break;
					await e.recordFocus(r.session), await o(async () => {
						let { pendingFocus: e = [] } = await chrome.storage.local.get("pendingFocus");
						await chrome.storage.local.set({ pendingFocus: e.filter((e) => e.uid !== r.uid || e.session.id !== r.session.id) });
					});
				}
			} catch {}
		})().catch((e) => {
			r = Gi(e);
		}).finally(() => {
			a = void 0;
		}), a);
	}
	async function p() {
		let [e] = await chrome.tabs.query({
			active: !0,
			lastFocusedWindow: !0
		}), t = e?.url, n = t?.startsWith(chrome.runtime.getURL("blocked.html")) ? Wi(t) : t;
		try {
			new URL(n);
			let t = Q(n);
			return {
				tabId: e.id,
				url: n,
				domain: t,
				canAdd: !Ai(t),
				label: "Add current website"
			};
		} catch {
			return null;
		}
	}
	chrome.runtime.onMessage.addListener((t, i, s) => {
		if (i.id === chrome.runtime.id && i.url?.startsWith(chrome.runtime.getURL(""))) return (async () => {
			let s = await o(u);
			if (await e.ready, t.type === "login" || t.type === "logout") {
				if (!i.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to manage your account.");
				if (s) throw Error("Account changes are locked until your focus timer ends.");
				t.type === "login" && (await e.login(String(t.email ?? "").trim(), String(t.password ?? "")), await f()), t.type === "logout" && (await e.logout(), n = 0, await o(() => c(null, "signed-out", null)));
			} else if (t.type === "website") {
				if (!i.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to edit websites.");
				if (!e.user()) throw Error("Sign in first.");
				await e.editWebsite(Ni(t.domain), !!t.remove), a && await a, await f();
			} else if (t.type === "current-add") {
				if (!i.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to add this website.");
				let t = await p();
				if (!t?.canAdd) throw Error("This page cannot be added.");
				await e.editWebsite(t.domain, !1), a && await a, await f();
			} else if (t.type === "start") {
				if (!i.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to start a session.");
				await e.start(t.minutes), a && await a, await f();
			} else if (t.type === "site-add") {
				if (!i.url.startsWith(chrome.runtime.getURL("blocked.html"))) throw Error("Open the blocked page to add this website.");
				let t = Wi(i.url);
				if (!t) throw Error("Website unavailable.");
				let n = Q(t);
				if (Ai(n)) throw Error("This website cannot be added here.");
				await e.editWebsite(n, !1), a && await a, await f(), i.tab?.id && (await chrome.tabs.get(i.tab.id)).url === i.url && await chrome.tabs.update(i.tab.id, { url: t });
			} else if (t.type === "sync") await f();
			else if (t.type !== "status") throw Error("Unknown request");
			let l = await o(u), { websiteDraft: d } = await chrome.storage.local.get("websiteDraft"), m = e.user(), ee = m?.uid && d?.uid === m.uid ? d : null, h = (l ? l.domains : ee?.domains ?? []).slice(0, 2), g = Wi(i.url), _ = g ? new URL(g).hostname : "", v = i.url.startsWith(chrome.runtime.getURL("popup.html")) ? await p() : null;
			return v && (v.canAdd = !!e.user() && v.canAdd && h.length < 2 && !h.includes(v.domain), delete v.url, delete v.tabId), {
				session: l,
				domains: h,
				currentSite: v,
				blockedSite: _ ? {
					domain: _,
					canAdd: !!l && h.length < 2 && !Ai(_)
				} : null,
				user: m,
				connected: Date.now() - n < 65e3,
				error: r
			};
		})().then((e) => s({
			ok: !0,
			...e
		}), (e) => s({
			ok: !1,
			error: Gi(e)
		})), !0;
	}), chrome.alarms.onAlarm.addListener(() => {
		o(u).then(f).catch((e) => {
			r = Gi(e);
		});
	}), o(async () => {
		await chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
		let { study: e } = await s();
		await c($(e?.session ?? null), e?.revision ?? "empty", e?.uid ?? null), await chrome.alarms.create("study-watch", { periodInMinutes: .5 });
	}).then(() => {
		e.subscribe(() => {
			f();
		}), f();
	}).catch((e) => {
		r = String(e);
	}), setInterval(() => {
		o(u).then(f);
	}, 1e4);
}
//#endregion
//#region browser-extension/worker.js
Ki(Ui());
//#endregion
