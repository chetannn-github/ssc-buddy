//#region shared/study-breaks.ts
function e(e, t = Date.now()) {
	return !!e?.paused && Number.isSafeInteger(e.breakUntil) && e.breakUntil > t;
}
function t(e, t = Date.now()) {
	if (!e.paused || !e.breakUntil || t < e.breakUntil) return e;
	let { paused: n, pausedAt: r, remainingMs: i, breakUntil: a, ...o } = e;
	return {
		...o,
		id: `${e.lockId ?? e.id}:focus-${e.breaksTaken ?? 0}`,
		lockId: e.lockId ?? e.id,
		startedAt: a,
		endsAt: a + (i ?? 0)
	};
}
function n(n, r = Date.now()) {
	let i = t(n, r);
	return Math.max(0, e(i, r) ? i.breakUntil - r : i.paused ? i.remainingMs ?? 0 : i.endsAt - r);
}
//#endregion
//#region browser-extension/page.js
var r = (e) => document.getElementById(e);
if (r("website-count") && (r("website-count").textContent = "0/2"), r("motivation")) {
	r("motivation").classList.add("image-loading");
	try {
		let e = await (await fetch("images/manifest.json")).json();
		r("motivation").src = "images/" + encodeURIComponent(e[Math.floor(Math.random() * e.length)]), await r("motivation").decode();
	} catch {
		r("motivation").hidden = !0;
	} finally {
		r("motivation").classList.remove("image-loading");
	}
}
var i, a = !1, o = 0, s = !1;
async function c(e, t, n) {
	if (a) return !1;
	a = !0;
	let c = e?.textContent, l = [...document.querySelectorAll("button,input")].map((e) => [e, e.disabled]);
	l.forEach(([e]) => {
		e.disabled = !0;
	}), document.querySelector("main")?.setAttribute("aria-busy", "true"), e && (e.textContent = t, e.classList.add("is-loading"));
	try {
		return await n();
	} finally {
		e && (e.textContent = c, e.classList.remove("is-loading")), l.forEach(([e, t]) => {
			e.disabled = t;
		}), a = !1, document.querySelector("main")?.removeAttribute("aria-busy"), r("website-add") && (r("website-add").disabled = o >= 2), r("website-domain") && (r("website-domain").disabled = o >= 2), r("add-current") && (r("add-current").disabled = !s || o >= 2), r("start-button") && (r("start-button").disabled = o === 0 || !!i);
	}
}
function l() {
	let e = Math.max(0, Math.ceil((i ? n(i) : 0) / 1e3)), t = e ? (Math.floor(e / 3600) ? Math.floor(e / 3600) + ":" : "") + String(Math.floor(e / 60) % 60).padStart(2, "0") + ":" + String(e % 60).padStart(2, "0") : "";
	u(r("countdown"), t);
}
function u(e, t) {
	if (e.dataset.slotValue === t) return;
	let n = e.dataset.slotValue;
	e.dataset.slotValue = t, e.classList.add("focus-slot-time"), e.setAttribute("aria-label", t);
	let r = Array.from(t, (e, r) => {
		let i = n?.[n.length - t.length + r], a = document.createElement("span");
		if (!/\d/.test(e)) return a.className = "focus-slot-separator", a.textContent = e, a;
		a.className = "focus-slot";
		let o = document.createElement("span");
		return o.textContent = e, i && i !== e && (o.className = "focus-slot-roll", o.dataset.previous = i), a.append(o), a;
	});
	e.replaceChildren(...r);
}
async function d(t = "status", n = {}) {
	try {
		let u = await chrome.runtime.sendMessage({
			type: t,
			...n
		});
		if (!u?.ok) throw Error(u?.error ?? "Extension unavailable");
		i = u.session, o = (u.domains ?? i?.domains ?? []).length, r("start-session") && (r("start-session").hidden = !u.user || !!i, r("start-button").disabled = a || !o), r("approve-site") && (r("approve-site").hidden = !u.blockedSite?.canAdd, r("approve-site").textContent = "Add " + (u.blockedSite?.domain ?? "website")), document.body.classList.contains("popup") && r("motivation") && (r("motivation").hidden = !u.user), r("error").textContent = u.error ?? "", r("status").textContent = i ? e(i) ? "Break · focus resumes automatically." : i.paused ? "Focus Lock is paused. Websites stay protected." : u.connected ? "Focus Lock is active." : "Offline. Your focus timer is still running." : u.connected ? "" : u.user ? "Offline" : "", r("status").hidden = !r("status").textContent, document.body.classList.contains("blocked") && !i && (r("title").textContent = "Your focus session is complete.", r("status").textContent = "Websites are unlocked. You can return to your previous page."), r("login") && (r("login").hidden = !!u.user || !!i), r("account") && (r("account").textContent = u.user?.email ?? ""), r("login") && (r("reconnect").hidden = !u.user), r("logout") && (r("logout").hidden = !u.user || !!i), r("sites").replaceChildren();
		for (let e of i?.domains ?? []) {
			let t = document.createElement("a");
			t.href = "https://" + e, t.title = e, t.rel = "noreferrer";
			let n = document.createElement("span");
			n.className = "site-icon", n.textContent = e.replace(/^www\./, "").charAt(0).toUpperCase();
			let i = document.createElement("strong");
			i.textContent = e;
			let a = document.createElement("span");
			a.className = "site-arrow", a.textContent = "↗", a.setAttribute("aria-hidden", "true"), t.append(n, i, a), r("sites").append(t);
		}
		if (r("website-editor")) {
			let e = u.domains ?? i?.domains ?? [];
			r("website-editor").hidden = !u.user, r("website-count").textContent = e.length + "/2", r("website-form").hidden = e.length >= 2, r("website-add").disabled = a || e.length >= 2, r("website-domain").disabled = e.length >= 2;
			let t = u.currentSite;
			if (s = !!t?.canAdd, r("add-current").hidden = !t || !u.user || e.length >= 2, r("add-current").disabled = a || !t?.canAdd, !a) {
				r("add-current").replaceChildren();
				let e = document.createElement("span");
				e.textContent = t?.label ?? "Add current website";
				let n = document.createElement("small");
				n.textContent = t?.domain ?? "", r("add-current").append(e, n);
			}
			if (r("draft-sites").replaceChildren(), !i) for (let t of e) {
				let e = document.createElement("span");
				e.textContent = t, e.title = t;
				let n = document.createElement("button");
				n.type = "button", n.textContent = "×", n.setAttribute("aria-label", "Remove " + t), n.addEventListener("click", () => void c(n, "...", () => d("website", {
					domain: t,
					remove: !0
				}))), e.append(n), r("draft-sites").append(e);
			}
		}
		return l(), !0;
	} catch (e) {
		return r("error").textContent = e.message, !1;
	}
}
r("start-session")?.addEventListener("submit", async (e) => {
	e.preventDefault(), await c(r("start-button"), "Starting...", () => d("start", { minutes: Number(r("session-time").value) }));
}), r("login")?.addEventListener("submit", async (e) => {
	e.preventDefault(), await c(r("login").querySelector("button"), "Signing in...", () => d("login", {
		email: r("email").value,
		password: r("password").value
	})), r("password").value = "";
}), r("website-form")?.addEventListener("submit", async (e) => {
	e.preventDefault(), await c(r("website-add"), "Adding...", () => d("website", { domain: r("website-domain").value })) && (r("website-domain").value = "");
}), r("add-current")?.addEventListener("click", () => void c(r("add-current"), "Adding current site...", () => d("current-add"))), r("approve-site")?.addEventListener("click", () => void c(r("approve-site"), "Adding...", () => d("site-add"))), r("logout")?.addEventListener("click", () => void c(r("logout"), "Signing out...", () => d("logout"))), r("reconnect").addEventListener("click", async () => {
	await c(r("reconnect"), "Refreshing...", () => d("sync"));
}), window.addEventListener("hashchange", async () => {
	await d();
}), await d(), setInterval(() => {
	a || d();
}, 2e3), setInterval(l, 1e3);
//#endregion
