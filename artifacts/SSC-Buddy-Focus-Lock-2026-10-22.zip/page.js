//#region page.js
var e = (e) => document.getElementById(e);
if (e("website-count") && (e("website-count").textContent = "0/2"), e("motivation")) {
	e("motivation").classList.add("image-loading");
	try {
		let t = await (await fetch("images/manifest.json")).json();
		e("motivation").src = "images/" + encodeURIComponent(t[Math.floor(Math.random() * t.length)]), await e("motivation").decode();
	} catch {
		e("motivation").hidden = !0;
	} finally {
		e("motivation").classList.remove("image-loading");
	}
}
var t, n = !1, r = 0, i = !1;
async function a(a, o, s) {
	if (n) return !1;
	n = !0;
	let c = a?.textContent, l = [...document.querySelectorAll("button,input")].map((e) => [e, e.disabled]);
	l.forEach(([e]) => {
		e.disabled = !0;
	}), document.querySelector("main")?.setAttribute("aria-busy", "true"), a && (a.textContent = o, a.classList.add("is-loading"));
	try {
		return await s();
	} finally {
		a && (a.textContent = c, a.classList.remove("is-loading")), l.forEach(([e, t]) => {
			e.disabled = t;
		}), n = !1, document.querySelector("main")?.removeAttribute("aria-busy"), e("website-add") && (e("website-add").disabled = r >= 2), e("website-domain") && (e("website-domain").disabled = r >= 2), e("add-current") && (e("add-current").disabled = !i || r >= 2), e("start-button") && (e("start-button").disabled = r === 0 || !!t);
	}
}
function o() {
	let n = Math.max(0, Math.ceil((t?.paused ? Number(t.remainingMs) || 0 : (t?.endsAt ?? 0) - Date.now()) / 1e3)), r = n ? (Math.floor(n / 3600) ? Math.floor(n / 3600) + ":" : "") + String(Math.floor(n / 60) % 60).padStart(2, "0") + ":" + String(n % 60).padStart(2, "0") : "";
	s(e("countdown"), r);
}
function s(e, t) {
	if (e.dataset.slotValue === t) return;
	let n = e.dataset.slotValue;
	e.dataset.slotValue = t, e.classList.add("focus-slot-time"), e.setAttribute("aria-label", t);
	let r = Array.from(t, (e, r) => {
		let i = n?.[n.length - t.length + r], a = document.createElement("span");
		if (!/\d/.test(e)) return a.className = "focus-slot-separator", a.textContent = e, a;
		a.className = "focus-slot";
		let o = document.createElement("span");
		return o.textContent = e, i && i !== e && (o.className = "focus-slot-roll", o.dataset.previous = i), a.append(o), a;
	});
	e.replaceChildren(...r);
}
async function c(s = "status", l = {}) {
	try {
		let u = await chrome.runtime.sendMessage({
			type: s,
			...l
		});
		if (!u?.ok) throw Error(u?.error ?? "Extension unavailable");
		t = u.session, r = (u.domains ?? t?.domains ?? []).length, e("start-session") && (e("start-session").hidden = !u.user || !!t, e("start-button").disabled = n || !r), e("approve-site") && (e("approve-site").hidden = !u.blockedSite?.canAdd, e("approve-site").textContent = "Add " + (u.blockedSite?.domain ?? "website")), document.body.classList.contains("popup") && e("motivation") && (e("motivation").hidden = !u.user), e("error").textContent = u.error ?? "", e("status").textContent = t ? t.paused ? "Focus Lock is paused. Websites stay protected." : u.connected ? "Focus Lock is active." : "Offline. Your focus timer is still running." : u.connected ? "" : u.user ? "Offline" : "", e("status").hidden = !e("status").textContent, document.body.classList.contains("blocked") && !t && (e("title").textContent = "Your focus session is complete.", e("status").textContent = "Websites are unlocked. You can return to your previous page."), e("login") && (e("login").hidden = !!u.user || !!t), e("account") && (e("account").textContent = u.user?.email ?? ""), e("login") && (e("reconnect").hidden = !u.user), e("logout") && (e("logout").hidden = !u.user || !!t), e("sites").replaceChildren();
		for (let n of t?.domains ?? []) {
			let t = document.createElement("a");
			t.href = "https://" + n, t.title = n, t.rel = "noreferrer";
			let r = document.createElement("span");
			r.className = "site-icon", r.textContent = n.replace(/^www\./, "").charAt(0).toUpperCase();
			let i = document.createElement("strong");
			i.textContent = n;
			let a = document.createElement("span");
			a.className = "site-arrow", a.textContent = "↗", a.setAttribute("aria-hidden", "true"), t.append(r, i, a), e("sites").append(t);
		}
		if (e("website-editor")) {
			let r = u.domains ?? t?.domains ?? [];
			e("website-editor").hidden = !u.user, e("website-count").textContent = r.length + "/2", e("website-form").hidden = r.length >= 2, e("website-add").disabled = n || r.length >= 2, e("website-domain").disabled = r.length >= 2;
			let o = u.currentSite;
			if (i = !!o?.canAdd, e("add-current").hidden = !o || !u.user || r.length >= 2, e("add-current").disabled = n || !o?.canAdd, !n) {
				e("add-current").replaceChildren();
				let t = document.createElement("span");
				t.textContent = o?.label ?? "Add current website";
				let n = document.createElement("small");
				n.textContent = o?.domain ?? "", e("add-current").append(t, n);
			}
			if (e("draft-sites").replaceChildren(), !t) for (let t of r) {
				let n = document.createElement("span");
				n.textContent = t, n.title = t;
				let r = document.createElement("button");
				r.type = "button", r.textContent = "×", r.setAttribute("aria-label", "Remove " + t), r.addEventListener("click", () => void a(r, "...", () => c("website", {
					domain: t,
					remove: !0
				}))), n.append(r), e("draft-sites").append(n);
			}
		}
		return o(), !0;
	} catch (t) {
		return e("error").textContent = t.message, !1;
	}
}
e("start-session")?.addEventListener("submit", async (t) => {
	t.preventDefault(), await a(e("start-button"), "Starting...", () => c("start", { minutes: Number(e("session-time").value) }));
}), e("login")?.addEventListener("submit", async (t) => {
	t.preventDefault(), await a(e("login").querySelector("button"), "Signing in...", () => c("login", {
		email: e("email").value,
		password: e("password").value
	})), e("password").value = "";
}), e("website-form")?.addEventListener("submit", async (t) => {
	t.preventDefault(), await a(e("website-add"), "Adding...", () => c("website", { domain: e("website-domain").value })) && (e("website-domain").value = "");
}), e("add-current")?.addEventListener("click", () => void a(e("add-current"), "Adding current site...", () => c("current-add"))), e("approve-site")?.addEventListener("click", () => void a(e("approve-site"), "Adding...", () => c("site-add"))), e("logout")?.addEventListener("click", () => void a(e("logout"), "Signing out...", () => c("logout"))), e("reconnect").addEventListener("click", async () => {
	await a(e("reconnect"), "Refreshing...", () => c("sync"));
}), window.addEventListener("hashchange", async () => {
	await c();
}), await c(), setInterval(() => {
	n || c();
}, 2e3), setInterval(o, 1e3);
//#endregion
