//#region ../node_modules/.pnpm/@firebase+util@1.15.3/node_modules/@firebase/util/dist/postinstall.mjs
var e = () => void 0, t = function(e) {
	let t = [], n = 0;
	for (let r = 0; r < e.length; r++) {
		let i = e.charCodeAt(r);
		i < 128 ? t[n++] = i : i < 2048 ? (t[n++] = i >> 6 | 192, t[n++] = i & 63 | 128) : (i & 64512) == 55296 && r + 1 < e.length && (e.charCodeAt(r + 1) & 64512) == 56320 ? (i = 65536 + ((i & 1023) << 10) + (e.charCodeAt(++r) & 1023), t[n++] = i >> 18 | 240, t[n++] = i >> 12 & 63 | 128, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128) : (t[n++] = i >> 12 | 224, t[n++] = i >> 6 & 63 | 128, t[n++] = i & 63 | 128);
	}
	return t;
}, n = function(e) {
	let t = [], n = 0, r = 0;
	for (; n < e.length;) {
		let i = e[n++];
		if (i < 128) t[r++] = String.fromCharCode(i);
		else if (i > 191 && i < 224) {
			let a = e[n++];
			t[r++] = String.fromCharCode((i & 31) << 6 | a & 63);
		} else if (i > 239 && i < 365) {
			let a = e[n++], o = e[n++], s = e[n++], c = ((i & 7) << 18 | (a & 63) << 12 | (o & 63) << 6 | s & 63) - 65536;
			t[r++] = String.fromCharCode(55296 + (c >> 10)), t[r++] = String.fromCharCode(56320 + (c & 1023));
		} else {
			let a = e[n++], o = e[n++];
			t[r++] = String.fromCharCode((i & 15) << 12 | (a & 63) << 6 | o & 63);
		}
	}
	return t.join("");
}, r = {
	byteToCharMap_: null,
	charToByteMap_: null,
	byteToCharMapWebSafe_: null,
	charToByteMapWebSafe_: null,
	ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
	get ENCODED_VALS() {
		return this.ENCODED_VALS_BASE + "+/=";
	},
	get ENCODED_VALS_WEBSAFE() {
		return this.ENCODED_VALS_BASE + "-_.";
	},
	HAS_NATIVE_SUPPORT: typeof atob == "function",
	encodeByteArray(e, t) {
		if (!Array.isArray(e)) throw Error("encodeByteArray takes an array as a parameter");
		this.init_();
		let n = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_, r = [];
		for (let t = 0; t < e.length; t += 3) {
			let i = e[t], a = t + 1 < e.length, o = a ? e[t + 1] : 0, s = t + 2 < e.length, c = s ? e[t + 2] : 0, l = i >> 2, u = (i & 3) << 4 | o >> 4, d = (o & 15) << 2 | c >> 6, f = c & 63;
			s || (f = 64, a || (d = 64)), r.push(n[l], n[u], n[d], n[f]);
		}
		return r.join("");
	},
	encodeString(e, n) {
		return this.HAS_NATIVE_SUPPORT && !n ? btoa(e) : this.encodeByteArray(t(e), n);
	},
	decodeString(e, t) {
		return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : n(this.decodeStringToByteArray(e, t));
	},
	decodeStringToByteArray(e, t) {
		this.init_();
		let n = t ? this.charToByteMapWebSafe_ : this.charToByteMap_, r = [];
		for (let t = 0; t < e.length;) {
			let a = n[e.charAt(t++)], o = t < e.length ? n[e.charAt(t)] : 0;
			++t;
			let s = t < e.length ? n[e.charAt(t)] : 64;
			++t;
			let c = t < e.length ? n[e.charAt(t)] : 64;
			if (++t, a == null || o == null || s == null || c == null) throw new i();
			let l = a << 2 | o >> 4;
			if (r.push(l), s !== 64) {
				let e = o << 4 & 240 | s >> 2;
				if (r.push(e), c !== 64) {
					let e = s << 6 & 192 | c;
					r.push(e);
				}
			}
		}
		return r;
	},
	init_() {
		if (!this.byteToCharMap_) {
			this.byteToCharMap_ = {}, this.charToByteMap_ = {}, this.byteToCharMapWebSafe_ = {}, this.charToByteMapWebSafe_ = {};
			for (let e = 0; e < this.ENCODED_VALS.length; e++) this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e), this.charToByteMap_[this.byteToCharMap_[e]] = e, this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e), this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e, e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e, this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e);
		}
	}
}, i = class extends Error {
	constructor() {
		super(...arguments), this.name = "DecodeBase64StringError";
	}
}, a = function(e) {
	let n = t(e);
	return r.encodeByteArray(n, !0);
}, o = function(e) {
	return a(e).replace(/\./g, "");
}, s = function(e) {
	try {
		return r.decodeString(e, !0);
	} catch (e) {
		console.error("base64Decode failed: ", e);
	}
	return null;
};
function c() {
	if (typeof self < "u") return self;
	if (typeof window < "u") return window;
	if (typeof global < "u") return global;
	throw Error("Unable to locate global object.");
}
var l = () => c().__FIREBASE_DEFAULTS__, u = () => {
	if (typeof process > "u" || process.env === void 0) return;
	let e = process.env.__FIREBASE_DEFAULTS__;
	if (e) return JSON.parse(e);
}, d = () => {
	if (typeof document > "u") return;
	let e;
	try {
		e = document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/);
	} catch {
		return;
	}
	let t = e && s(e[1]);
	return t && JSON.parse(t);
}, f = () => {
	try {
		return e() || l() || u() || d();
	} catch (e) {
		console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);
		return;
	}
}, p = () => f()?.config, m = class {
	constructor() {
		this.reject = () => {}, this.resolve = () => {}, this.promise = new Promise((e, t) => {
			this.resolve = e, this.reject = t;
		});
	}
	wrapCallback(e) {
		return (t, n) => {
			t ? this.reject(t) : this.resolve(n), typeof e == "function" && (this.promise.catch(() => {}), e.length === 1 ? e(t) : e(t, n));
		};
	}
};
function h() {
	return typeof navigator < "u" && typeof navigator.userAgent == "string" ? navigator.userAgent : "";
}
function g() {
	return typeof window < "u" && !!(window.cordova || window.phonegap || window.PhoneGap) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(h());
}
function _() {
	return typeof navigator < "u" && navigator.userAgent === "Cloudflare-Workers";
}
function v() {
	let e = typeof chrome == "object" ? chrome.runtime : typeof browser == "object" ? browser.runtime : void 0;
	return typeof e == "object" && e.id !== void 0;
}
function y() {
	return typeof navigator == "object" && navigator.product === "ReactNative";
}
function ee() {
	try {
		return typeof indexedDB == "object";
	} catch {
		return !1;
	}
}
function te() {
	return new Promise((e, t) => {
		try {
			let n = !0, r = "validate-browser-context-for-indexeddb-analytics-module", i = self.indexedDB.open(r);
			i.onsuccess = () => {
				i.result.close(), n || self.indexedDB.deleteDatabase(r), e(!0);
			}, i.onupgradeneeded = () => {
				n = !1;
			}, i.onerror = () => {
				t(i.error?.message || "");
			};
		} catch (e) {
			t(e);
		}
	});
}
var ne = "FirebaseError", b = class e extends Error {
	constructor(t, n, r) {
		super(n), this.code = t, this.customData = r, this.name = ne, Object.setPrototypeOf(this, e.prototype), Error.captureStackTrace && Error.captureStackTrace(this, x.prototype.create);
	}
}, x = class {
	constructor(e, t, n) {
		this.service = e, this.serviceName = t, this.errors = n;
	}
	create(e, ...t) {
		let n = t[0] || {}, r = `${this.service}/${e}`, i = this.errors[e], a = i ? re(i, n) : "Error";
		return new b(r, `${this.serviceName}: ${a} (${r}).`, n);
	}
};
function re(e, t) {
	try {
		let n = 0, r = "";
		for (; n < e.length;) {
			let i = e.indexOf("{$", n);
			if (i === -1) {
				r += e.substring(n);
				break;
			}
			let a = e.indexOf("}", i + 2);
			if (a === -1) {
				r += e.substring(n);
				break;
			}
			let o = e.substring(i + 2, a), s = t[o];
			r += e.substring(n, i) + (s == null ? `<${o}?>` : String(s)), n = a + 1;
		}
		return r;
	} catch {
		return e;
	}
}
function ie(e, t) {
	if (e === t) return !0;
	let n = Object.keys(e), r = Object.keys(t);
	for (let i of n) {
		if (!r.includes(i)) return !1;
		let n = e[i], a = t[i];
		if (ae(n) && ae(a)) {
			if (!ie(n, a)) return !1;
		} else if (n !== a) return !1;
	}
	for (let e of r) if (!n.includes(e)) return !1;
	return !0;
}
function ae(e) {
	return typeof e == "object" && !!e;
}
function oe(e) {
	let t = [];
	for (let [n, r] of Object.entries(e)) Array.isArray(r) ? r.forEach((e) => {
		t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e));
	}) : t.push(encodeURIComponent(n) + "=" + encodeURIComponent(r));
	return t.length ? "&" + t.join("&") : "";
}
function S(e) {
	let t = {};
	return e.replace(/^\?/, "").split("&").forEach((e) => {
		if (e) {
			let [n, r] = e.split("=");
			t[decodeURIComponent(n)] = decodeURIComponent(r);
		}
	}), t;
}
function C(e) {
	let t = e.indexOf("?");
	if (!t) return "";
	let n = e.indexOf("#", t);
	return e.substring(t, n > 0 ? n : void 0);
}
function se(e, t) {
	let n = new ce(e, t);
	return n.subscribe.bind(n);
}
var ce = class {
	constructor(e, t) {
		this.observers = [], this.unsubscribes = [], this.observerCount = 0, this.task = Promise.resolve(), this.finalized = !1, this.onNoObservers = t, this.task.then(() => {
			e(this);
		}).catch((e) => {
			this.error(e);
		});
	}
	next(e) {
		this.forEachObserver((t) => {
			t.next(e);
		});
	}
	error(e) {
		this.forEachObserver((t) => {
			t.error(e);
		}), this.close(e);
	}
	complete() {
		this.forEachObserver((e) => {
			e.complete();
		}), this.close();
	}
	subscribe(e, t, n) {
		let r;
		if (e === void 0 && t === void 0 && n === void 0) throw Error("Missing Observer.");
		r = le(e, [
			"next",
			"error",
			"complete"
		]) ? e : {
			next: e,
			error: t,
			complete: n
		}, r.next === void 0 && (r.next = ue), r.error === void 0 && (r.error = ue), r.complete === void 0 && (r.complete = ue);
		let i = this.unsubscribeOne.bind(this, this.observers.length);
		return this.finalized && this.task.then(() => {
			try {
				this.finalError ? r.error(this.finalError) : r.complete();
			} catch {}
		}), this.observers.push(r), i;
	}
	unsubscribeOne(e) {
		this.observers !== void 0 && this.observers[e] !== void 0 && (delete this.observers[e], --this.observerCount, this.observerCount === 0 && this.onNoObservers !== void 0 && this.onNoObservers(this));
	}
	forEachObserver(e) {
		if (!this.finalized) for (let t = 0; t < this.observers.length; t++) this.sendOne(t, e);
	}
	sendOne(e, t) {
		this.task.then(() => {
			if (this.observers !== void 0 && this.observers[e] !== void 0) try {
				t(this.observers[e]);
			} catch (e) {
				typeof console < "u" && console.error && console.error(e);
			}
		});
	}
	close(e) {
		this.finalized || (this.finalized = !0, e !== void 0 && (this.finalError = e), this.task.then(() => {
			this.observers = void 0, this.onNoObservers = void 0;
		}));
	}
};
function le(e, t) {
	if (typeof e != "object" || !e) return !1;
	for (let n of t) if (n in e && typeof e[n] == "function") return !0;
	return !1;
}
function ue() {}
function w(e) {
	return e && e._delegate ? e._delegate : e;
}
function de(e) {
	try {
		return (e.startsWith("http://") || e.startsWith("https://") ? new URL(e).hostname : e).endsWith(".cloudworkstations.dev");
	} catch {
		return !1;
	}
}
//#endregion
//#region ../node_modules/.pnpm/@firebase+component@0.7.5/node_modules/@firebase/component/dist/esm/index.esm.js
var T = class {
	constructor(e, t, n) {
		this.name = e, this.instanceFactory = t, this.type = n, this.multipleInstances = !1, this.serviceProps = {}, this.instantiationMode = "LAZY", this.onInstanceCreated = null;
	}
	setInstantiationMode(e) {
		return this.instantiationMode = e, this;
	}
	setMultipleInstances(e) {
		return this.multipleInstances = e, this;
	}
	setServiceProps(e) {
		return this.serviceProps = e, this;
	}
	setInstanceCreatedCallback(e) {
		return this.onInstanceCreated = e, this;
	}
}, E = "[DEFAULT]", fe = class {
	constructor(e, t) {
		this.name = e, this.container = t, this.component = null, this.instances = /* @__PURE__ */ new Map(), this.instancesDeferred = /* @__PURE__ */ new Map(), this.instancesOptions = /* @__PURE__ */ new Map(), this.onInitCallbacks = /* @__PURE__ */ new Map();
	}
	get(e) {
		let t = this.normalizeInstanceIdentifier(e);
		if (!this.instancesDeferred.has(t)) {
			let e = new m();
			if (this.instancesDeferred.set(t, e), this.isInitialized(t) || this.shouldAutoInitialize()) try {
				let n = this.getOrInitializeService({ instanceIdentifier: t });
				n && e.resolve(n);
			} catch {}
		}
		return this.instancesDeferred.get(t).promise;
	}
	getImmediate(e) {
		let t = this.normalizeInstanceIdentifier(e?.identifier), n = e?.optional ?? !1;
		if (this.isInitialized(t) || this.shouldAutoInitialize()) try {
			return this.getOrInitializeService({ instanceIdentifier: t });
		} catch (e) {
			if (n) return null;
			throw e;
		}
		if (n) return null;
		throw Error(`Service ${this.name} is not available`);
	}
	getComponent() {
		return this.component;
	}
	setComponent(e) {
		if (e.name !== this.name) throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);
		if (this.component) throw Error(`Component for ${this.name} has already been provided`);
		if (this.component = e, this.shouldAutoInitialize()) {
			if (me(e)) try {
				this.getOrInitializeService({ instanceIdentifier: E });
			} catch {}
			for (let [e, t] of this.instancesDeferred.entries()) {
				let n = this.normalizeInstanceIdentifier(e);
				try {
					let e = this.getOrInitializeService({ instanceIdentifier: n });
					t.resolve(e);
				} catch {}
			}
		}
	}
	clearInstance(e = E) {
		this.instancesDeferred.delete(e), this.instancesOptions.delete(e), this.instances.delete(e);
	}
	async delete() {
		let e = Array.from(this.instances.values());
		await Promise.all([...e.filter((e) => "INTERNAL" in e).map((e) => e.INTERNAL.delete()), ...e.filter((e) => "_delete" in e).map((e) => e._delete())]);
	}
	isComponentSet() {
		return this.component != null;
	}
	isInitialized(e = E) {
		return this.instances.has(e);
	}
	getOptions(e = E) {
		return this.instancesOptions.get(e) || {};
	}
	initialize(e = {}) {
		let { options: t = {} } = e, n = this.normalizeInstanceIdentifier(e.instanceIdentifier);
		if (this.isInitialized(n)) throw Error(`${this.name}(${n}) has already been initialized`);
		if (!this.isComponentSet()) throw Error(`Component ${this.name} has not been registered yet`);
		let r = this.getOrInitializeService({
			instanceIdentifier: n,
			options: t
		});
		for (let [e, t] of this.instancesDeferred.entries()) n === this.normalizeInstanceIdentifier(e) && t.resolve(r);
		return r;
	}
	onInit(e, t) {
		let n = this.normalizeInstanceIdentifier(t), r = this.onInitCallbacks.get(n) ?? /* @__PURE__ */ new Set();
		r.add(e), this.onInitCallbacks.set(n, r);
		let i = this.instances.get(n);
		return i && e(i, n), () => {
			r.delete(e);
		};
	}
	invokeOnInitCallbacks(e, t) {
		let n = this.onInitCallbacks.get(t);
		if (n) for (let r of n) try {
			r(e, t);
		} catch {}
	}
	getOrInitializeService({ instanceIdentifier: e, options: t = {} }) {
		let n = this.instances.get(e);
		if (!n && this.component && (n = this.component.instanceFactory(this.container, {
			instanceIdentifier: pe(e),
			options: t
		}), this.instances.set(e, n), this.instancesOptions.set(e, t), this.invokeOnInitCallbacks(n, e), this.component.onInstanceCreated)) try {
			this.component.onInstanceCreated(this.container, e, n);
		} catch {}
		return n || null;
	}
	normalizeInstanceIdentifier(e = E) {
		return this.component ? this.component.multipleInstances ? e : E : e;
	}
	shouldAutoInitialize() {
		return !!this.component && this.component.instantiationMode !== "EXPLICIT";
	}
};
function pe(e) {
	return e === E ? void 0 : e;
}
function me(e) {
	return e.instantiationMode === "EAGER";
}
var he = class {
	constructor(e) {
		this.name = e, this.providers = /* @__PURE__ */ new Map();
	}
	addComponent(e) {
		let t = this.getProvider(e.name);
		if (t.isComponentSet()) throw Error(`Component ${e.name} has already been registered with ${this.name}`);
		t.setComponent(e);
	}
	addOrOverwriteComponent(e) {
		this.getProvider(e.name).isComponentSet() && this.providers.delete(e.name), this.addComponent(e);
	}
	getProvider(e) {
		if (this.providers.has(e)) return this.providers.get(e);
		let t = new fe(e, this);
		return this.providers.set(e, t), t;
	}
	getProviders() {
		return Array.from(this.providers.values());
	}
}, ge = [], D;
(function(e) {
	e[e.DEBUG = 0] = "DEBUG", e[e.VERBOSE = 1] = "VERBOSE", e[e.INFO = 2] = "INFO", e[e.WARN = 3] = "WARN", e[e.ERROR = 4] = "ERROR", e[e.SILENT = 5] = "SILENT";
})(D ||= {});
var _e = {
	debug: D.DEBUG,
	verbose: D.VERBOSE,
	info: D.INFO,
	warn: D.WARN,
	error: D.ERROR,
	silent: D.SILENT
}, ve = D.INFO, ye = {
	[D.DEBUG]: "log",
	[D.VERBOSE]: "log",
	[D.INFO]: "info",
	[D.WARN]: "warn",
	[D.ERROR]: "error"
}, be = (e, t, ...n) => {
	if (t < e.logLevel) return;
	let r = (/* @__PURE__ */ new Date()).toISOString(), i = ye[t];
	if (i) console[i](`[${r}]  ${e.name}:`, ...n);
	else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`);
}, xe = class {
	constructor(e) {
		this.name = e, this._logLevel = ve, this._logHandler = be, this._userLogHandler = null, ge.push(this);
	}
	get logLevel() {
		return this._logLevel;
	}
	set logLevel(e) {
		if (!(e in D)) throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);
		this._logLevel = e;
	}
	setLogLevel(e) {
		this._logLevel = typeof e == "string" ? _e[e] : e;
	}
	get logHandler() {
		return this._logHandler;
	}
	set logHandler(e) {
		if (typeof e != "function") throw TypeError("Value assigned to `logHandler` must be a function");
		this._logHandler = e;
	}
	get userLogHandler() {
		return this._userLogHandler;
	}
	set userLogHandler(e) {
		this._userLogHandler = e;
	}
	debug(...e) {
		this._userLogHandler && this._userLogHandler(this, D.DEBUG, ...e), this._logHandler(this, D.DEBUG, ...e);
	}
	log(...e) {
		this._userLogHandler && this._userLogHandler(this, D.VERBOSE, ...e), this._logHandler(this, D.VERBOSE, ...e);
	}
	info(...e) {
		this._userLogHandler && this._userLogHandler(this, D.INFO, ...e), this._logHandler(this, D.INFO, ...e);
	}
	warn(...e) {
		this._userLogHandler && this._userLogHandler(this, D.WARN, ...e), this._logHandler(this, D.WARN, ...e);
	}
	error(...e) {
		this._userLogHandler && this._userLogHandler(this, D.ERROR, ...e), this._logHandler(this, D.ERROR, ...e);
	}
}, Se = (e, t) => t.some((t) => e instanceof t), Ce, we;
function Te() {
	return Ce ||= [
		IDBDatabase,
		IDBObjectStore,
		IDBIndex,
		IDBCursor,
		IDBTransaction
	];
}
function Ee() {
	return we ||= [
		IDBCursor.prototype.advance,
		IDBCursor.prototype.continue,
		IDBCursor.prototype.continuePrimaryKey
	];
}
var De = /* @__PURE__ */ new WeakMap(), Oe = /* @__PURE__ */ new WeakMap(), ke = /* @__PURE__ */ new WeakMap(), Ae = /* @__PURE__ */ new WeakMap(), je = /* @__PURE__ */ new WeakMap();
function Me(e) {
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("success", i), e.removeEventListener("error", a);
		}, i = () => {
			t(O(e.result)), r();
		}, a = () => {
			n(e.error), r();
		};
		e.addEventListener("success", i), e.addEventListener("error", a);
	});
	return t.then((t) => {
		t instanceof IDBCursor && De.set(t, e);
	}).catch(() => {}), je.set(t, e), t;
}
function Ne(e) {
	if (Oe.has(e)) return;
	let t = new Promise((t, n) => {
		let r = () => {
			e.removeEventListener("complete", i), e.removeEventListener("error", a), e.removeEventListener("abort", a);
		}, i = () => {
			t(), r();
		}, a = () => {
			n(e.error || new DOMException("AbortError", "AbortError")), r();
		};
		e.addEventListener("complete", i), e.addEventListener("error", a), e.addEventListener("abort", a);
	});
	Oe.set(e, t);
}
var Pe = {
	get(e, t, n) {
		if (e instanceof IDBTransaction) {
			if (t === "done") return Oe.get(e);
			if (t === "objectStoreNames") return e.objectStoreNames || ke.get(e);
			if (t === "store") return n.objectStoreNames[1] ? void 0 : n.objectStore(n.objectStoreNames[0]);
		}
		return O(e[t]);
	},
	set(e, t, n) {
		return e[t] = n, !0;
	},
	has(e, t) {
		return e instanceof IDBTransaction && (t === "done" || t === "store") || t in e;
	}
};
function Fe(e) {
	Pe = e(Pe);
}
function Ie(e) {
	return e === IDBDatabase.prototype.transaction && !("objectStoreNames" in IDBTransaction.prototype) ? function(t, ...n) {
		let r = e.call(Re(this), t, ...n);
		return ke.set(r, t.sort ? t.sort() : [t]), O(r);
	} : Ee().includes(e) ? function(...t) {
		return e.apply(Re(this), t), O(De.get(this));
	} : function(...t) {
		return O(e.apply(Re(this), t));
	};
}
function Le(e) {
	return typeof e == "function" ? Ie(e) : (e instanceof IDBTransaction && Ne(e), Se(e, Te()) ? new Proxy(e, Pe) : e);
}
function O(e) {
	if (e instanceof IDBRequest) return Me(e);
	if (Ae.has(e)) return Ae.get(e);
	let t = Le(e);
	return t !== e && (Ae.set(e, t), je.set(t, e)), t;
}
var Re = (e) => je.get(e);
//#endregion
//#region ../node_modules/.pnpm/idb@7.1.1/node_modules/idb/build/index.js
function ze(e, t, { blocked: n, upgrade: r, blocking: i, terminated: a } = {}) {
	let o = indexedDB.open(e, t), s = O(o);
	return r && o.addEventListener("upgradeneeded", (e) => {
		r(O(o.result), e.oldVersion, e.newVersion, O(o.transaction), e);
	}), n && o.addEventListener("blocked", (e) => n(e.oldVersion, e.newVersion, e)), s.then((e) => {
		a && e.addEventListener("close", () => a()), i && e.addEventListener("versionchange", (e) => i(e.oldVersion, e.newVersion, e));
	}).catch(() => {}), s;
}
var Be = [
	"get",
	"getKey",
	"getAll",
	"getAllKeys",
	"count"
], Ve = [
	"put",
	"add",
	"delete",
	"clear"
], He = /* @__PURE__ */ new Map();
function Ue(e, t) {
	if (!(e instanceof IDBDatabase && !(t in e) && typeof t == "string")) return;
	if (He.get(t)) return He.get(t);
	let n = t.replace(/FromIndex$/, ""), r = t !== n, i = Ve.includes(n);
	if (!(n in (r ? IDBIndex : IDBObjectStore).prototype) || !(i || Be.includes(n))) return;
	let a = async function(e, ...t) {
		let a = this.transaction(e, i ? "readwrite" : "readonly"), o = a.store;
		return r && (o = o.index(t.shift())), (await Promise.all([o[n](...t), i && a.done]))[0];
	};
	return He.set(t, a), a;
}
Fe((e) => ({
	...e,
	get: (t, n, r) => Ue(t, n) || e.get(t, n, r),
	has: (t, n) => !!Ue(t, n) || e.has(t, n)
}));
//#endregion
//#region ../node_modules/.pnpm/@firebase+app@0.16.3/node_modules/@firebase/app/dist/esm/index.esm.js
var We = class {
	constructor(e) {
		this.container = e;
	}
	getPlatformInfoString() {
		return this.container.getProviders().map((e) => {
			if (Ge(e)) {
				let t = e.getImmediate();
				return `${t.library}/${t.version}`;
			}
			return null;
		}).filter((e) => e).join(" ");
	}
};
function Ge(e) {
	return e.getComponent()?.type === "VERSION";
}
var Ke = "@firebase/app", qe = "0.16.3", k = new xe("@firebase/app"), Je = "@firebase/app-compat", Ye = "@firebase/analytics-compat", Xe = "@firebase/analytics", Ze = "@firebase/app-check-compat", Qe = "@firebase/app-check", $e = "@firebase/auth", et = "@firebase/auth-compat", tt = "@firebase/database", nt = "@firebase/data-connect", rt = "@firebase/database-compat", it = "@firebase/functions", at = "@firebase/functions-compat", ot = "@firebase/installations", st = "@firebase/installations-compat", ct = "@firebase/messaging", lt = "@firebase/messaging-compat", ut = "@firebase/performance", dt = "@firebase/performance-compat", ft = "@firebase/remote-config", pt = "@firebase/remote-config-compat", mt = "@firebase/storage", ht = "@firebase/storage-compat", gt = "@firebase/firestore", _t = "@firebase/ai", vt = "@firebase/firestore-compat", yt = "firebase", bt = "13.0.0", xt = "[DEFAULT]", St = {
	[Ke]: "fire-core",
	[Je]: "fire-core-compat",
	[Xe]: "fire-analytics",
	[Ye]: "fire-analytics-compat",
	[Qe]: "fire-app-check",
	[Ze]: "fire-app-check-compat",
	[$e]: "fire-auth",
	[et]: "fire-auth-compat",
	[tt]: "fire-rtdb",
	[nt]: "fire-data-connect",
	[rt]: "fire-rtdb-compat",
	[it]: "fire-fn",
	[at]: "fire-fn-compat",
	[ot]: "fire-iid",
	[st]: "fire-iid-compat",
	[ct]: "fire-fcm",
	[lt]: "fire-fcm-compat",
	[ut]: "fire-perf",
	[dt]: "fire-perf-compat",
	[ft]: "fire-rc",
	[pt]: "fire-rc-compat",
	[mt]: "fire-gcs",
	[ht]: "fire-gcs-compat",
	[gt]: "fire-fst",
	[vt]: "fire-fst-compat",
	[_t]: "fire-vertex",
	"fire-js": "fire-js",
	[yt]: "fire-js-all"
}, Ct = /* @__PURE__ */ new Map(), wt = /* @__PURE__ */ new Map(), Tt = /* @__PURE__ */ new Map();
function Et(e, t) {
	try {
		e.container.addComponent(t);
	} catch (n) {
		k.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`, n);
	}
}
function A(e) {
	let t = e.name;
	if (Tt.has(t)) return k.debug(`There were multiple attempts to register component ${t}.`), !1;
	Tt.set(t, e);
	for (let t of Ct.values()) Et(t, e);
	for (let t of wt.values()) Et(t, e);
	return !0;
}
function Dt(e, t) {
	let n = e.container.getProvider("heartbeat").getImmediate({ optional: !0 });
	return n && n.triggerHeartbeat(), e.container.getProvider(t);
}
function j(e) {
	return e != null && e.settings !== void 0;
}
var M = new x("app", "Firebase", {
	"no-app": "No Firebase App '{$appName}' has been created - call initializeApp() first",
	"bad-app-name": "Illegal App name: '{$appName}'",
	"duplicate-app": "Firebase App named '{$appName}' already exists with different {$mismatchedParam}. Existing: '{$oldValue}'. New: '{$newValue}'.",
	"app-deleted": "Firebase App named '{$appName}' already deleted",
	"server-app-deleted": "Firebase Server App has been deleted",
	"no-options": "Need to provide options, when not being deployed to hosting via source.",
	"invalid-app-argument": "firebase.{$appName}() takes either no argument or a Firebase App instance.",
	"invalid-log-argument": "First argument to `onLog` must be null or a function.",
	"idb-open": "Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-get": "Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-set": "Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.",
	"idb-delete": "Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.",
	"finalization-registry-not-supported": "FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.",
	"invalid-server-app-environment": "FirebaseServerApp is not for use in browser environments."
}), Ot = class {
	constructor(e, t, n) {
		this._isDeleted = !1, this._options = { ...e }, this._config = { ...t }, this._name = t.name, this._automaticDataCollectionEnabled = t.automaticDataCollectionEnabled, this._container = n, this.container.addComponent(new T("app", () => this, "PUBLIC"));
	}
	get automaticDataCollectionEnabled() {
		return this.checkDestroyed(), this._automaticDataCollectionEnabled;
	}
	set automaticDataCollectionEnabled(e) {
		this.checkDestroyed(), this._automaticDataCollectionEnabled = e;
	}
	get name() {
		return this.checkDestroyed(), this._name;
	}
	get options() {
		return this.checkDestroyed(), this._options;
	}
	get config() {
		return this.checkDestroyed(), this._config;
	}
	get container() {
		return this._container;
	}
	get isDeleted() {
		return this._isDeleted;
	}
	set isDeleted(e) {
		this._isDeleted = e;
	}
	checkDestroyed() {
		if (this.isDeleted) throw M.create("app-deleted", { appName: this._name });
	}
}, kt = bt;
function At(e, t = {}) {
	let n = e;
	typeof t != "object" && (t = { name: t });
	let r = {
		name: xt,
		automaticDataCollectionEnabled: !0,
		...t
	}, i = r.name;
	if (typeof i != "string" || !i) throw M.create("bad-app-name", { appName: String(i) });
	if (n ||= p(), !n) throw M.create("no-options");
	let a = Ct.get(i);
	if (a) {
		if (!ie(n, a.options)) throw M.create("duplicate-app", {
			appName: i,
			mismatchedParam: "options",
			oldValue: JSON.stringify(a.options),
			newValue: JSON.stringify(n)
		});
		if (ie(r, a.config)) return a;
		throw M.create("duplicate-app", {
			appName: i,
			mismatchedParam: "config",
			oldValue: JSON.stringify(a.config),
			newValue: JSON.stringify(r)
		});
	}
	let o = new he(i);
	for (let e of Tt.values()) o.addComponent(e);
	let s = new Ot(n, r, o);
	return Ct.set(i, s), s;
}
function N(e, t, n) {
	let r = St[e] ?? e;
	n && (r += `-${n}`);
	let i = r.match(/\s|\//), a = t.match(/\s|\//);
	if (i || a) {
		let e = [`Unable to register library "${r}" with version "${t}":`];
		i && e.push(`library name "${r}" contains illegal characters (whitespace or "/")`), i && a && e.push("and"), a && e.push(`version name "${t}" contains illegal characters (whitespace or "/")`), k.warn(e.join(" "));
		return;
	}
	A(new T(`${r}-version`, () => ({
		library: r,
		version: t
	}), "VERSION"));
}
var jt = "firebase-heartbeat-database", Mt = 1, P = "firebase-heartbeat-store", Nt = null;
function Pt() {
	return Nt ||= ze(jt, Mt, { upgrade: (e, t) => {
		if (t === 0) try {
			e.createObjectStore(P);
		} catch (e) {
			console.warn(e);
		}
	} }).catch((e) => {
		throw M.create("idb-open", { originalErrorMessage: e.message });
	}), Nt;
}
async function Ft(e) {
	try {
		let t = (await Pt()).transaction(P), n = await t.objectStore(P).get(Lt(e));
		return await t.done, n;
	} catch (e) {
		if (e instanceof b) k.warn(e.message);
		else {
			let t = M.create("idb-get", { originalErrorMessage: e?.message });
			k.warn(t.message);
		}
	}
}
async function It(e, t) {
	try {
		let n = (await Pt()).transaction(P, "readwrite");
		await n.objectStore(P).put(t, Lt(e)), await n.done;
	} catch (e) {
		if (e instanceof b) k.warn(e.message);
		else {
			let t = M.create("idb-set", { originalErrorMessage: e?.message });
			k.warn(t.message);
		}
	}
}
function Lt(e) {
	return `${e.name}!${e.options.appId}`;
}
var Rt = 1024, zt = 30, Bt = class {
	constructor(e) {
		this.container = e, this._heartbeatsCache = null;
		let t = this.container.getProvider("app").getImmediate();
		this._storage = new Ut(t), this._heartbeatsCachePromise = this._storage.read().then((e) => (this._heartbeatsCache = e, e));
	}
	async triggerHeartbeat() {
		try {
			let e = this.container.getProvider("platform-logger").getImmediate().getPlatformInfoString(), t = Vt();
			if (this._heartbeatsCache?.heartbeats == null && (this._heartbeatsCache = await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null) || this._heartbeatsCache.lastSentHeartbeatDate === t || this._heartbeatsCache.heartbeats.some((e) => e.date === t)) return;
			if (this._heartbeatsCache.heartbeats.push({
				date: t,
				agent: e
			}), this._heartbeatsCache.heartbeats.length > zt) {
				let e = Gt(this._heartbeatsCache.heartbeats);
				this._heartbeatsCache.heartbeats.splice(e, 1);
			}
			return this._storage.overwrite(this._heartbeatsCache);
		} catch (e) {
			k.warn(e);
		}
	}
	async getHeartbeatsHeader() {
		try {
			if (this._heartbeatsCache === null && await this._heartbeatsCachePromise, this._heartbeatsCache?.heartbeats == null || this._heartbeatsCache.heartbeats.length === 0) return "";
			let e = Vt(), { heartbeatsToSend: t, unsentEntries: n } = Ht(this._heartbeatsCache.heartbeats), r = o(JSON.stringify({
				version: 2,
				heartbeats: t
			}));
			return this._heartbeatsCache.lastSentHeartbeatDate = e, n.length > 0 ? (this._heartbeatsCache.heartbeats = n, await this._storage.overwrite(this._heartbeatsCache)) : (this._heartbeatsCache.heartbeats = [], this._storage.overwrite(this._heartbeatsCache)), r;
		} catch (e) {
			return k.warn(e), "";
		}
	}
};
function Vt() {
	return (/* @__PURE__ */ new Date()).toISOString().substring(0, 10);
}
function Ht(e, t = Rt) {
	let n = [], r = e.slice();
	for (let i of e) {
		let e = n.find((e) => e.agent === i.agent);
		if (!e) {
			if (n.push({
				agent: i.agent,
				dates: [i.date]
			}), Wt(n) > t) {
				n.pop();
				break;
			}
		} else if (e.dates.push(i.date), Wt(n) > t) {
			e.dates.pop();
			break;
		}
		r = r.slice(1);
	}
	return {
		heartbeatsToSend: n,
		unsentEntries: r
	};
}
var Ut = class {
	constructor(e) {
		this.app = e, this._canUseIndexedDBPromise = this.runIndexedDBEnvironmentCheck();
	}
	async runIndexedDBEnvironmentCheck() {
		return ee() ? te().then(() => !0).catch(() => !1) : !1;
	}
	async read() {
		if (await this._canUseIndexedDBPromise) {
			let e = await Ft(this.app);
			return e?.heartbeats ? e : { heartbeats: [] };
		}
		return { heartbeats: [] };
	}
	async overwrite(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return It(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: e.heartbeats
			});
		}
	}
	async add(e) {
		if (await this._canUseIndexedDBPromise) {
			let t = await this.read();
			return It(this.app, {
				lastSentHeartbeatDate: e.lastSentHeartbeatDate ?? t.lastSentHeartbeatDate,
				heartbeats: [...t.heartbeats, ...e.heartbeats]
			});
		}
	}
};
function Wt(e) {
	return o(JSON.stringify({
		version: 2,
		heartbeats: e
	})).length;
}
function Gt(e) {
	if (e.length === 0) return -1;
	let t = 0, n = e[0].date;
	for (let r = 1; r < e.length; r++) e[r].date < n && (n = e[r].date, t = r);
	return t;
}
function Kt(e) {
	A(new T("platform-logger", (e) => new We(e), "PRIVATE")), A(new T("heartbeat", (e) => new Bt(e), "PRIVATE")), N(Ke, qe, e), N(Ke, qe, "esm2020"), N("fire-js", "");
}
//#endregion
//#region ../node_modules/.pnpm/firebase@13.0.0/node_modules/firebase/app/dist/esm/index.esm.js
Kt(""), N("firebase", "13.0.0", "app");
//#endregion
//#region ../node_modules/.pnpm/@firebase+auth@1.13.7_@firebase+app@0.16.3/node_modules/@firebase/auth/dist/web-extension-esm/register-BYpQIvAX.js
function qt() {
	return { "dependent-sdk-initialized-before-auth": "Another Firebase SDK was initialized and is trying to use Auth before Auth is initialized. Please be sure to call `initializeAuth` or `getAuth` before starting any other Firebase SDK." };
}
var Jt = qt, Yt = new x("auth", "Firebase", qt()), Xt = new xe("@firebase/auth");
function Zt(e, ...t) {
	Xt.logLevel <= D.WARN && Xt.warn(`Auth (${kt}): ${e}`, ...t);
}
function Qt(e, ...t) {
	Xt.logLevel <= D.ERROR && Xt.error(`Auth (${kt}): ${e}`, ...t);
}
function F(e, ...t) {
	throw tn(e, ...t);
}
function $t(e, ...t) {
	return tn(e, ...t);
}
function en(e, t, n) {
	return new x("auth", "Firebase", {
		...Jt(),
		[t]: n
	}).create(t, { appName: e.name });
}
function I(e) {
	return en(e, "operation-not-supported-in-this-environment", "Operations that alter the current user are not supported in conjunction with FirebaseServerApp");
}
function tn(e, ...t) {
	if (typeof e != "string") {
		let n = t[0], r = [...t.slice(1)];
		return r[0] && (r[0].appName = e.name), e._errorFactory.create(n, ...r);
	}
	return Yt.create(e, ...t);
}
function L(e, t, ...n) {
	if (!e) throw tn(t, ...n);
}
function R(e) {
	let t = "INTERNAL ASSERTION FAILED: " + e;
	throw Qt(t), Error(t);
}
function z(e, t) {
	e || R(t);
}
function nn() {
	return rn() === "http:" || rn() === "https:";
}
function rn() {
	return typeof self < "u" && self.location?.protocol || null;
}
function an() {
	return typeof navigator < "u" && navigator && "onLine" in navigator && typeof navigator.onLine == "boolean" && (nn() || v() || "connection" in navigator) ? navigator.onLine : !0;
}
function on() {
	if (typeof navigator > "u") return null;
	let e = navigator;
	return e.languages && e.languages[0] || e.language || null;
}
var sn = class {
	constructor(e, t) {
		this.shortDelay = e, this.longDelay = t, z(t > e, "Short delay should be less than long delay!"), this.isMobile = g() || y();
	}
	get() {
		return an() ? this.isMobile ? this.longDelay : this.shortDelay : Math.min(5e3, this.shortDelay);
	}
};
function cn(e, t) {
	z(e.emulator, "Emulator should always be set here");
	let { url: n } = e.emulator;
	return t ? `${n}${t.startsWith("/") ? t.slice(1) : t}` : n;
}
var ln = class {
	static initialize(e, t, n) {
		this.fetchImpl = e, t && (this.headersImpl = t), n && (this.responseImpl = n);
	}
	static fetch() {
		if (this.fetchImpl) return this.fetchImpl;
		if (typeof self < "u" && "fetch" in self) return self.fetch;
		if (typeof globalThis < "u" && globalThis.fetch) return globalThis.fetch;
		if (typeof fetch < "u") return fetch;
		R("Could not find fetch implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static headers() {
		if (this.headersImpl) return this.headersImpl;
		if (typeof self < "u" && "Headers" in self) return self.Headers;
		if (typeof globalThis < "u" && globalThis.Headers) return globalThis.Headers;
		if (typeof Headers < "u") return Headers;
		R("Could not find Headers implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
	static response() {
		if (this.responseImpl) return this.responseImpl;
		if (typeof self < "u" && "Response" in self) return self.Response;
		if (typeof globalThis < "u" && globalThis.Response) return globalThis.Response;
		if (typeof Response < "u") return Response;
		R("Could not find Response implementation, make sure you call FetchProvider.initialize() with an appropriate polyfill");
	}
}, un = {
	CREDENTIAL_MISMATCH: "custom-token-mismatch",
	MISSING_CUSTOM_TOKEN: "internal-error",
	INVALID_IDENTIFIER: "invalid-email",
	MISSING_CONTINUE_URI: "internal-error",
	INVALID_PASSWORD: "wrong-password",
	MISSING_PASSWORD: "missing-password",
	INVALID_LOGIN_CREDENTIALS: "invalid-credential",
	EMAIL_EXISTS: "email-already-in-use",
	PASSWORD_LOGIN_DISABLED: "operation-not-allowed",
	INVALID_IDP_RESPONSE: "invalid-credential",
	INVALID_PENDING_TOKEN: "invalid-credential",
	FEDERATED_USER_ID_ALREADY_LINKED: "credential-already-in-use",
	MISSING_REQ_TYPE: "internal-error",
	EMAIL_NOT_FOUND: "user-not-found",
	RESET_PASSWORD_EXCEED_LIMIT: "too-many-requests",
	EXPIRED_OOB_CODE: "expired-action-code",
	INVALID_OOB_CODE: "invalid-action-code",
	MISSING_OOB_CODE: "internal-error",
	CREDENTIAL_TOO_OLD_LOGIN_AGAIN: "requires-recent-login",
	INVALID_ID_TOKEN: "invalid-user-token",
	TOKEN_EXPIRED: "user-token-expired",
	USER_NOT_FOUND: "user-token-expired",
	TOO_MANY_ATTEMPTS_TRY_LATER: "too-many-requests",
	PASSWORD_DOES_NOT_MEET_REQUIREMENTS: "password-does-not-meet-requirements",
	INVALID_CODE: "invalid-verification-code",
	INVALID_SESSION_INFO: "invalid-verification-id",
	INVALID_TEMPORARY_PROOF: "invalid-credential",
	MISSING_SESSION_INFO: "missing-verification-id",
	SESSION_EXPIRED: "code-expired",
	MISSING_ANDROID_PACKAGE_NAME: "missing-android-pkg-name",
	UNAUTHORIZED_DOMAIN: "unauthorized-continue-uri",
	INVALID_OAUTH_CLIENT_ID: "invalid-oauth-client-id",
	ADMIN_ONLY_OPERATION: "admin-restricted-operation",
	INVALID_MFA_PENDING_CREDENTIAL: "invalid-multi-factor-session",
	MFA_ENROLLMENT_NOT_FOUND: "multi-factor-info-not-found",
	MISSING_MFA_ENROLLMENT_ID: "missing-multi-factor-info",
	MISSING_MFA_PENDING_CREDENTIAL: "missing-multi-factor-session",
	SECOND_FACTOR_EXISTS: "second-factor-already-in-use",
	SECOND_FACTOR_LIMIT_EXCEEDED: "maximum-second-factor-count-exceeded",
	BLOCKING_FUNCTION_ERROR_RESPONSE: "internal-error",
	RECAPTCHA_NOT_ENABLED: "recaptcha-not-enabled",
	MISSING_RECAPTCHA_TOKEN: "missing-recaptcha-token",
	INVALID_RECAPTCHA_TOKEN: "invalid-recaptcha-token",
	INVALID_RECAPTCHA_ACTION: "invalid-recaptcha-action",
	MISSING_CLIENT_TYPE: "missing-client-type",
	MISSING_RECAPTCHA_VERSION: "missing-recaptcha-version",
	INVALID_RECAPTCHA_VERSION: "invalid-recaptcha-version",
	INVALID_REQ_TYPE: "invalid-req-type"
}, dn = [
	"/v1/accounts:signInWithCustomToken",
	"/v1/accounts:signInWithEmailLink",
	"/v1/accounts:signInWithIdp",
	"/v1/accounts:signInWithPassword",
	"/v1/accounts:signInWithPhoneNumber",
	"/v1/token"
], fn = new sn(3e4, 6e4);
function B(e, t) {
	return e.tenantId && !t.tenantId ? {
		...t,
		tenantId: e.tenantId
	} : t;
}
async function V(e, t, n, r, i = {}) {
	return pn(e, i, async () => {
		let i = {}, a = {};
		r && (t === "GET" ? a = r : i = { body: JSON.stringify(r) });
		let o = oe({
			...a,
			key: e.config.apiKey
		}).slice(1), s = await e._getAdditionalHeaders();
		s["Content-Type"] = "application/json", e.languageCode && (s["X-Firebase-Locale"] = e.languageCode);
		let c = {
			method: t,
			headers: s,
			...i
		};
		return _() || (c.referrerPolicy = "strict-origin-when-cross-origin"), e.emulatorConfig && de(e.emulatorConfig.host) && (c.credentials = "include"), ln.fetch()(await mn(e, e.config.apiHost, n, o), c);
	});
}
async function pn(e, t, n) {
	e._canInitEmulator = !1;
	let r = {
		...un,
		...t
	};
	try {
		let t = new gn(e), i = await Promise.race([n(), t.promise]);
		t.clearNetworkTimeout();
		let a = await i.json();
		if ("needConfirmation" in a) throw U(e, "account-exists-with-different-credential", a);
		if (i.ok && !("errorMessage" in a)) return a;
		{
			let [t, n] = (i.ok ? a.errorMessage : a.error.message).split(" : ");
			if (t === "FEDERATED_USER_ID_ALREADY_LINKED") throw U(e, "credential-already-in-use", a);
			if (t === "EMAIL_EXISTS") throw U(e, "email-already-in-use", a);
			if (t === "USER_DISABLED") throw U(e, "user-disabled", a);
			let o = r[t] || t.toLowerCase().replace(/[_\s]+/g, "-");
			if (n) throw en(e, o, n);
			F(e, o);
		}
	} catch (t) {
		if (t instanceof b) throw t;
		F(e, "network-request-failed", { message: String(t) });
	}
}
async function H(e, t, n, r, i = {}) {
	let a = await V(e, t, n, r, i);
	return "mfaPendingCredential" in a && F(e, "multi-factor-auth-required", { _serverResponse: a }), a;
}
async function mn(e, t, n, r) {
	let i = `${t}${n}?${r}`, a = e, o = a.config.emulator ? cn(e.config, i) : `${e.config.apiScheme}://${i}`;
	return dn.includes(n) && (await a._persistenceManagerAvailable, a._getPersistenceType() === "COOKIE") ? a._getPersistence()._getFinalTarget(o).toString() : o;
}
function hn(e) {
	switch (e) {
		case "ENFORCE": return "ENFORCE";
		case "AUDIT": return "AUDIT";
		case "OFF": return "OFF";
		default: return "ENFORCEMENT_STATE_UNSPECIFIED";
	}
}
var gn = class {
	clearNetworkTimeout() {
		clearTimeout(this.timer);
	}
	constructor(e) {
		this.auth = e, this.timer = null, this.promise = new Promise((e, t) => {
			this.timer = setTimeout(() => t($t(this.auth, "network-request-failed")), fn.get());
		});
	}
};
function U(e, t, n) {
	let r = { appName: e.name };
	n.email && (r.email = n.email), n.phoneNumber && (r.phoneNumber = n.phoneNumber);
	let i = $t(e, t, r);
	return i.customData._tokenResponse = n, i;
}
function _n(e) {
	return e !== void 0 && e.enterprise !== void 0;
}
var vn = class {
	constructor(e) {
		if (this.siteKey = "", this.recaptchaEnforcementState = [], e.recaptchaKey === void 0) throw Error("recaptchaKey undefined");
		this.siteKey = e.recaptchaKey.split("/")[3], this.recaptchaEnforcementState = e.recaptchaEnforcementState;
	}
	getProviderEnforcementState(e) {
		if (!this.recaptchaEnforcementState || this.recaptchaEnforcementState.length === 0) return null;
		for (let t of this.recaptchaEnforcementState) if (t.provider && t.provider === e) return hn(t.enforcementState);
		return null;
	}
	isProviderEnabled(e) {
		return this.getProviderEnforcementState(e) === "ENFORCE" || this.getProviderEnforcementState(e) === "AUDIT";
	}
	isAnyProviderEnabled() {
		return this.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") || this.isProviderEnabled("PHONE_PROVIDER");
	}
};
async function yn(e, t) {
	return V(e, "GET", "/v2/recaptchaConfig", B(e, t));
}
async function bn(e, t) {
	return V(e, "POST", "/v1/accounts:delete", t);
}
async function xn(e, t) {
	return V(e, "POST", "/v1/accounts:lookup", t);
}
function W(e) {
	if (e) try {
		let t = new Date(Number(e));
		if (!isNaN(t.getTime())) return t.toUTCString();
	} catch {}
}
async function Sn(e, t = !1) {
	let n = w(e), r = await n.getIdToken(t), i = wn(r);
	L(i && i.exp && i.auth_time && i.iat, n.auth, "internal-error");
	let a = typeof i.firebase == "object" ? i.firebase : void 0, o = a?.sign_in_provider;
	return {
		claims: i,
		token: r,
		authTime: W(Cn(i.auth_time)),
		issuedAtTime: W(Cn(i.iat)),
		expirationTime: W(Cn(i.exp)),
		signInProvider: o || null,
		signInSecondFactor: a?.sign_in_second_factor || null
	};
}
function Cn(e) {
	return Number(e) * 1e3;
}
function wn(e) {
	let [t, n, r] = e.split(".");
	if (t === void 0 || n === void 0 || r === void 0) return Qt("JWT malformed, contained fewer than 3 sections"), null;
	try {
		let e = s(n);
		return e ? JSON.parse(e) : (Qt("Failed to decode base64 JWT payload"), null);
	} catch (e) {
		return Qt("Caught error parsing JWT payload as JSON", e?.toString()), null;
	}
}
function Tn(e) {
	let t = wn(e);
	return L(t, "internal-error"), L(t.exp !== void 0, "internal-error"), L(t.iat !== void 0, "internal-error"), Number(t.exp) - Number(t.iat);
}
async function En(e, t, n = !1) {
	if (n) return t;
	try {
		return await t;
	} catch (t) {
		throw t instanceof b && Dn(t) && e.auth.currentUser === e && await e.auth.signOut(), t;
	}
}
function Dn({ code: e }) {
	return e === "auth/user-disabled" || e === "auth/user-token-expired";
}
var On = class {
	constructor(e) {
		this.user = e, this.isRunning = !1, this.timerId = null, this.errorBackoff = 3e4;
	}
	_start() {
		this.isRunning || (this.isRunning = !0, this.schedule());
	}
	_stop() {
		this.isRunning && (this.isRunning = !1, this.timerId !== null && clearTimeout(this.timerId));
	}
	getInterval(e) {
		if (e) {
			let e = this.errorBackoff;
			return this.errorBackoff = Math.min(this.errorBackoff * 2, 96e4), e;
		}
		{
			this.errorBackoff = 3e4;
			let e = (this.user.stsTokenManager.expirationTime ?? 0) - Date.now() - 3e5;
			return Math.max(0, e);
		}
	}
	schedule(e = !1) {
		if (!this.isRunning) return;
		let t = this.getInterval(e);
		this.timerId = setTimeout(async () => {
			await this.iteration();
		}, t);
	}
	async iteration() {
		try {
			await this.user.getIdToken(!0);
		} catch (e) {
			e?.code === "auth/network-request-failed" && this.schedule(!0);
			return;
		}
		this.schedule();
	}
}, kn = class {
	constructor(e, t) {
		this.createdAt = e, this.lastLoginAt = t, this._initializeTime();
	}
	_initializeTime() {
		this.lastSignInTime = W(this.lastLoginAt), this.creationTime = W(this.createdAt);
	}
	_copy(e) {
		this.createdAt = e.createdAt, this.lastLoginAt = e.lastLoginAt, this._initializeTime();
	}
	toJSON() {
		return {
			createdAt: this.createdAt,
			lastLoginAt: this.lastLoginAt
		};
	}
};
async function An(e) {
	let t = e.auth, n = await En(e, xn(t, { idToken: await e.getIdToken() }));
	L(n?.users.length, t, "internal-error");
	let r = n.users[0];
	e._notifyReloadListener(r);
	let i = r.providerUserInfo?.length ? Nn(r.providerUserInfo) : [], a = Mn(e.providerData, i), o = e.isAnonymous, s = !(e.email && r.passwordHash) && !a?.length, c = o ? s : !1, l = {
		uid: r.localId,
		displayName: r.displayName || null,
		photoURL: r.photoUrl || null,
		email: r.email || null,
		emailVerified: r.emailVerified || !1,
		phoneNumber: r.phoneNumber || null,
		tenantId: r.tenantId || null,
		providerData: a,
		metadata: new kn(r.createdAt, r.lastLoginAt),
		isAnonymous: c
	};
	Object.assign(e, l);
}
async function jn(e) {
	let t = w(e);
	await An(t), await t.auth._persistUserIfCurrent(t), t.auth._notifyListenersIfCurrent(t);
}
function Mn(e, t) {
	return [...e.filter((e) => !t.some((t) => t.providerId === e.providerId)), ...t];
}
function Nn(e) {
	return e.map(({ providerId: e, ...t }) => ({
		providerId: e,
		uid: t.rawId || "",
		displayName: t.displayName || null,
		email: t.email || null,
		phoneNumber: t.phoneNumber || null,
		photoURL: t.photoUrl || null
	}));
}
async function Pn(e, t) {
	let n = await pn(e, {}, async () => {
		let n = oe({
			grant_type: "refresh_token",
			refresh_token: t
		}).slice(1), { tokenApiHost: r, apiKey: i } = e.config, a = await mn(e, r, "/v1/token", `key=${i}`), o = await e._getAdditionalHeaders();
		o["Content-Type"] = "application/x-www-form-urlencoded";
		let s = {
			method: "POST",
			headers: o,
			body: n
		};
		return e.emulatorConfig && de(e.emulatorConfig.host) && (s.credentials = "include"), ln.fetch()(a, s);
	});
	return {
		accessToken: n.access_token,
		expiresIn: n.expires_in,
		refreshToken: n.refresh_token
	};
}
async function Fn(e, t) {
	return V(e, "POST", "/v2/accounts:revokeToken", B(e, t));
}
var In = class e {
	constructor() {
		this.refreshToken = null, this.accessToken = null, this.expirationTime = null;
	}
	get isExpired() {
		return !this.expirationTime || Date.now() > this.expirationTime - 3e4;
	}
	updateFromServerResponse(e) {
		L(e.idToken, "internal-error"), L(e.idToken !== void 0, "internal-error"), L(e.refreshToken !== void 0, "internal-error");
		let t = "expiresIn" in e && e.expiresIn !== void 0 ? Number(e.expiresIn) : Tn(e.idToken);
		this.updateTokensAndExpiration(e.idToken, e.refreshToken, t);
	}
	updateFromIdToken(e) {
		L(e.length !== 0, "internal-error");
		let t = Tn(e);
		this.updateTokensAndExpiration(e, null, t);
	}
	async getToken(e, t = !1) {
		return !t && this.accessToken && !this.isExpired ? this.accessToken : (L(this.refreshToken, e, "user-token-expired"), this.refreshToken ? (await this.refresh(e, this.refreshToken), this.accessToken) : null);
	}
	clearRefreshToken() {
		this.refreshToken = null;
	}
	async refresh(e, t) {
		let { accessToken: n, refreshToken: r, expiresIn: i } = await Pn(e, t);
		this.updateTokensAndExpiration(n, r, Number(i));
	}
	updateTokensAndExpiration(e, t, n) {
		this.refreshToken = t || null, this.accessToken = e || null, this.expirationTime = Date.now() + n * 1e3;
	}
	static fromJSON(t, n) {
		let { refreshToken: r, accessToken: i, expirationTime: a } = n, o = new e();
		return r && (L(typeof r == "string", "internal-error", { appName: t }), o.refreshToken = r), i && (L(typeof i == "string", "internal-error", { appName: t }), o.accessToken = i), a && (L(typeof a == "number", "internal-error", { appName: t }), o.expirationTime = a), o;
	}
	toJSON() {
		return {
			refreshToken: this.refreshToken,
			accessToken: this.accessToken,
			expirationTime: this.expirationTime
		};
	}
	_assign(e) {
		this.accessToken = e.accessToken, this.refreshToken = e.refreshToken, this.expirationTime = e.expirationTime;
	}
	_clone() {
		return Object.assign(new e(), this.toJSON());
	}
	_performRefresh() {
		return R("not implemented");
	}
};
function G(e, t) {
	L(typeof e == "string" || e === void 0, "internal-error", { appName: t });
}
var K = class e {
	constructor({ uid: e, auth: t, stsTokenManager: n, ...r }) {
		this.providerId = "firebase", this.proactiveRefresh = new On(this), this.reloadUserInfo = null, this.reloadListener = null, this.uid = e, this.auth = t, this.stsTokenManager = n, this.accessToken = n.accessToken, this.displayName = r.displayName || null, this.email = r.email || null, this.emailVerified = r.emailVerified || !1, this.phoneNumber = r.phoneNumber || null, this.photoURL = r.photoURL || null, this.isAnonymous = r.isAnonymous || !1, this.tenantId = r.tenantId || null, this.providerData = r.providerData ? [...r.providerData] : [], this.metadata = new kn(r.createdAt || void 0, r.lastLoginAt || void 0);
	}
	async getIdToken(e) {
		let t = await En(this, this.stsTokenManager.getToken(this.auth, e));
		return L(t, this.auth, "internal-error"), this.accessToken !== t && (this.accessToken = t, await this.auth._persistUserIfCurrent(this), this.auth._notifyListenersIfCurrent(this)), t;
	}
	getIdTokenResult(e) {
		return Sn(this, e);
	}
	reload() {
		return jn(this);
	}
	_assign(e) {
		this !== e && (L(this.uid === e.uid, this.auth, "internal-error"), this.displayName = e.displayName, this.photoURL = e.photoURL, this.email = e.email, this.emailVerified = e.emailVerified, this.phoneNumber = e.phoneNumber, this.isAnonymous = e.isAnonymous, this.tenantId = e.tenantId, this.providerData = e.providerData.map((e) => ({ ...e })), this.metadata._copy(e.metadata), this.stsTokenManager._assign(e.stsTokenManager));
	}
	_clone(t) {
		let n = new e({
			...this,
			auth: t,
			stsTokenManager: this.stsTokenManager._clone()
		});
		return n.metadata._copy(this.metadata), n;
	}
	_onReload(e) {
		L(!this.reloadListener, this.auth, "internal-error"), this.reloadListener = e, this.reloadUserInfo &&= (this._notifyReloadListener(this.reloadUserInfo), null);
	}
	_notifyReloadListener(e) {
		this.reloadListener ? this.reloadListener(e) : this.reloadUserInfo = e;
	}
	_startProactiveRefresh() {
		this.proactiveRefresh._start();
	}
	_stopProactiveRefresh() {
		this.proactiveRefresh._stop();
	}
	async _updateTokensIfNecessary(e, t = !1) {
		let n = !1;
		e.idToken && e.idToken !== this.stsTokenManager.accessToken && (this.stsTokenManager.updateFromServerResponse(e), n = !0), t && await An(this), await this.auth._persistUserIfCurrent(this), n && this.auth._notifyListenersIfCurrent(this);
	}
	async delete() {
		if (j(this.auth.app)) return Promise.reject(I(this.auth));
		let e = await this.getIdToken();
		return await En(this, bn(this.auth, { idToken: e })), this.stsTokenManager.clearRefreshToken(), this.auth.signOut();
	}
	toJSON() {
		return {
			uid: this.uid,
			email: this.email || void 0,
			emailVerified: this.emailVerified,
			displayName: this.displayName || void 0,
			isAnonymous: this.isAnonymous,
			photoURL: this.photoURL || void 0,
			phoneNumber: this.phoneNumber || void 0,
			tenantId: this.tenantId || void 0,
			providerData: this.providerData.map((e) => ({ ...e })),
			stsTokenManager: this.stsTokenManager.toJSON(),
			_redirectEventId: this._redirectEventId,
			...this.metadata.toJSON(),
			apiKey: this.auth.config.apiKey,
			appName: this.auth.name
		};
	}
	get refreshToken() {
		return this.stsTokenManager.refreshToken || "";
	}
	static _fromJSON(t, n) {
		let r = n.displayName ?? void 0, i = n.email ?? void 0, a = n.phoneNumber ?? void 0, o = n.photoURL ?? void 0, s = n.tenantId ?? void 0, c = n._redirectEventId ?? void 0, l = n.createdAt ?? void 0, u = n.lastLoginAt ?? void 0, { uid: d, emailVerified: f, isAnonymous: p, providerData: m, stsTokenManager: h } = n;
		L(d && h, t, "internal-error");
		let g = In.fromJSON(this.name, h);
		L(typeof d == "string", t, "internal-error"), G(r, t.name), G(i, t.name), L(typeof f == "boolean", t, "internal-error"), L(typeof p == "boolean", t, "internal-error"), G(a, t.name), G(o, t.name), G(s, t.name), G(c, t.name), G(l, t.name), G(u, t.name);
		let _ = new e({
			uid: d,
			auth: t,
			email: i,
			emailVerified: f,
			displayName: r,
			isAnonymous: p,
			photoURL: o,
			phoneNumber: a,
			tenantId: s,
			stsTokenManager: g,
			createdAt: l,
			lastLoginAt: u
		});
		return m && Array.isArray(m) && (_.providerData = m.map((e) => ({ ...e }))), c && (_._redirectEventId = c), _;
	}
	static async _fromIdTokenResponse(t, n, r = !1) {
		let i = new In();
		i.updateFromServerResponse(n);
		let a = new e({
			uid: n.localId,
			auth: t,
			stsTokenManager: i,
			isAnonymous: r
		});
		return await An(a), a;
	}
	static async _fromGetAccountInfoResponse(t, n, r) {
		let i = n.users[0];
		L(i.localId !== void 0, "internal-error");
		let a = i.providerUserInfo === void 0 ? [] : Nn(i.providerUserInfo), o = !(i.email && i.passwordHash) && !a?.length, s = new In();
		s.updateFromIdToken(r);
		let c = new e({
			uid: i.localId,
			auth: t,
			stsTokenManager: s,
			isAnonymous: o
		}), l = {
			uid: i.localId,
			displayName: i.displayName || null,
			photoURL: i.photoUrl || null,
			email: i.email || null,
			emailVerified: i.emailVerified || !1,
			phoneNumber: i.phoneNumber || null,
			tenantId: i.tenantId || null,
			providerData: a,
			metadata: new kn(i.createdAt, i.lastLoginAt),
			isAnonymous: !(i.email && i.passwordHash) && !a?.length
		};
		return Object.assign(c, l), c;
	}
}, Ln = /* @__PURE__ */ new Map();
function q(e) {
	z(e instanceof Function, "Expected a class definition");
	let t = Ln.get(e);
	return t ? (z(t instanceof e, "Instance stored in cache mismatched with class"), t) : (t = new e(), Ln.set(e, t), t);
}
var Rn = class {
	constructor() {
		this.type = "NONE", this.storage = {};
	}
	async _isAvailable() {
		return !0;
	}
	async _set(e, t) {
		this.storage[e] = t;
	}
	async _get(e) {
		let t = this.storage[e];
		return t === void 0 ? null : t;
	}
	async _remove(e) {
		delete this.storage[e];
	}
	_addListener(e, t) {}
	_removeListener(e, t) {}
};
Rn.type = "NONE";
var zn = Rn;
function Bn(e, t, n) {
	return `firebase:${e}:${t}:${n}`;
}
var Vn = class e {
	constructor(e, t, n) {
		this.persistence = e, this.auth = t, this.userKey = n;
		let { config: r, name: i } = this.auth;
		this.fullUserKey = Bn(this.userKey, r.apiKey, i), this.fullPersistenceKey = Bn("persistence", r.apiKey, i), this.boundEventHandler = t._onStorageEvent.bind(t);
		try {
			this.persistence._addListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	setCurrentUser(e) {
		return this.persistence._set(this.fullUserKey, e.toJSON());
	}
	async getCurrentUser() {
		let e = await this.persistence._get(this.fullUserKey);
		if (!e) return null;
		if (typeof e == "string") {
			let t = await xn(this.auth, { idToken: e }).catch(() => void 0);
			return t ? K._fromGetAccountInfoResponse(this.auth, t, e) : null;
		}
		return K._fromJSON(this.auth, e);
	}
	removeCurrentUser() {
		return this.persistence._remove(this.fullUserKey);
	}
	savePersistenceForRedirect() {
		return this.persistence._set(this.fullPersistenceKey, this.persistence.type);
	}
	async setPersistence(e) {
		if (this.persistence === e) return;
		let t = await this.getCurrentUser();
		if (await this.removeCurrentUser(), this.persistence = e, t) return this.setCurrentUser(t);
	}
	delete() {
		try {
			this.persistence._removeListener(this.fullUserKey, this.boundEventHandler);
		} catch {}
	}
	static async create(t, n, r = "authUser") {
		if (!n.length) return new e(q(zn), t, r);
		let i = (await Promise.all(n.map(async (e) => {
			try {
				if (await e._isAvailable()) return e;
			} catch {
				return;
			}
		}))).filter((e) => e), a = i[0] || q(zn), o = Bn(r, t.config.apiKey, t.name), s = null;
		for (let e of n) try {
			let n = await e._get(o);
			if (n) {
				let r;
				if (typeof n == "string") {
					let e = await xn(t, { idToken: n }).catch(() => void 0);
					if (!e) break;
					r = await K._fromGetAccountInfoResponse(t, e, n);
				} else r = K._fromJSON(t, n);
				e !== a && (s = r), a = e;
				break;
			}
		} catch {}
		let c = i.filter((e) => e._shouldAllowMigration);
		return !a._shouldAllowMigration || !c.length ? new e(a, t, r) : (a = c[0], s && await a._set(o, s.toJSON()), await Promise.all(n.map(async (e) => {
			if (e !== a) try {
				await e._remove(o);
			} catch {}
		})), new e(a, t, r));
	}
};
function Hn(e) {
	let t = e.toLowerCase();
	if (t.includes("opera/") || t.includes("opr/") || t.includes("opios/")) return "Opera";
	if (Kn(t)) return "IEMobile";
	if (t.includes("msie") || t.includes("trident/")) return "IE";
	if (t.includes("edge/")) return "Edge";
	if (Un(t)) return "Firefox";
	if (t.includes("silk/")) return "Silk";
	if (Jn(t)) return "Blackberry";
	if (Yn(t)) return "Webos";
	if (Wn(t)) return "Safari";
	if ((t.includes("chrome/") || Gn(t)) && !t.includes("edge/")) return "Chrome";
	if (qn(t)) return "Android";
	{
		let t = e.match(/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/);
		if (t?.length === 2) return t[1];
	}
	return "Other";
}
function Un(e = h()) {
	return /firefox\//i.test(e);
}
function Wn(e = h()) {
	let t = e.toLowerCase();
	return t.includes("safari/") && !t.includes("chrome/") && !t.includes("crios/") && !t.includes("android");
}
function Gn(e = h()) {
	return /crios\//i.test(e);
}
function Kn(e = h()) {
	return /iemobile/i.test(e);
}
function qn(e = h()) {
	return /android/i.test(e);
}
function Jn(e = h()) {
	return /blackberry/i.test(e);
}
function Yn(e = h()) {
	return /webos/i.test(e);
}
function Xn(e, t = []) {
	let n;
	switch (e) {
		case "Browser":
			n = Hn(h());
			break;
		case "Worker":
			n = `${Hn(h())}-${e}`;
			break;
		default: n = e;
	}
	let r = t.length ? t.join(",") : "FirebaseCore-web";
	return `${n}/JsCore/${kt}/${r}`;
}
var Zn = class {
	constructor(e) {
		this.auth = e, this.queue = [];
	}
	pushCallback(e, t) {
		let n = (t) => new Promise((n, r) => {
			try {
				n(e(t));
			} catch (e) {
				r(e);
			}
		});
		n.onAbort = t, this.queue.push(n);
		let r = this.queue.length - 1;
		return () => {
			this.queue[r] = () => Promise.resolve();
		};
	}
	async runMiddleware(e) {
		if (this.auth.currentUser === e) return;
		let t = [];
		try {
			for (let n of this.queue) await n(e), n.onAbort && t.push(n.onAbort);
		} catch (e) {
			t.reverse();
			for (let e of t) try {
				e();
			} catch {}
			throw this.auth._errorFactory.create("login-blocked", { originalMessage: e?.message });
		}
	}
};
async function Qn(e, t = {}) {
	return V(e, "GET", "/v2/passwordPolicy", B(e, t));
}
var $n = 6, er = class {
	constructor(e) {
		let t = e.customStrengthOptions;
		this.customStrengthOptions = {}, this.customStrengthOptions.minPasswordLength = t.minPasswordLength ?? $n, t.maxPasswordLength && (this.customStrengthOptions.maxPasswordLength = t.maxPasswordLength), t.containsLowercaseCharacter !== void 0 && (this.customStrengthOptions.containsLowercaseLetter = t.containsLowercaseCharacter), t.containsUppercaseCharacter !== void 0 && (this.customStrengthOptions.containsUppercaseLetter = t.containsUppercaseCharacter), t.containsNumericCharacter !== void 0 && (this.customStrengthOptions.containsNumericCharacter = t.containsNumericCharacter), t.containsNonAlphanumericCharacter !== void 0 && (this.customStrengthOptions.containsNonAlphanumericCharacter = t.containsNonAlphanumericCharacter), this.enforcementState = e.enforcementState, this.enforcementState === "ENFORCEMENT_STATE_UNSPECIFIED" && (this.enforcementState = "OFF"), this.allowedNonAlphanumericCharacters = e.allowedNonAlphanumericCharacters?.join("") ?? "", this.forceUpgradeOnSignin = e.forceUpgradeOnSignin ?? !1, this.schemaVersion = e.schemaVersion;
	}
	validatePassword(e) {
		let t = {
			isValid: !0,
			passwordPolicy: this
		};
		return this.validatePasswordLengthOptions(e, t), this.validatePasswordCharacterOptions(e, t), t.isValid &&= t.meetsMinPasswordLength ?? !0, t.isValid &&= t.meetsMaxPasswordLength ?? !0, t.isValid &&= t.containsLowercaseLetter ?? !0, t.isValid &&= t.containsUppercaseLetter ?? !0, t.isValid &&= t.containsNumericCharacter ?? !0, t.isValid &&= t.containsNonAlphanumericCharacter ?? !0, t;
	}
	validatePasswordLengthOptions(e, t) {
		let n = this.customStrengthOptions.minPasswordLength, r = this.customStrengthOptions.maxPasswordLength;
		n && (t.meetsMinPasswordLength = e.length >= n), r && (t.meetsMaxPasswordLength = e.length <= r);
	}
	validatePasswordCharacterOptions(e, t) {
		this.updatePasswordCharacterOptionsStatuses(t, !1, !1, !1, !1);
		let n;
		for (let r = 0; r < e.length; r++) n = e.charAt(r), this.updatePasswordCharacterOptionsStatuses(t, n >= "a" && n <= "z", n >= "A" && n <= "Z", n >= "0" && n <= "9", this.allowedNonAlphanumericCharacters.includes(n));
	}
	updatePasswordCharacterOptionsStatuses(e, t, n, r, i) {
		this.customStrengthOptions.containsLowercaseLetter && (e.containsLowercaseLetter ||= t), this.customStrengthOptions.containsUppercaseLetter && (e.containsUppercaseLetter ||= n), this.customStrengthOptions.containsNumericCharacter && (e.containsNumericCharacter ||= r), this.customStrengthOptions.containsNonAlphanumericCharacter && (e.containsNonAlphanumericCharacter ||= i);
	}
}, tr = class {
	constructor(e, t, n, r) {
		this.app = e, this.heartbeatServiceProvider = t, this.appCheckServiceProvider = n, this.config = r, this.currentUser = null, this.emulatorConfig = null, this.operations = Promise.resolve(), this.authStateSubscription = new rr(this), this.idTokenSubscription = new rr(this), this.beforeStateQueue = new Zn(this), this.redirectUser = null, this.isProactiveRefreshEnabled = !1, this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION = 1, this._canInitEmulator = !0, this._isInitialized = !1, this._deleted = !1, this._initializationPromise = null, this._popupRedirectResolver = null, this._errorFactory = Yt, this._agentRecaptchaConfig = null, this._tenantRecaptchaConfigs = {}, this._projectPasswordPolicy = null, this._tenantPasswordPolicies = {}, this._resolvePersistenceManagerAvailable = void 0, this.lastNotifiedUid = void 0, this.languageCode = null, this.tenantId = null, this.settings = { appVerificationDisabledForTesting: !1 }, this.frameworks = [], this.name = e.name, this.clientVersion = r.sdkClientVersion, this._persistenceManagerAvailable = new Promise((e) => this._resolvePersistenceManagerAvailable = e);
	}
	_initializeWithPersistence(e, t) {
		return t && (this._popupRedirectResolver = q(t)), this._initializationPromise = this.queue(async () => {
			if (!this._deleted) {
				try {
					this.persistenceManager = await Vn.create(this, e);
				} catch (e) {
					Zt(`Failed to initialize persistence: ${e}`), this.persistenceManager = await Vn.create(this, []);
				} finally {
					this._resolvePersistenceManagerAvailable?.();
				}
				if (!this._deleted) {
					if (this._popupRedirectResolver?._shouldInitProactively) try {
						await this._popupRedirectResolver._initialize(this);
					} catch {}
					try {
						await this.initializeCurrentUser(t);
					} catch (e) {
						Zt(`Failed to initialize current user: ${e}`), await this.directlySetCurrentUser(null).catch(() => {});
					}
					this.lastNotifiedUid = this.currentUser?.uid || null, !this._deleted && (this._isInitialized = !0);
				}
			}
		}), this._initializationPromise;
	}
	async _onStorageEvent() {
		if (this._deleted) return;
		let e = await this.assertedPersistence.getCurrentUser();
		if (this.currentUser || e) {
			if (this.currentUser && e && this.currentUser.uid === e.uid) {
				this._currentUser._assign(e), await this.currentUser.getIdToken();
				return;
			}
			await this._updateCurrentUser(e, !0);
		}
	}
	async initializeCurrentUserFromIdToken(e) {
		try {
			let t = await xn(this, { idToken: e }), n = await K._fromGetAccountInfoResponse(this, t, e);
			await this.directlySetCurrentUser(n);
		} catch (e) {
			console.warn("FirebaseServerApp could not login user with provided authIdToken: ", e), await this.directlySetCurrentUser(null);
		}
	}
	async initializeCurrentUser(e) {
		if (j(this.app)) {
			let e = this.app.settings.authIdToken;
			return e ? new Promise((t) => {
				setTimeout(() => this.initializeCurrentUserFromIdToken(e).then(t, t));
			}) : this.directlySetCurrentUser(null);
		}
		let t = await this.assertedPersistence.getCurrentUser(), n = t, r = !1;
		if (e && this.config.authDomain) {
			await this.getOrInitRedirectPersistenceManager();
			let t = this.redirectUser?._redirectEventId, i = n?._redirectEventId, a = await this.tryRedirectSignIn(e);
			(!t || t === i) && a?.user && (n = a.user, r = !0);
		}
		if (!n) return this.directlySetCurrentUser(null);
		if (!n._redirectEventId) {
			if (r) try {
				await this.beforeStateQueue.runMiddleware(n);
			} catch (e) {
				n = t, this._popupRedirectResolver._overrideRedirectResult(this, () => Promise.reject(e));
			}
			return n ? this.reloadAndSetCurrentUserOrClear(n) : this.directlySetCurrentUser(null);
		}
		return L(this._popupRedirectResolver, this, "argument-error"), await this.getOrInitRedirectPersistenceManager(), this.redirectUser && this.redirectUser._redirectEventId === n._redirectEventId ? this.directlySetCurrentUser(n) : this.reloadAndSetCurrentUserOrClear(n);
	}
	async tryRedirectSignIn(e) {
		let t = null;
		try {
			t = await this._popupRedirectResolver._completeRedirectFn(this, e, !0);
		} catch {
			await this._setRedirectUser(null);
		}
		return t;
	}
	async reloadAndSetCurrentUserOrClear(e) {
		try {
			await An(e);
		} catch (e) {
			let t = e?.code;
			if (t !== "auth/network-request-failed" && t !== "auth/too-many-requests" && !t?.startsWith("auth/quota-exceeded")) return this.directlySetCurrentUser(null);
		}
		return this.directlySetCurrentUser(e);
	}
	useDeviceLanguage() {
		this.languageCode = on();
	}
	async _delete() {
		this._deleted = !0;
	}
	async updateCurrentUser(e) {
		if (j(this.app)) return Promise.reject(I(this));
		let t = e ? w(e) : null;
		return t && L(t.auth.config.apiKey === this.config.apiKey, this, "invalid-user-token"), this._updateCurrentUser(t && t._clone(this));
	}
	async _updateCurrentUser(e, t = !1) {
		if (!this._deleted) return e && L(this.tenantId === e.tenantId, this, "tenant-id-mismatch"), t || await this.beforeStateQueue.runMiddleware(e), this.queue(async () => {
			await this.directlySetCurrentUser(e), this.notifyAuthListeners();
		});
	}
	async signOut() {
		return j(this.app) ? Promise.reject(I(this)) : (await this.beforeStateQueue.runMiddleware(null), (this.redirectPersistenceManager || this._popupRedirectResolver) && await this._setRedirectUser(null), this._updateCurrentUser(null, !0));
	}
	setPersistence(e) {
		return j(this.app) ? Promise.reject(I(this)) : this.queue(async () => {
			await this.assertedPersistence.setPersistence(q(e));
		});
	}
	_getRecaptchaConfig() {
		return this.tenantId == null ? this._agentRecaptchaConfig : this._tenantRecaptchaConfigs[this.tenantId];
	}
	async validatePassword(e) {
		this._getPasswordPolicyInternal() || await this._updatePasswordPolicy();
		let t = this._getPasswordPolicyInternal();
		return t.schemaVersion === this.EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION ? t.validatePassword(e) : Promise.reject(this._errorFactory.create("unsupported-password-policy-schema-version", {}));
	}
	_getPasswordPolicyInternal() {
		return this.tenantId === null ? this._projectPasswordPolicy : this._tenantPasswordPolicies[this.tenantId];
	}
	async _updatePasswordPolicy() {
		let e = new er(await Qn(this));
		this.tenantId === null ? this._projectPasswordPolicy = e : this._tenantPasswordPolicies[this.tenantId] = e;
	}
	_getPersistenceType() {
		return this.assertedPersistence.persistence.type;
	}
	_getPersistence() {
		return this.assertedPersistence.persistence;
	}
	_updateErrorMap(e) {
		this._errorFactory = new x("auth", "Firebase", e());
	}
	onAuthStateChanged(e, t, n) {
		return this.registerStateListener(this.authStateSubscription, e, t, n);
	}
	beforeAuthStateChanged(e, t) {
		return this.beforeStateQueue.pushCallback(e, t);
	}
	onIdTokenChanged(e, t, n) {
		return this.registerStateListener(this.idTokenSubscription, e, t, n);
	}
	authStateReady() {
		return new Promise((e, t) => {
			if (this.currentUser) e();
			else {
				let n = this.onAuthStateChanged(() => {
					n(), e();
				}, t);
			}
		});
	}
	async revokeAccessToken(e) {
		if (this.currentUser) {
			let t = {
				providerId: "apple.com",
				tokenType: "ACCESS_TOKEN",
				token: e,
				idToken: await this.currentUser.getIdToken()
			};
			this.tenantId != null && (t.tenantId = this.tenantId), await Fn(this, t);
		}
	}
	toJSON() {
		return {
			apiKey: this.config.apiKey,
			authDomain: this.config.authDomain,
			appName: this.name,
			currentUser: this._currentUser?.toJSON()
		};
	}
	async _setRedirectUser(e, t) {
		let n = await this.getOrInitRedirectPersistenceManager(t);
		return e === null ? n.removeCurrentUser() : n.setCurrentUser(e);
	}
	async getOrInitRedirectPersistenceManager(e) {
		if (!this.redirectPersistenceManager) {
			let t = e && q(e) || this._popupRedirectResolver;
			L(t, this, "argument-error"), this.redirectPersistenceManager = await Vn.create(this, [q(t._redirectPersistence)], "redirectUser"), this.redirectUser = await this.redirectPersistenceManager.getCurrentUser();
		}
		return this.redirectPersistenceManager;
	}
	async _redirectUserForId(e) {
		return this._isInitialized && await this.queue(async () => {}), this._currentUser?._redirectEventId === e ? this._currentUser : this.redirectUser?._redirectEventId === e ? this.redirectUser : null;
	}
	async _persistUserIfCurrent(e) {
		if (e === this.currentUser) return this.queue(async () => this.directlySetCurrentUser(e));
	}
	_notifyListenersIfCurrent(e) {
		e === this.currentUser && this.notifyAuthListeners();
	}
	_key() {
		return `${this.config.authDomain}:${this.config.apiKey}:${this.name}`;
	}
	_startProactiveRefresh() {
		this.isProactiveRefreshEnabled = !0, this.currentUser && this._currentUser._startProactiveRefresh();
	}
	_stopProactiveRefresh() {
		this.isProactiveRefreshEnabled = !1, this.currentUser && this._currentUser._stopProactiveRefresh();
	}
	get _currentUser() {
		return this.currentUser;
	}
	notifyAuthListeners() {
		if (!this._isInitialized) return;
		this.idTokenSubscription.next(this.currentUser);
		let e = this.currentUser?.uid ?? null;
		this.lastNotifiedUid !== e && (this.lastNotifiedUid = e, this.authStateSubscription.next(this.currentUser));
	}
	registerStateListener(e, t, n, r) {
		if (this._deleted) return () => {};
		let i = typeof t == "function" ? t : t.next.bind(t), a = !1, o = this._isInitialized ? Promise.resolve() : this._initializationPromise;
		if (L(o, this, "internal-error"), o.then(() => {
			a || i(this.currentUser);
		}).catch((e) => {
			if (!a) {
				if (typeof t != "function" && t.error) t.error(e);
				else if (n) n(e);
				else throw e;
			}
		}), typeof t == "function") {
			let i = e.addObserver(t, n, r);
			return () => {
				a = !0, i();
			};
		}
		{
			let n = e.addObserver(t);
			return () => {
				a = !0, n();
			};
		}
	}
	async directlySetCurrentUser(e) {
		if (this.currentUser && this.currentUser !== e && this._currentUser._stopProactiveRefresh(), e && this.isProactiveRefreshEnabled && e._startProactiveRefresh(), this.currentUser = e, this.persistenceManager) try {
			e ? await this.persistenceManager.setCurrentUser(e) : await this.persistenceManager.removeCurrentUser();
		} catch (e) {
			let t = e?.message || String(e), n = en(this, "internal-error", `An internal AuthError has occurred: ${t}`);
			throw n.customData = { originalError: e }, n;
		}
	}
	queue(e) {
		return this.operations = this.operations.then(e, e), this.operations;
	}
	get assertedPersistence() {
		return L(this.persistenceManager, this, "internal-error"), this.persistenceManager;
	}
	_logFramework(e) {
		e && !this.frameworks.includes(e) && (this.frameworks.push(e), this.frameworks.sort(), this.clientVersion = Xn(this.config.clientPlatform, this._getFrameworks()));
	}
	_getFrameworks() {
		return this.frameworks;
	}
	async _getAdditionalHeaders() {
		let e = { "X-Client-Version": this.clientVersion };
		this.app.options.appId && (e["X-Firebase-gmpid"] = this.app.options.appId);
		let t = await this.heartbeatServiceProvider.getImmediate({ optional: !0 })?.getHeartbeatsHeader();
		t && (e["X-Firebase-Client"] = t);
		let n = await this._getAppCheckToken();
		return n && (e["X-Firebase-AppCheck"] = n), e;
	}
	async _getAppCheckToken() {
		if (j(this.app) && this.app.settings.appCheckToken) return this.app.settings.appCheckToken;
		let e = await this.appCheckServiceProvider.getImmediate({ optional: !0 })?.getToken();
		return e?.error && Zt(`Error while retrieving App Check token: ${e.error}`), e?.token;
	}
};
function nr(e) {
	return w(e);
}
var rr = class {
	constructor(e) {
		this.auth = e, this.observer = null, this.addObserver = se((e) => this.observer = e);
	}
	get next() {
		return L(this.observer, this.auth, "internal-error"), this.observer.next.bind(this.observer);
	}
}, ir = {
	async loadJS() {
		throw Error("Unable to load external scripts");
	},
	recaptchaV2Script: "",
	recaptchaEnterpriseScript: "",
	gapiScript: ""
};
function ar(e) {
	return ir.loadJS(e);
}
function or() {
	return ir.recaptchaEnterpriseScript;
}
var sr = class {
	constructor() {
		this.enterprise = new cr();
	}
	ready(e) {
		e();
	}
	execute(e, t) {
		return Promise.resolve("token");
	}
	render(e, t) {
		return "";
	}
}, cr = class {
	ready(e) {
		e();
	}
	execute(e, t) {
		return Promise.resolve("token");
	}
	render(e, t) {
		return "";
	}
}, lr = "recaptcha-enterprise", ur = "NO_RECAPTCHA", dr = "onFirebaseAuthREInstanceReady", fr = class e {
	constructor(e) {
		this.type = lr, this.auth = nr(e);
	}
	async verify(t = "verify", n = !1) {
		async function r(e) {
			if (!n) {
				if (e.tenantId == null && e._agentRecaptchaConfig != null) return e._agentRecaptchaConfig.siteKey;
				if (e.tenantId != null && e._tenantRecaptchaConfigs[e.tenantId] !== void 0) return e._tenantRecaptchaConfigs[e.tenantId].siteKey;
			}
			return new Promise(async (t, n) => {
				yn(e, {
					clientType: "CLIENT_TYPE_WEB",
					version: "RECAPTCHA_ENTERPRISE"
				}).then((r) => {
					if (r.recaptchaKey === void 0) n(/* @__PURE__ */ Error("recaptcha Enterprise site key undefined"));
					else {
						let n = new vn(r);
						return e.tenantId == null ? e._agentRecaptchaConfig = n : e._tenantRecaptchaConfigs[e.tenantId] = n, t(n.siteKey);
					}
				}).catch((e) => {
					n(e);
				});
			});
		}
		function i(e, n, r) {
			let i = window.grecaptcha;
			_n(i) ? i.enterprise.ready(() => {
				i.enterprise.execute(e, { action: t }).then((e) => {
					n(e);
				}).catch(() => {
					n(ur);
				});
			}) : r(Error("No reCAPTCHA enterprise script loaded."));
		}
		return this.auth.settings.appVerificationDisabledForTesting ? new sr().execute("siteKey", { action: "verify" }) : new Promise((t, a) => {
			r(this.auth).then(async (r) => {
				if (!n && _n(window.grecaptcha) && e.scriptInjectionDeferred) await e.scriptInjectionDeferred.promise, i(r, t, a);
				else {
					if (typeof window > "u") {
						a(/* @__PURE__ */ Error("RecaptchaVerifier is only supported in browser"));
						return;
					}
					let n = or();
					n.length !== 0 && (n += r + `&onload=${dr}`), e.scriptInjectionDeferred = new m(), window[dr] = () => {
						e.scriptInjectionDeferred?.resolve();
					}, ar(n).then(() => e.scriptInjectionDeferred?.promise).then(() => {
						i(r, t, a);
					}).catch((e) => {
						a(e);
					});
				}
			}).catch((e) => {
				a(e);
			});
		});
	}
};
fr.scriptInjectionDeferred = null;
async function J(e, t, n, r = !1, i = !1) {
	let a = new fr(e), o;
	if (i) o = ur;
	else try {
		o = await a.verify(n);
	} catch {
		o = await a.verify(n, !0);
	}
	let s = { ...t };
	if (n === "mfaSmsEnrollment" || n === "mfaSmsSignIn") {
		if ("phoneEnrollmentInfo" in s) {
			let e = s.phoneEnrollmentInfo.phoneNumber, t = s.phoneEnrollmentInfo.recaptchaToken;
			Object.assign(s, { phoneEnrollmentInfo: {
				phoneNumber: e,
				recaptchaToken: t,
				captchaResponse: o,
				clientType: "CLIENT_TYPE_WEB",
				recaptchaVersion: "RECAPTCHA_ENTERPRISE"
			} });
		} else if ("phoneSignInInfo" in s) {
			let e = s.phoneSignInInfo.recaptchaToken;
			Object.assign(s, { phoneSignInInfo: {
				recaptchaToken: e,
				captchaResponse: o,
				clientType: "CLIENT_TYPE_WEB",
				recaptchaVersion: "RECAPTCHA_ENTERPRISE"
			} });
		}
		return s;
	}
	return r ? Object.assign(s, { captchaResp: o }) : Object.assign(s, { captchaResponse: o }), Object.assign(s, { clientType: "CLIENT_TYPE_WEB" }), Object.assign(s, { recaptchaVersion: "RECAPTCHA_ENTERPRISE" }), s;
}
async function pr(e, t, n, r, i) {
	return i === "EMAIL_PASSWORD_PROVIDER" ? e._getRecaptchaConfig()?.isProviderEnabled("EMAIL_PASSWORD_PROVIDER") ? r(e, await J(e, t, n, n === "getOobCode")) : r(e, t).catch(async (i) => i.code === "auth/missing-recaptcha-token" ? (console.log(`${n} is protected by reCAPTCHA Enterprise for this project. Automatically triggering the reCAPTCHA flow and restarting the flow.`), r(e, await J(e, t, n, n === "getOobCode"))) : Promise.reject(i)) : i === "PHONE_PROVIDER" ? e._getRecaptchaConfig()?.isProviderEnabled("PHONE_PROVIDER") ? r(e, await J(e, t, n)).catch(async (i) => e._getRecaptchaConfig()?.getProviderEnforcementState("PHONE_PROVIDER") === "AUDIT" && (i.code === "auth/missing-recaptcha-token" || i.code === "auth/invalid-app-credential") ? (console.log(`Failed to verify with reCAPTCHA Enterprise. Automatically triggering the reCAPTCHA v2 flow to complete the ${n} flow.`), r(e, await J(e, t, n, !1, !0))) : Promise.reject(i)) : r(e, await J(e, t, n, !1, !0)) : Promise.reject(i + " provider is not supported.");
}
function mr(e, t) {
	let n = Dt(e, "auth");
	if (n.isInitialized()) {
		let e = n.getImmediate();
		if (ie(n.getOptions(), t ?? {})) return e;
		F(e, "already-initialized");
	}
	return n.initialize({ options: t });
}
function hr(e, t) {
	let n = t?.persistence || [], r = (Array.isArray(n) ? n : [n]).map(q);
	t?.errorMap && e._updateErrorMap(t.errorMap), e._initializeWithPersistence(r, t?.popupRedirectResolver);
}
var gr = class {
	constructor(e, t) {
		this.providerId = e, this.signInMethod = t;
	}
	toJSON() {
		return R("not implemented");
	}
	_getIdTokenResponse(e) {
		return R("not implemented");
	}
	_linkToIdToken(e, t) {
		return R("not implemented");
	}
	_getReauthenticationResolver(e) {
		return R("not implemented");
	}
};
async function _r(e, t) {
	return V(e, "POST", "/v1/accounts:signUp", t);
}
async function vr(e, t) {
	return H(e, "POST", "/v1/accounts:signInWithPassword", B(e, t));
}
async function yr(e, t) {
	return H(e, "POST", "/v1/accounts:signInWithEmailLink", B(e, t));
}
async function br(e, t) {
	return H(e, "POST", "/v1/accounts:signInWithEmailLink", B(e, t));
}
var xr = class e extends gr {
	constructor(e, t, n, r = null) {
		super("password", n), this._email = e, this._password = t, this._tenantId = r;
	}
	static _fromEmailAndPassword(t, n) {
		return new e(t, n, "password");
	}
	static _fromEmailAndCode(t, n, r = null) {
		return new e(t, n, "emailLink", r);
	}
	toJSON() {
		return {
			email: this._email,
			password: this._password,
			signInMethod: this.signInMethod,
			tenantId: this._tenantId
		};
	}
	static fromJSON(e) {
		let t = typeof e == "string" ? JSON.parse(e) : e;
		if (t?.email && t?.password) {
			if (t.signInMethod === "password") return this._fromEmailAndPassword(t.email, t.password);
			if (t.signInMethod === "emailLink") return this._fromEmailAndCode(t.email, t.password, t.tenantId);
		}
		return null;
	}
	async _getIdTokenResponse(e) {
		switch (this.signInMethod) {
			case "password": return pr(e, {
				returnSecureToken: !0,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signInWithPassword", vr, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return yr(e, {
				email: this._email,
				oobCode: this._password
			});
			default: F(e, "internal-error");
		}
	}
	async _linkToIdToken(e, t) {
		switch (this.signInMethod) {
			case "password": return pr(e, {
				idToken: t,
				returnSecureToken: !0,
				email: this._email,
				password: this._password,
				clientType: "CLIENT_TYPE_WEB"
			}, "signUpPassword", _r, "EMAIL_PASSWORD_PROVIDER");
			case "emailLink": return br(e, {
				idToken: t,
				email: this._email,
				oobCode: this._password
			});
			default: F(e, "internal-error");
		}
	}
	_getReauthenticationResolver(e) {
		return this._getIdTokenResponse(e);
	}
};
async function Sr(e, t) {
	return H(e, "POST", "/v1/accounts:signInWithIdp", B(e, t));
}
var Cr = "http://localhost", wr = class e extends gr {
	constructor() {
		super(...arguments), this.pendingToken = null;
	}
	static _fromParams(t) {
		let n = new e(t.providerId, t.signInMethod);
		return t.idToken || t.accessToken ? (t.idToken && (n.idToken = t.idToken), t.accessToken && (n.accessToken = t.accessToken), t.nonce && !t.pendingToken && (n.nonce = t.nonce), t.pendingToken && (n.pendingToken = t.pendingToken)) : t.oauthToken && t.oauthTokenSecret ? (n.accessToken = t.oauthToken, n.secret = t.oauthTokenSecret) : F("argument-error"), n;
	}
	toJSON() {
		return {
			idToken: this.idToken,
			accessToken: this.accessToken,
			secret: this.secret,
			nonce: this.nonce,
			pendingToken: this.pendingToken,
			providerId: this.providerId,
			signInMethod: this.signInMethod
		};
	}
	static fromJSON(t) {
		let { providerId: n, signInMethod: r, ...i } = typeof t == "string" ? JSON.parse(t) : t;
		if (!n || !r) return null;
		let a = new e(n, r);
		return a.idToken = i.idToken || void 0, a.accessToken = i.accessToken || void 0, a.secret = i.secret, a.nonce = i.nonce, a.pendingToken = i.pendingToken || null, a;
	}
	_getIdTokenResponse(e) {
		return Sr(e, this.buildRequest());
	}
	_linkToIdToken(e, t) {
		let n = this.buildRequest();
		return n.idToken = t, Sr(e, n);
	}
	_getReauthenticationResolver(e) {
		let t = this.buildRequest();
		return t.autoCreate = !1, Sr(e, t);
	}
	buildRequest() {
		let e = {
			requestUri: Cr,
			returnSecureToken: !0
		};
		if (this.pendingToken) e.pendingToken = this.pendingToken;
		else {
			let t = {};
			this.idToken && (t.id_token = this.idToken), this.accessToken && (t.access_token = this.accessToken), this.secret && (t.oauth_token_secret = this.secret), t.providerId = this.providerId, this.nonce && !this.pendingToken && (t.nonce = this.nonce), e.postBody = oe(t);
		}
		return e;
	}
};
function Tr(e) {
	switch (e) {
		case "recoverEmail": return "RECOVER_EMAIL";
		case "resetPassword": return "PASSWORD_RESET";
		case "signIn": return "EMAIL_SIGNIN";
		case "verifyEmail": return "VERIFY_EMAIL";
		case "verifyAndChangeEmail": return "VERIFY_AND_CHANGE_EMAIL";
		case "revertSecondFactorAddition": return "REVERT_SECOND_FACTOR_ADDITION";
		default: return null;
	}
}
function Er(e) {
	let t = S(C(e)).link, n = t ? S(C(t)).deep_link_id : null, r = S(C(e)).deep_link_id;
	return (r ? S(C(r)).link : null) || r || n || t || e;
}
var Dr = class e {
	constructor(e) {
		let t = S(C(e)), n = t.apiKey ?? null, r = t.oobCode ?? null, i = Tr(t.mode ?? null);
		L(n && r && i, "argument-error"), this.apiKey = n, this.operation = i, this.code = r, this.continueUrl = t.continueUrl ?? null, this.languageCode = t.lang ?? null, this.tenantId = t.tenantId ?? null;
	}
	static parseLink(t) {
		let n = Er(t);
		try {
			return new e(n);
		} catch {
			return null;
		}
	}
}, Or = class e {
	constructor() {
		this.providerId = e.PROVIDER_ID;
	}
	static credential(e, t) {
		return xr._fromEmailAndPassword(e, t);
	}
	static credentialWithLink(e, t) {
		let n = Dr.parseLink(t);
		return L(n, "argument-error"), xr._fromEmailAndCode(e, n.code, n.tenantId);
	}
};
Or.PROVIDER_ID = "password", Or.EMAIL_PASSWORD_SIGN_IN_METHOD = "password", Or.EMAIL_LINK_SIGN_IN_METHOD = "emailLink";
var kr = class {
	constructor(e) {
		this.providerId = e, this.defaultLanguageCode = null, this.customParameters = {};
	}
	setDefaultLanguage(e) {
		this.defaultLanguageCode = e;
	}
	setCustomParameters(e) {
		return this.customParameters = e, this;
	}
	getCustomParameters() {
		return this.customParameters;
	}
}, Ar = class extends kr {
	constructor() {
		super(...arguments), this.scopes = [];
	}
	addScope(e) {
		return this.scopes.includes(e) || this.scopes.push(e), this;
	}
	getScopes() {
		return [...this.scopes];
	}
}, jr = class e extends Ar {
	constructor() {
		super("facebook.com");
	}
	static credential(t) {
		return wr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.FACEBOOK_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
jr.FACEBOOK_SIGN_IN_METHOD = "facebook.com", jr.PROVIDER_ID = "facebook.com";
var Mr = class e extends Ar {
	constructor() {
		super("google.com"), this.addScope("profile");
	}
	static credential(t, n) {
		return wr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GOOGLE_SIGN_IN_METHOD,
			idToken: t,
			accessToken: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthIdToken: n, oauthAccessToken: r } = t;
		if (!n && !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
Mr.GOOGLE_SIGN_IN_METHOD = "google.com", Mr.PROVIDER_ID = "google.com";
var Nr = class e extends Ar {
	constructor() {
		super("github.com");
	}
	static credential(t) {
		return wr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.GITHUB_SIGN_IN_METHOD,
			accessToken: t
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t || !("oauthAccessToken" in t) || !t.oauthAccessToken) return null;
		try {
			return e.credential(t.oauthAccessToken);
		} catch {
			return null;
		}
	}
};
Nr.GITHUB_SIGN_IN_METHOD = "github.com", Nr.PROVIDER_ID = "github.com";
var Pr = class e extends Ar {
	constructor() {
		super("twitter.com");
	}
	static credential(t, n) {
		return wr._fromParams({
			providerId: e.PROVIDER_ID,
			signInMethod: e.TWITTER_SIGN_IN_METHOD,
			oauthToken: t,
			oauthTokenSecret: n
		});
	}
	static credentialFromResult(t) {
		return e.credentialFromTaggedObject(t);
	}
	static credentialFromError(t) {
		return e.credentialFromTaggedObject(t.customData || {});
	}
	static credentialFromTaggedObject({ _tokenResponse: t }) {
		if (!t) return null;
		let { oauthAccessToken: n, oauthTokenSecret: r } = t;
		if (!n || !r) return null;
		try {
			return e.credential(n, r);
		} catch {
			return null;
		}
	}
};
Pr.TWITTER_SIGN_IN_METHOD = "twitter.com", Pr.PROVIDER_ID = "twitter.com";
var Fr = class e {
	constructor(e) {
		this.user = e.user, this.providerId = e.providerId, this._tokenResponse = e._tokenResponse, this.operationType = e.operationType;
	}
	static async _fromIdTokenResponse(t, n, r, i = !1) {
		let a = await K._fromIdTokenResponse(t, r, i), o = Ir(r);
		return new e({
			user: a,
			providerId: o,
			_tokenResponse: r,
			operationType: n
		});
	}
	static async _forOperation(t, n, r) {
		await t._updateTokensIfNecessary(r, !0);
		let i = Ir(r);
		return new e({
			user: t,
			providerId: i,
			_tokenResponse: r,
			operationType: n
		});
	}
};
function Ir(e) {
	return e.providerId ? e.providerId : "phoneNumber" in e ? "phone" : null;
}
var Lr = class e extends b {
	constructor(t, n, r, i) {
		super(n.code, n.message), this.operationType = r, this.user = i, Object.setPrototypeOf(this, e.prototype), this.customData = {
			appName: t.name,
			tenantId: t.tenantId ?? void 0,
			_serverResponse: n.customData._serverResponse,
			operationType: r
		};
	}
	static _fromErrorAndOperation(t, n, r, i) {
		return new e(t, n, r, i);
	}
};
function Rr(e, t, n, r) {
	return (t === "reauthenticate" ? n._getReauthenticationResolver(e) : n._getIdTokenResponse(e)).catch((n) => {
		throw n.code === "auth/multi-factor-auth-required" ? Lr._fromErrorAndOperation(e, n, t, r) : n;
	});
}
async function zr(e, t, n = !1) {
	if (j(e.app)) return Promise.reject(I(e));
	let r = "signIn", i = await Rr(e, r, t), a = await Fr._fromIdTokenResponse(e, r, i);
	return n || await e._updateCurrentUser(a.user), a;
}
async function Br(e, t) {
	return zr(nr(e), t);
}
async function Vr(e) {
	let t = nr(e);
	t._getPasswordPolicyInternal() && await t._updatePasswordPolicy();
}
function Hr(e, t, n) {
	return j(e.app) ? Promise.reject(I(e)) : Br(w(e), Or.credential(t, n)).catch(async (t) => {
		throw t.code === "auth/password-does-not-meet-requirements" && Vr(e), t;
	});
}
function Ur(e, t, n, r) {
	return w(e).onAuthStateChanged(t, n, r);
}
function Wr(e) {
	return w(e).signOut();
}
var Gr = "__sak";
function Kr(e) {
	return Promise.all(e.map(async (e) => {
		try {
			return {
				fulfilled: !0,
				value: await e
			};
		} catch (e) {
			return {
				fulfilled: !1,
				reason: e
			};
		}
	}));
}
var qr = class e {
	constructor(e) {
		this.eventTarget = e, this.handlersMap = {}, this.boundEventHandler = this.handleEvent.bind(this);
	}
	static _getInstance(t) {
		let n = this.receivers.find((e) => e.isListeningto(t));
		if (n) return n;
		let r = new e(t);
		return this.receivers.push(r), r;
	}
	isListeningto(e) {
		return this.eventTarget === e;
	}
	async handleEvent(e) {
		let t = e, { eventId: n, eventType: r, data: i } = t.data, a = this.handlersMap[r];
		if (!a?.size) return;
		t.ports[0].postMessage({
			status: "ack",
			eventId: n,
			eventType: r
		});
		let o = await Kr(Array.from(a).map(async (e) => e(t.origin, i)));
		t.ports[0].postMessage({
			status: "done",
			eventId: n,
			eventType: r,
			response: o
		});
	}
	_subscribe(e, t) {
		Object.keys(this.handlersMap).length === 0 && this.eventTarget.addEventListener("message", this.boundEventHandler), this.handlersMap[e] || (this.handlersMap[e] = /* @__PURE__ */ new Set()), this.handlersMap[e].add(t);
	}
	_unsubscribe(e, t) {
		this.handlersMap[e] && t && this.handlersMap[e].delete(t), (!t || this.handlersMap[e].size === 0) && delete this.handlersMap[e], Object.keys(this.handlersMap).length === 0 && this.eventTarget.removeEventListener("message", this.boundEventHandler);
	}
};
qr.receivers = [];
function Jr(e = "", t = 10) {
	let n = "";
	for (let e = 0; e < t; e++) n += Math.floor(Math.random() * 10);
	return e + n;
}
var Yr = class {
	constructor(e) {
		this.target = e, this.handlers = /* @__PURE__ */ new Set();
	}
	removeMessageHandler(e) {
		e.messageChannel && (e.messageChannel.port1.removeEventListener("message", e.onMessage), e.messageChannel.port1.close()), this.handlers.delete(e);
	}
	async _send(e, t, n = 50) {
		let r = typeof MessageChannel < "u" ? new MessageChannel() : null;
		if (!r) throw Error("connection_unavailable");
		let i, a;
		return new Promise((o, s) => {
			let c = Jr("", 20);
			r.port1.start();
			let l = setTimeout(() => {
				s(/* @__PURE__ */ Error("unsupported_event"));
			}, n);
			a = {
				messageChannel: r,
				onMessage(e) {
					let t = e;
					if (t.data.eventId === c) switch (t.data.status) {
						case "ack":
							clearTimeout(l), i = setTimeout(() => {
								s(/* @__PURE__ */ Error("timeout"));
							}, 3e3);
							break;
						case "done":
							clearTimeout(i), o(t.data.response);
							break;
						default: clearTimeout(l), clearTimeout(i), s(/* @__PURE__ */ Error("invalid_response"));
					}
				}
			}, this.handlers.add(a), r.port1.addEventListener("message", a.onMessage), this.target.postMessage({
				eventType: e,
				eventId: c,
				data: t
			}, [r.port2]);
		}).finally(() => {
			a && this.removeMessageHandler(a);
		});
	}
};
function Xr() {
	return window;
}
function Zr() {
	return Xr().WorkerGlobalScope !== void 0 && typeof Xr().importScripts == "function";
}
async function Qr() {
	if (!navigator?.serviceWorker) return null;
	try {
		return (await navigator.serviceWorker.ready).active;
	} catch {
		return null;
	}
}
function $r() {
	return navigator?.serviceWorker?.controller || null;
}
function ei() {
	return Zr() ? self : null;
}
var ti = "firebaseLocalStorageDb", ni = 1, ri = "firebaseLocalStorage", ii = "fbase_key", Y = class {
	constructor(e) {
		this.request = e;
	}
	toPromise() {
		return new Promise((e, t) => {
			this.request.addEventListener("success", () => {
				e(this.request.result);
			}), this.request.addEventListener("error", () => {
				t(this.request.error);
			});
		});
	}
};
function X(e, t) {
	return e.transaction([ri], t ? "readwrite" : "readonly").objectStore(ri);
}
function ai() {
	return new Y(indexedDB.deleteDatabase(ti)).toPromise();
}
function oi() {
	let e = indexedDB.open(ti, ni);
	return new Promise((t, n) => {
		e.addEventListener("error", () => {
			n(e.error);
		}), e.addEventListener("upgradeneeded", () => {
			let t = e.result;
			try {
				t.createObjectStore(ri, { keyPath: ii });
			} catch (e) {
				n(e);
			}
		}), e.addEventListener("success", async () => {
			let n = e.result;
			n.objectStoreNames.contains(ri) ? t(n) : (n.close(), await ai(), t(await oi()));
		});
	});
}
async function si(e, t, n) {
	return new Y(X(e, !0).put({
		[ii]: t,
		value: n
	})).toPromise();
}
async function ci(e, t) {
	let n = await new Y(X(e, !1).get(t)).toPromise();
	return n === void 0 ? null : n.value;
}
function li(e, t) {
	return new Y(X(e, !0).delete(t)).toPromise();
}
var ui = 800, di = 3, fi = class {
	registerLifecycleListeners() {
		typeof window < "u" && typeof window.addEventListener == "function" && (window.addEventListener("pagehide", this.onPageHide), window.addEventListener("pageshow", this.onPageShow));
	}
	unregisterLifecycleListeners() {
		typeof window < "u" && typeof window.removeEventListener == "function" && (window.removeEventListener("pagehide", this.onPageHide), window.removeEventListener("pageshow", this.onPageShow));
	}
	constructor() {
		this.type = "LOCAL", this.dbPromise = null, this._shouldAllowMigration = !0, this.listeners = {}, this.localCache = {}, this.pollTimer = null, this.isClosing = !1, this.pendingWrites = 0, this.receiver = null, this.sender = null, this.serviceWorkerReceiverAvailable = !1, this.activeServiceWorker = null, this.onPageHide = () => {
			this.isClosing = !0, this.stopPolling(), this.dbPromise &&= (this.dbPromise.then((e) => e.close()).catch(() => {}), null);
		}, this.onPageShow = () => {
			this.isClosing && (this.isClosing = !1, Object.keys(this.listeners).length > 0 && this.startPolling());
		}, this._workerInitializationPromise = this.initializeServiceWorkerMessaging().then(() => {}, () => {});
	}
	async _openDb() {
		return this.dbPromise ? this.dbPromise : (this.dbPromise = oi(), this.dbPromise.catch(() => {
			this.dbPromise = null;
		}), this.dbPromise);
	}
	async _withRetries(e) {
		let t = 0;
		for (;;) try {
			return await e(await this._openDb());
		} catch (e) {
			if (t++ > di) throw e;
			if (this.dbPromise) {
				let e = this.dbPromise;
				this.dbPromise = null;
				try {
					(await e).close();
				} catch {}
			}
		}
	}
	async initializeServiceWorkerMessaging() {
		return Zr() ? this.initializeReceiver() : this.initializeSender();
	}
	async initializeReceiver() {
		this.receiver = qr._getInstance(ei()), this.receiver._subscribe("keyChanged", async (e, t) => ({ keyProcessed: (await this._poll()).includes(t.key) })), this.receiver._subscribe("ping", async (e, t) => ["keyChanged"]);
	}
	async initializeSender() {
		if (this.activeServiceWorker = await Qr(), !this.activeServiceWorker) return;
		this.sender = new Yr(this.activeServiceWorker);
		let e = await this.sender._send("ping", {}, 800);
		e && e[0]?.fulfilled && e[0]?.value.includes("keyChanged") && (this.serviceWorkerReceiverAvailable = !0);
	}
	async notifyServiceWorker(e) {
		if (this.sender && this.activeServiceWorker && $r() === this.activeServiceWorker) try {
			await this.sender._send("keyChanged", { key: e }, this.serviceWorkerReceiverAvailable ? 800 : 50);
		} catch {}
	}
	async _isAvailable() {
		try {
			return indexedDB ? (await this._withRetries(async (e) => {
				await si(e, Gr, "1"), await li(e, Gr);
			}), !0) : !1;
		} catch {}
		return !1;
	}
	async _withPendingWrite(e) {
		this.pendingWrites++;
		try {
			await e();
		} finally {
			this.pendingWrites--;
		}
	}
	async _set(e, t) {
		return this._withPendingWrite(async () => (await this._withRetries((n) => si(n, e, t)), this.localCache[e] = t, this.notifyServiceWorker(e)));
	}
	async _get(e) {
		let t = await this._withRetries((t) => ci(t, e));
		return this.localCache[e] = t, t;
	}
	async _remove(e) {
		return this._withPendingWrite(async () => (await this._withRetries((t) => li(t, e)), delete this.localCache[e], this.notifyServiceWorker(e)));
	}
	async _poll() {
		if (this.isClosing) return [];
		try {
			let e = await this._withRetries((e) => new Y(X(e, !1).getAll()).toPromise());
			if (this.isClosing || !e || this.pendingWrites !== 0) return [];
			let t = [], n = /* @__PURE__ */ new Set();
			if (e.length !== 0) for (let { fbase_key: r, value: i } of e) n.add(r), JSON.stringify(this.localCache[r]) !== JSON.stringify(i) && (this.notifyListeners(r, i), t.push(r));
			for (let e of Object.keys(this.localCache)) this.localCache[e] && !n.has(e) && (this.notifyListeners(e, null), t.push(e));
			return t;
		} catch (e) {
			return this.isClosing || Zt(`Firebase Auth cross-tab polling failed with error: ${e}`), [];
		}
	}
	notifyListeners(e, t) {
		this.localCache[e] = t;
		let n = this.listeners[e];
		if (n) for (let e of Array.from(n)) e(t);
	}
	startPolling() {
		this.stopPolling(), this.pollTimer = setInterval(async () => this._poll(), ui);
	}
	stopPolling() {
		this.pollTimer &&= (clearInterval(this.pollTimer), null);
	}
	_addListener(e, t) {
		Object.keys(this.listeners).length === 0 && (this.startPolling(), this.registerLifecycleListeners()), this.listeners[e] || (this.listeners[e] = /* @__PURE__ */ new Set(), this._get(e)), this.listeners[e].add(t);
	}
	_removeListener(e, t) {
		this.listeners[e] && (this.listeners[e].delete(t), this.listeners[e].size === 0 && delete this.listeners[e]), Object.keys(this.listeners).length === 0 && (this.stopPolling(), this.unregisterLifecycleListeners());
	}
};
fi.type = "LOCAL";
var pi = fi, mi = "@firebase/auth", hi = "1.13.7", gi = class {
	constructor(e) {
		this.auth = e, this.internalListeners = /* @__PURE__ */ new Map();
	}
	getUid() {
		return this.assertAuthConfigured(), this.auth.currentUser?.uid || null;
	}
	async getToken(e) {
		return this.assertAuthConfigured(), await this.auth._initializationPromise, this.auth.currentUser ? { accessToken: await this.auth.currentUser.getIdToken(e) } : null;
	}
	addAuthTokenListener(e) {
		if (this.assertAuthConfigured(), this.internalListeners.has(e)) return;
		let t = this.auth.onIdTokenChanged((t) => {
			e(t?.stsTokenManager.accessToken || null);
		});
		this.internalListeners.set(e, t), this.updateProactiveRefresh();
	}
	removeAuthTokenListener(e) {
		this.assertAuthConfigured();
		let t = this.internalListeners.get(e);
		t && (this.internalListeners.delete(e), t(), this.updateProactiveRefresh());
	}
	assertAuthConfigured() {
		L(this.auth._initializationPromise, "dependent-sdk-initialized-before-auth");
	}
	updateProactiveRefresh() {
		this.internalListeners.size > 0 ? this.auth._startProactiveRefresh() : this.auth._stopProactiveRefresh();
	}
};
function _i(e) {
	switch (e) {
		case "Node": return "node";
		case "ReactNative": return "rn";
		case "Worker": return "webworker";
		case "Cordova": return "cordova";
		case "WebExtension": return "web-extension";
		default: return;
	}
}
function vi(e) {
	A(new T("auth", (t, { options: n }) => {
		let r = t.getProvider("app").getImmediate(), i = t.getProvider("heartbeat"), a = t.getProvider("app-check-internal"), { apiKey: o, authDomain: s } = r.options;
		L(o && !o.includes(":"), "invalid-api-key", { appName: r.name });
		let c = new tr(r, i, a, {
			apiKey: o,
			authDomain: s,
			clientPlatform: e,
			apiHost: "identitytoolkit.googleapis.com",
			tokenApiHost: "securetoken.googleapis.com",
			apiScheme: "https",
			sdkClientVersion: Xn(e)
		});
		return hr(c, n), c;
	}, "PUBLIC").setInstantiationMode("EXPLICIT").setInstanceCreatedCallback((e, t, n) => {
		e.getProvider("auth-internal").initialize();
	})), A(new T("auth-internal", (e) => ((e) => new gi(e))(nr(e.getProvider("auth").getImmediate())), "PRIVATE").setInstantiationMode("EXPLICIT")), N(mi, hi, _i(e)), N(mi, hi, "esm2020");
}
//#endregion
//#region ../node_modules/.pnpm/@firebase+auth@1.13.7_@firebase+app@0.16.3/node_modules/@firebase/auth/dist/web-extension-esm/index.js
vi("WebExtension");
//#endregion
//#region firestore-codec.js
function yi(e) {
	if (!e || "nullValue" in e) return null;
	if ("stringValue" in e) return e.stringValue;
	if ("integerValue" in e) return Number(e.integerValue);
	if ("doubleValue" in e) return e.doubleValue;
	if ("booleanValue" in e) return e.booleanValue;
	if ("timestampValue" in e) return Date.parse(e.timestampValue);
	if ("arrayValue" in e) return (e.arrayValue.values ?? []).map(yi);
	if ("mapValue" in e) return Object.fromEntries(Object.entries(e.mapValue.fields ?? {}).map(([e, t]) => [e, yi(t)]));
	throw Error("Unsupported Firebase field");
}
function Z(e) {
	return yi({ mapValue: { fields: e.fields ?? {} } });
}
function Q(e) {
	if (e === null) return { nullValue: null };
	if (typeof e == "string") return { stringValue: e };
	if (typeof e == "boolean") return { booleanValue: e };
	if (typeof e == "number" && Number.isSafeInteger(e)) return { integerValue: String(e) };
	if (Array.isArray(e)) return { arrayValue: { values: e.map(Q) } };
	if (e && typeof e == "object") return { mapValue: { fields: Object.fromEntries(Object.entries(e).map(([e, t]) => [e, Q(t)])) } };
	throw Error("Unsupported Firebase value");
}
//#endregion
//#region ../shared/study-focus.ts
var bi = () => Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
function xi(e = Date.now(), t = bi()) {
	let n = new Intl.DateTimeFormat("en-US", {
		timeZone: t,
		year: "numeric",
		month: "2-digit",
		day: "2-digit"
	}).formatToParts(e);
	return [
		"year",
		"month",
		"day"
	].map((e) => n.find((t) => t.type === e).value).join("-");
}
function Si(e, t = Date.now(), n = !1) {
	if (!e || typeof e.id != "string" || !e.id || !Number.isSafeInteger(e.startedAt) || !Number.isSafeInteger(e.endsAt) || e.endsAt <= e.startedAt || e.endsAt - e.startedAt > 432e5) return [];
	let r = e.timeZone || bi(), i = Math.min(t, e.endsAt, e.paused ? e.pausedAt ?? e.startedAt : e.endsAt), a = [], o = e.startedAt;
	for (; o < i;) {
		let t = xi(o, r), s = i;
		if (xi(i - 1, r) !== t) {
			let e = o, n = i;
			for (; n - e > 1;) {
				let i = Math.floor((e + n) / 2);
				xi(i, r) === t ? e = i : n = i;
			}
			s = n;
		}
		let c = s - o, l = n && s === i && i < e.endsAt && !e.paused ? Math.floor(c / 6e4) * 6e4 : c;
		l > 0 && a.push({
			date: t,
			milliseconds: l
		}), o = s;
	}
	return a;
}
function Ci(e, t, n) {
	let r = { ...e?.sessionCredits ?? {} }, i = Number(r[t]) || 0, a = Math.max(i, n);
	return r[t] = a, {
		totalMilliseconds: Math.max(0, Number(e?.totalMilliseconds) || 0) + a - i,
		sessionCredits: r
	};
}
var wi = [
	"instagram.com",
	"facebook.com",
	"fb.com",
	"x.com",
	"twitter.com",
	"reddit.com",
	"snapchat.com",
	"tiktok.com",
	"threads.net",
	"threads.com",
	"pinterest.com",
	"linkedin.com",
	"discord.com",
	"discord.gg",
	"telegram.org",
	"t.me",
	"twitch.tv"
], Ti = (e, t) => e === t || e.endsWith(`.${t}`), Ei = (e) => wi.some((t) => Ti(e, t));
function Di(e) {
	let t = e.trim(), n = new URL(t.includes("://") ? t : `https://${t}`), r = n.hostname.toLowerCase().replace(/\.$/, "");
	if (!["http:", "https:"].includes(n.protocol) || n.username || n.password || r.length > 253 || !r.includes(".") || /^\d+(\.\d+){3}$/.test(r) || r.endsWith(".localhost") || r.split(".").some((e) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(e))) throw Error("Enter a domain like parmar.com.");
	return r;
}
function Oi(e) {
	let t = [...new Set(e.map(Di))];
	if (t.some(Ei)) throw Error("Social media websites cannot be added.");
	if (t.length > 2) throw Error("Maximum 2 websites per session.");
	return { domains: t };
}
//#endregion
//#region policy.js
var ki = [
	1,
	2,
	3
];
function $(e, t = Date.now()) {
	if (e === null) return null;
	if (!e || typeof e.id != "string" || !Number.isSafeInteger(e.startedAt) || !Number.isSafeInteger(e.endsAt) || e.endsAt <= e.startedAt || e.endsAt - e.startedAt > 432e5 || !Array.isArray(e.domains) || e.domains.length > 64 || e.paused !== void 0 && e.paused !== !0) throw Error("Invalid study session");
	if (e.appLimit !== void 0 && (!Number.isInteger(e.appLimit) || e.appLimit < 0 || e.appLimit > 2)) throw Error("Invalid allowed app limit");
	if (e.lockId !== void 0 && (typeof e.lockId != "string" || !e.lockId.length || e.lockId.length > 128)) throw Error("Invalid study session");
	if (e.paused && (!Number.isSafeInteger(e.remainingMs) || e.remainingMs < 1 || e.remainingMs > 432e5 || !Number.isSafeInteger(e.pausedAt))) throw Error("Invalid paused study session");
	for (let t of e.domains) if (typeof t != "string" || t.length > 253 || !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/.test(t) || /^\d+(\.\d+){3}$/.test(t)) throw Error("Invalid allowed website");
	return e.paused || e.endsAt > t ? {
		id: e.id,
		startedAt: e.startedAt,
		endsAt: e.endsAt,
		domains: e.domains.slice(0, 2),
		...e.appLimit === void 0 ? {} : { appLimit: e.appLimit },
		...e.lockId ? { lockId: e.lockId } : {},
		...e.timeZone ? { timeZone: e.timeZone } : {},
		...e.paused ? {
			paused: !0,
			pausedAt: e.pausedAt,
			remainingMs: e.remainingMs
		} : {}
	} : null;
}
function Ai(e) {
	return Oi([String(e).trim()]).domains[0] ?? (() => {
		throw Error("Enter a website domain.");
	})();
}
function ji(e, t, n = !1, r = Date.now()) {
	let i = Di(String(t).trim()), a = e.session && (e.session.paused || e.session.endsAt > r);
	if (a && n) throw Error("Websites stay locked until the timer ends.");
	let o = (a ? e.session.domains : e.allowedDomains ?? []).slice(0, 2), { domains: s } = Oi(n ? o.filter((e) => e !== i) : [.../* @__PURE__ */ new Set([...o, i])]);
	return {
		...e,
		version: 1,
		revision: crypto.randomUUID(),
		session: a ? {
			...e.session,
			domains: s
		} : null,
		allowedDomains: s,
		source: "extension"
	};
}
function Mi(e, t, n = Date.now()) {
	if (!Number.isInteger(t) || t < 1 || t > 720) throw Error("Choose 1 minute to 12 hours.");
	if (e.session && (e.session.paused || e.session.endsAt > n)) throw Error("Your session is already running.");
	let { domains: r } = Oi((e.allowedDomains ?? []).slice(0, 2));
	if (!r.length) throw Error("Add a website first.");
	return {
		...e,
		version: 1,
		revision: crypto.randomUUID(),
		source: "extension",
		session: {
			id: crypto.randomUUID(),
			startedAt: n,
			endsAt: n + t * 6e4,
			domains: r,
			timeZone: bi()
		}
	};
}
function Ni(e, t) {
	try {
		let n = new URL(e);
		return ["https:", "http:"].includes(n.protocol) && t.some((e) => n.hostname === e || n.hostname.endsWith(`.${e}`));
	} catch {
		return !1;
	}
}
function Pi(e, t = "") {
	return e ? [{
		id: 1,
		priority: 1,
		action: {
			type: "redirect",
			redirect: t ? { regexSubstitution: `${t}#site=\\1` } : { extensionPath: "/blocked.html" }
		},
		condition: {
			regexFilter: "^(https?://.*)$",
			resourceTypes: ["main_frame"]
		}
	}, ...e.domains.length ? [{
		id: 2,
		priority: 2,
		action: { type: "allow" },
		condition: {
			requestDomains: e.domains,
			resourceTypes: ["main_frame"]
		}
	}] : []] : [];
}
//#endregion
//#region ../shared/focus-rewards.ts
var Fi = 6e5, Ii = (e) => Number.isFinite(Number(e)) ? Math.floor(Math.max(0, Number(e) || 0) / Fi) : 0, Li = (e = {}) => Object.values(e).reduce((e, t) => e + Ii(t), 0);
function Ri(e) {
	let t = /* @__PURE__ */ new Date(`${e}T12:00:00Z`);
	return !Number.isFinite(t.getTime()) || t.toISOString().slice(0, 10) !== e ? "" : (t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 6) % 7), t.toISOString().slice(0, 10));
}
function zi(e, t, n, r) {
	let i = Ri(n);
	return {
		uid: e,
		username: String(t.username ?? "").trim().toLowerCase(),
		name: String(t.name || "Student"),
		...t.avatar ? { avatar: t.avatar } : {},
		week: i,
		focusDays: Object.fromEntries(Object.entries(r).filter(([e]) => /^\d{4}-\d{2}-\d{2}$/.test(e) && Ri(e) === i)),
		focusXp: Li(r)
	};
}
//#endregion
//#region cloud.js
function Bi() {
	let e = {
		apiKey: "AIzaSyBKS04pXofLZ18RDLYIlPvo8Mkba2mqIKQ",
		authDomain: "ssc-buddy-e73d7.firebaseapp.com",
		projectId: "ssc-buddy-e73d7",
		appId: "1:541181826831:web:75cb1de57a5db2affc507a"
	};
	if (!e.apiKey || !e.projectId || !e.appId) throw Error("The extension is not configured. Please install the latest version.");
	let t = mr(At(e), { persistence: pi }), n = new Promise((e) => {
		let n = Ur(t, () => {
			n(), e();
		});
	}), r = `https://firestore.googleapis.com/v1/projects/${encodeURIComponent(e.projectId)}/databases/(default)/documents`;
	async function i(e, i = {}, a, o, s) {
		await n;
		let c = t.currentUser;
		if (!c || a && c.uid !== a) throw Error("Sign in to your SSC Buddy account.");
		let l = await c.getIdToken(), u = s ? `${r}/leaderboards/${encodeURIComponent(s)}/entries/${encodeURIComponent(c.uid)}${e}` : o ? `${r}/publicProfiles/${encodeURIComponent(o)}${e}` : `${r}/users/${encodeURIComponent(c.uid)}/${e}`, d = await fetch(u, {
			...i,
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${l}`,
				...i.headers
			},
			signal: AbortSignal.timeout(8e3),
			cache: "no-store"
		});
		if (d.status === 404 && !i.method) return null;
		let f = await d.json();
		if (!d.ok) {
			let e = /* @__PURE__ */ Error(d.status === 403 ? "Sign in with your SSC Buddy account." : "Could not connect. Please try again.");
			throw e.status = d.status, e;
		}
		return f;
	}
	async function a(e, t, n) {
		let r = await i("profile/current", {}, n), a = r ? Z(r) : {}, s = String(a.username ?? "").trim().toLowerCase();
		if (!/^[a-z0-9._]{3,24}$/.test(s)) return;
		let c = await i("studyFocusDays/" + e, {}, n), l = Number(c ? Z(c).totalMilliseconds : 0) || 0;
		for (let r = 0; r < 4; r++) {
			let r = await i("", {}, n, s), c = r ? Z(r) : null;
			if (c?.uid !== n) return;
			if (Number(c.focusDays?.[e] ?? -1) >= l && c.focusTimeZone === t) {
				await o(n, a, e, c.focusDays);
				return;
			}
			let u = {
				...c.focusDays,
				[e]: Math.max(Number(c.focusDays?.[e]) || 0, l)
			}, d = "currentDocument.updateTime=" + encodeURIComponent(r.updateTime), f = Q({
				focusDays: u,
				focusTimeZone: t || "UTC"
			}).mapValue.fields;
			try {
				await i("?updateMask.fieldPaths=focusDays&updateMask.fieldPaths=focusTimeZone&" + d, {
					method: "PATCH",
					body: JSON.stringify({ fields: f })
				}, n, s), await o(n, a, e, u);
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Could not share focus time. Please try again.");
	}
	async function o(e, t, n, r) {
		let a = Ri(n);
		for (let o = 0; o < 4; o++) {
			let o = await i("", {}, e, void 0, a), s = o ? Z(o) : {}, c = zi(e, t, n, r);
			c.focusDays = {
				...s.focusDays,
				...Object.fromEntries(Object.entries(c.focusDays).map(([e, t]) => [e, Math.max(s.focusDays?.[e] ?? 0, t)]))
			}, c.focusXp = Math.max(s.focusXp ?? 0, c.focusXp);
			let l = o ? "currentDocument.updateTime=" + encodeURIComponent(o.updateTime) : "currentDocument.exists=false", u = Object.keys(c).map((e) => "updateMask.fieldPaths=" + encodeURIComponent(e)).join("&");
			try {
				await i("?" + u + "&" + l, {
					method: "PATCH",
					body: JSON.stringify({ fields: Q(c).mapValue.fields })
				}, e, void 0, a);
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Could not update focus points. Please try again.");
	}
	async function s(e, n = Date.now()) {
		let r = t.currentUser?.uid;
		if (!r) throw Error("Sign in to your SSC Buddy account.");
		for (let t of Si(e, n, !0)) {
			let n = !1;
			for (let a = 0; a < 4; a++) {
				let a = "studyFocusDays/" + t.date, o = await i(a, {}, r), s = o ? Z(o) : null, c = Ci(s, e.id, t.milliseconds);
				if (c.totalMilliseconds === s?.totalMilliseconds) {
					n = !0;
					break;
				}
				let l = o ? "currentDocument.updateTime=" + encodeURIComponent(o.updateTime) : "currentDocument.exists=false", u = Q({
					version: 1,
					date: t.date,
					...c
				}).mapValue.fields;
				u.updatedAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() };
				try {
					await i(a + "?" + l, {
						method: "PATCH",
						body: JSON.stringify({ fields: u })
					}, r), n = !0;
					break;
				} catch (e) {
					if (![409, 412].includes(e.status)) throw e;
				}
			}
			if (!n) throw Error("Could not save focus time. Please try again.");
			await a(t.date, e.timeZone || "UTC", r);
		}
	}
	async function c(e, t) {
		for (let n = 0; n < 4; n++) {
			let n = await i("studyLock/current"), r = n ? Z(n) : {
				version: 1,
				revision: "empty",
				session: null
			}, a = ji(r, e, t);
			r.session && r.session.endsAt <= Date.now() && await s(r.session);
			let o = n ? `currentDocument.updateTime=${encodeURIComponent(n.updateTime)}` : "currentDocument.exists=false";
			try {
				let e = Q(a).mapValue.fields;
				e.updatedAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() }, await i(`studyLock/current?${o}`, {
					method: "PATCH",
					body: JSON.stringify({ fields: e })
				});
				return;
			} catch (e) {
				if (![409, 412].includes(e.status)) throw e;
			}
		}
		throw Error("Your websites changed on another device. Try again.");
	}
	return {
		ready: n,
		recordFocus: s,
		user: () => t.currentUser ? {
			uid: t.currentUser.uid,
			email: t.currentUser.email
		} : null,
		subscribe: (e) => Ur(t, e),
		login: (e, n) => Hr(t, e, n),
		logout: () => Wr(t),
		async read() {
			let e = await i("studyLock/current");
			return e ? Z(e) : {
				version: 1,
				revision: "empty",
				session: null
			};
		},
		editWebsite: c,
		async start(e) {
			for (let t = 0; t < 4; t++) {
				let t = await i("studyLock/current"), n = t ? Z(t) : {
					version: 1,
					revision: "empty",
					session: null
				}, r = Mi(n, e);
				n.session && await s(n.session);
				let a = t ? `currentDocument.updateTime=${encodeURIComponent(t.updateTime)}` : "currentDocument.exists=false";
				try {
					await i(`studyLock/current?${a}`, {
						method: "PATCH",
						body: JSON.stringify({ fields: Q(r).mapValue.fields })
					});
					return;
				} catch (e) {
					if (![409, 412].includes(e.status)) throw e;
				}
			}
			throw Error("Your session changed on another device. Try again.");
		},
		async acknowledge(e, t, n = "") {
			let r = Q({
				label: /Edg\//.test(navigator.userAgent) ? "Edge" : "Chrome",
				extensionId: chrome.runtime.id,
				sessionId: t,
				error: n,
				version: 1
			}).mapValue.fields;
			r.lastSeenAt = { timestampValue: (/* @__PURE__ */ new Date()).toISOString() }, await i(`studyLockDevices/${encodeURIComponent(e)}`, {
				method: "PATCH",
				body: JSON.stringify({ fields: r })
			});
		}
	};
}
//#endregion
//#region worker-engine.js
function Vi(e) {
	try {
		let t = new URL(e).hash, n = t.startsWith("#site=") ? t.slice(6) : t.startsWith("#youtube=") ? t.slice(9) : "", r = new URL(/^https?:\/\//.test(n) ? n : decodeURIComponent(n));
		return ["http:", "https:"].includes(r.protocol) ? r.href : null;
	} catch {
		return null;
	}
}
function Hi(e) {
	let t = e?.code;
	if ([
		"auth/invalid-credential",
		"auth/wrong-password",
		"auth/user-not-found",
		"auth/invalid-email",
		"auth/missing-password"
	].includes(t)) return "Check your email and password.";
	if (t === "auth/too-many-requests") return "Too many attempts. Try again later.";
	if (t === "auth/network-request-failed") return "Check your internet connection.";
	if (t?.startsWith("auth/")) return "Could not sign in. Please try again.";
	let n = e?.message ?? "";
	return /firebase|googleapis|identitytoolkit|securetoken/i.test(n) || !n ? "Could not connect. Please try again." : n;
}
function Ui(e) {
	let t = 0, n = "", r = Promise.resolve(), i, a = (e) => {
		let t = r.then(e);
		return r = t.catch(() => {}), t;
	}, o = async () => await chrome.storage.local.get(["study", "deviceId"]);
	async function s(e, t, n) {
		let { study: r } = await o();
		if (r?.session && (!e || e.id !== r.session.id)) {
			let { pendingFocus: e = [] } = await chrome.storage.local.get("pendingFocus"), t = e.filter((e) => e.uid !== r.uid || e.session.id !== r.session.id);
			t.push({
				uid: r.uid,
				session: r.session
			}), await chrome.storage.local.set({ pendingFocus: t });
		}
		let i = await chrome.declarativeNetRequest.getSessionRules();
		await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: i.filter((e) => e.id >= 1e5).map((e) => e.id) }), await chrome.declarativeNetRequest.updateDynamicRules({
			removeRuleIds: ki,
			addRules: Pi(e, chrome.runtime.getURL("blocked.html"))
		}), await chrome.storage.local.set({ study: {
			session: e,
			revision: t,
			uid: n
		} }), await chrome.alarms.clear("study-end"), e && !e.paused && await chrome.alarms.create("study-end", { when: e.endsAt }), await chrome.action.setBadgeText({ text: e ? "ON" : "" }), await chrome.action.setBadgeBackgroundColor({ color: "#577c3e" });
	}
	async function c() {
		let { study: e } = await o(), t = $(e?.session ?? null);
		return !t && e?.session && await s(null, e.revision, e.uid), t;
	}
	async function l(e, t) {
		if (e.version !== 1 || typeof e.revision != "string" || e.revision.length > 128) throw Error("Could not load your focus session");
		let n = $(e.session), { study: r } = await o(), i = $(r?.session ?? null);
		if (i && r.uid === t) {
			let e = i.domains, t = n ? n.domains : [], r = n && e.length === n.domains.length && e.every((e) => n.domains.includes(e)), a = !i.paused && n?.paused && n.id === i.id && n.startedAt === i.startedAt && n.endsAt === i.endsAt && r, o = n && !n.paused && r && n.lockId === (i.lockId ?? i.id) && n.startedAt >= i.startedAt && n.endsAt - n.startedAt <= (i.paused ? i.remainingMs : i.endsAt - i.startedAt);
			if (!a && !o && (!n || n.id !== i.id || n.startedAt !== i.startedAt || n.endsAt !== i.endsAt || !!n.paused != !!i.paused || Number(n.remainingMs ?? 0) !== Number(i.remainingMs ?? 0) || e.some((e) => !t.includes(e)))) throw Error("Your session stays locked until its timer ends.");
		}
		let a = (n?.domains ?? e.allowedDomains ?? []).slice(0, 2);
		await chrome.storage.local.set({ websiteDraft: {
			uid: t,
			domains: a
		} });
		let { study: c } = await o();
		if ((c?.uid !== t || c?.revision !== e.revision || JSON.stringify(c?.session ?? null) !== JSON.stringify(n)) && (await s(n, e.revision, t), n)) for (let e of await chrome.tabs.query({})) e.id && /^https?:\/\//.test(e.url ?? "") && !Ni(e.url, n.domains) && await chrome.tabs.update(e.id, { url: chrome.runtime.getURL("blocked.html") + "#site=" + encodeURIComponent(e.url) }).catch(() => {});
		return n;
	}
	async function u() {
		return i || (i = (async () => {
			await e.ready;
			let r = e.user();
			if (!r) return;
			let i = await e.read();
			if (e.user()?.uid !== r.uid) return;
			let s = await a(() => l(i, r.uid)), { deviceId: c } = await o();
			if (c || (c = crypto.randomUUID(), await chrome.storage.local.set({ deviceId: c })), await e.acknowledge(c, s?.id ?? null), t = Date.now(), n = "", e.recordFocus) try {
				i.session && !i.session.paused && await e.recordFocus(i.session);
				let { pendingFocus: t = [] } = await chrome.storage.local.get("pendingFocus");
				for (let n of t.filter((e) => e.uid === r.uid)) {
					if (e.user()?.uid !== r.uid) break;
					await e.recordFocus(n.session), await a(async () => {
						let { pendingFocus: e = [] } = await chrome.storage.local.get("pendingFocus");
						await chrome.storage.local.set({ pendingFocus: e.filter((e) => e.uid !== n.uid || e.session.id !== n.session.id) });
					});
				}
			} catch {}
		})().catch((e) => {
			n = Hi(e);
		}).finally(() => {
			i = void 0;
		}), i);
	}
	async function d() {
		let [e] = await chrome.tabs.query({
			active: !0,
			lastFocusedWindow: !0
		}), t = e?.url, n = t?.startsWith(chrome.runtime.getURL("blocked.html")) ? Vi(t) : t;
		try {
			new URL(n);
			let t = Di(n);
			return {
				tabId: e.id,
				url: n,
				domain: t,
				canAdd: !Ei(t),
				label: "Add current website"
			};
		} catch {
			return null;
		}
	}
	chrome.runtime.onMessage.addListener((r, o, l) => {
		if (o.id === chrome.runtime.id && o.url?.startsWith(chrome.runtime.getURL(""))) return (async () => {
			let l = await a(c);
			if (await e.ready, r.type === "login" || r.type === "logout") {
				if (!o.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to manage your account.");
				if (l) throw Error("Account changes are locked until your focus timer ends.");
				r.type === "login" && (await e.login(String(r.email ?? "").trim(), String(r.password ?? "")), await u()), r.type === "logout" && (await e.logout(), t = 0, await a(() => s(null, "signed-out", null)));
			} else if (r.type === "website") {
				if (!o.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to edit websites.");
				if (!e.user()) throw Error("Sign in first.");
				await e.editWebsite(Ai(r.domain), !!r.remove), i && await i, await u();
			} else if (r.type === "current-add") {
				if (!o.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to add this website.");
				let t = await d();
				if (!t?.canAdd) throw Error("This page cannot be added.");
				await e.editWebsite(t.domain, !1), i && await i, await u();
			} else if (r.type === "start") {
				if (!o.url.startsWith(chrome.runtime.getURL("popup.html"))) throw Error("Open the extension popup to start a session.");
				await e.start(r.minutes), i && await i, await u();
			} else if (r.type === "site-add") {
				if (!o.url.startsWith(chrome.runtime.getURL("blocked.html"))) throw Error("Open the blocked page to add this website.");
				let t = Vi(o.url);
				if (!t) throw Error("Website unavailable.");
				let n = Di(t);
				if (Ei(n)) throw Error("This website cannot be added here.");
				await e.editWebsite(n, !1), i && await i, await u(), o.tab?.id && (await chrome.tabs.get(o.tab.id)).url === o.url && await chrome.tabs.update(o.tab.id, { url: t });
			} else if (r.type === "sync") await u();
			else if (r.type !== "status") throw Error("Unknown request");
			let f = await a(c), { websiteDraft: p } = await chrome.storage.local.get("websiteDraft"), m = e.user(), h = m?.uid && p?.uid === m.uid ? p : null, g = (f ? f.domains : h?.domains ?? []).slice(0, 2), _ = Vi(o.url), v = _ ? new URL(_).hostname : "", y = o.url.startsWith(chrome.runtime.getURL("popup.html")) ? await d() : null;
			return y && (y.canAdd = !!e.user() && y.canAdd && g.length < 2 && !g.includes(y.domain), delete y.url, delete y.tabId), {
				session: f,
				domains: g,
				currentSite: y,
				blockedSite: v ? {
					domain: v,
					canAdd: !!f && g.length < 2 && !Ei(v)
				} : null,
				user: m,
				connected: Date.now() - t < 65e3,
				error: n
			};
		})().then((e) => l({
			ok: !0,
			...e
		}), (e) => l({
			ok: !1,
			error: Hi(e)
		})), !0;
	}), chrome.alarms.onAlarm.addListener(() => {
		a(c).then(u).catch((e) => {
			n = Hi(e);
		});
	}), a(async () => {
		await chrome.storage.local.setAccessLevel({ accessLevel: "TRUSTED_CONTEXTS" });
		let { study: e } = await o();
		await s($(e?.session ?? null), e?.revision ?? "empty", e?.uid ?? null), await chrome.alarms.create("study-watch", { periodInMinutes: .5 });
	}).then(() => {
		e.subscribe(() => {
			u();
		}), u();
	}).catch((e) => {
		n = String(e);
	}), setInterval(() => {
		a(c).then(u);
	}, 1e4);
}
//#endregion
//#region worker.js
Ui(Bi());
//#endregion
